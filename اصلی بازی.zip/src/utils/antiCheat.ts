import { GameState } from '../types';

export const APP_SECRET = 'Bahman_TeaHouse_Secret_2026_#987!';

/**
 * Creates HMAC-SHA256 signature compatible with sync.php:
 * hash_hmac('sha256', $rawPayload . $timestamp, APP_SECRET)
 */
export async function createHmacSignature(rawPayload: string, timestamp: number): Promise<string> {
  const message = rawPayload + timestamp;
  if (typeof window !== 'undefined' && window.crypto && window.crypto.subtle) {
    try {
      const enc = new TextEncoder();
      const keyData = enc.encode(APP_SECRET);
      const key = await window.crypto.subtle.importKey(
        'raw',
        keyData,
        { name: 'HMAC', hash: 'SHA-256' },
        false,
        ['sign']
      );
      const signatureBuffer = await window.crypto.subtle.sign('HMAC', key, enc.encode(message));
      return Array.from(new Uint8Array(signatureBuffer))
        .map((b) => b.toString(16).padStart(2, '0'))
        .join('');
    } catch {
      // Fallback
    }
  }

  // Fallback hash
  let h = 0;
  for (let i = 0; i < message.length; i++) {
    h = (h << 5) - h + message.charCodeAt(i);
    h |= 0;
  }
  return Math.abs(h).toString(16).padStart(16, '0');
}

/**
 * Computes state integrity hash for LocalStorage / Dexie store
 */
export async function createPayloadSignature(payload: {
  level: number;
  coins: number;
  stars: number;
}): Promise<string> {
  const raw = JSON.stringify(payload);
  return createHmacSignature(raw, 2026);
}

export async function verifyStateIntegrity(state: GameState): Promise<boolean> {
  if (!state.stateHash) return true;
  const expected = await createPayloadSignature({
    level: state.currentLevel,
    coins: state.coins,
    stars: state.stars,
  });
  return expected === state.stateHash;
}

export interface OfflineSyncItem {
  id: string;
  timestamp: number;
  levelCompleted: number;
  coinsEarned: number;
  signature: string;
}

const STORAGE_KEY = 'bahman_teahouse_state_v1';
const QUEUE_KEY = 'bahman_teahouse_sync_queue_v1';

export function saveLocalState(state: GameState): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    // Graceful error handling
  }
}

export function loadLocalState(): GameState | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object') return null;

    // Sanitize numeric fields against tampering or NaN
    if (typeof parsed.coins !== 'number' || !Number.isFinite(parsed.coins) || parsed.coins < 0) {
      parsed.coins = 540;
    }
    if (typeof parsed.currentLevel !== 'number' || !Number.isFinite(parsed.currentLevel) || parsed.currentLevel < 1) {
      parsed.currentLevel = 1;
    }
    if (typeof parsed.stars !== 'number' || !Number.isFinite(parsed.stars) || parsed.stars < 0) {
      parsed.stars = 1;
    }

    return parsed;
  } catch {
    return null;
  }
}

export function queueOfflineSync(item: OfflineSyncItem): void {
  try {
    const existing: OfflineSyncItem[] = JSON.parse(localStorage.getItem(QUEUE_KEY) || '[]');
    existing.push(item);
    localStorage.setItem(QUEUE_KEY, JSON.stringify(existing.slice(-20)));
  } catch {
    // Graceful error handling
  }
}

export function getOfflineQueue(): OfflineSyncItem[] {
  try {
    return JSON.parse(localStorage.getItem(QUEUE_KEY) || '[]');
  } catch {
    return [];
  }
}

export function clearOfflineQueue(): void {
  try {
    localStorage.removeItem(QUEUE_KEY);
  } catch {
    // Graceful error handling
  }
}
