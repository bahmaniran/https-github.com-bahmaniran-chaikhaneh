const PERSIAN_DIGITS = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

export function toPersianDigits(value: number | string): string {
  if (value === undefined || value === null) return '';
  return value
    .toString()
    .replace(/[0-9]/g, (digit) => PERSIAN_DIGITS[parseInt(digit, 10)]);
}

export function formatPersianCoins(coins: number): string {
  if (typeof coins !== 'number' || isNaN(coins)) {
    return toPersianDigits('0');
  }
  const formatted = coins.toLocaleString('en-US');
  return toPersianDigits(formatted);
}

export function formatTimeSeconds(seconds: number): string {
  if (typeof seconds !== 'number' || isNaN(seconds) || seconds < 0) {
    seconds = 0;
  }
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  const minsStr = mins < 10 ? `0${mins}` : `${mins}`;
  const secsStr = secs < 10 ? `0${secs}` : `${secs}`;
  return `${toPersianDigits(minsStr)}:${toPersianDigits(secsStr)}`;
}
