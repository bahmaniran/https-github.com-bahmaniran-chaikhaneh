import React, { useState, useEffect, useCallback, useRef } from 'react';
import confetti from 'canvas-confetti';
import { Cup, DrinkType, RadioTrackId, ShopItem, PlayerProfile, WeeklyChallengeStage } from './types';
import { generateLevel, LevelConfig } from './game/LevelGenerator';
import { solveWaterSort, isBoardSolved } from './game/Solver';
import { soundEngine } from './audio/SoundEngine';
import {
  saveLocalState,
  loadLocalState,
  createPayloadSignature,
  queueOfflineSync,
} from './utils/antiCheat';
import {
  getStoredPlayerProfile,
  syncProgressToServer,
  fetchServerConfig,
  ServerConfig,
  APP_VERSION,
} from './services/backendApi';
import {
  completeWeeklyStage,
  getWeeklyChallengeState,
  getWeeklyStagesForCurrentWeek,
} from './game/WeeklyChallengeService';
import { toPersianDigits, formatPersianCoins } from './utils/persianNumbers';

// Components
import { HUD } from './components/HUD';
import { CharacterSpeech } from './components/CharacterSpeech';
import { Estekan } from './components/Estekan';
import { ActionBar } from './components/ActionBar';
import { RushOrderBanner } from './components/RushOrderBanner';
import { OnboardingPointer } from './components/OnboardingPointer';
import { TeahouseAtmosphere } from './components/TeahouseAtmosphere';
import { PersianTeahouseScene } from './components/PersianTeahouseScene';
import { DakhleBahmanDrawer } from './components/DakhleBahmanDrawer';
import { VIPBossBanner } from './components/VIPBossBanner';

// Modals
import { RadioModal } from './components/modals/RadioModal';
import { SpecialGuestModal } from './components/modals/SpecialGuestModal';
import { FortuneModal } from './components/modals/FortuneModal';
import { DecorationShopModal } from './components/modals/DecorationShopModal';
import { NeighborhoodModal } from './components/modals/NeighborhoodModal';
import { DailyRewardModal } from './components/modals/DailyRewardModal';
import {
  getDailyRewardStatus,
  claimDailyReward,
  DailyRewardStatus,
} from './services/DailyRewardService';
import { VictoryModal } from './components/modals/VictoryModal';
import { RegisterPlayerModal } from './components/modals/RegisterPlayerModal';
import { WeeklyChallengeModal } from './components/modals/WeeklyChallengeModal';
import { ContactModal } from './components/modals/ContactModal';
import { MainMenuModal } from './components/modals/MainMenuModal';
import { DaftarHesabModal } from './components/modals/DaftarHesabModal';
import { NaghaliModal } from './components/modals/NaghaliModal';
import { DecorationRenovationModal } from './components/modals/DecorationRenovationModal';
import { PatoghModal } from './components/modals/PatoghModal';
import { SiniGardaniModal } from './components/modals/SiniGardaniModal';
import { TakhtehNardModal } from './components/modals/TakhtehNardModal';
import { PahlavaniCardModal } from './components/modals/PahlavaniCardModal';
import { HavalehModal } from './components/modals/HavalehModal';
import { AppUpdateModal } from './components/modals/AppUpdateModal';
import { AutoUpdateModal } from './components/modals/AutoUpdateModal';
import { checkForAppUpdate, shouldPromptUpdate, recordUpdateCheckedNow } from './services/UpdateService';
import { AppUpdateInfo } from './types';
import {
  getDaftarHesab,
  borrowDebt,
  advanceDebtStreak,
  failDebtStreak,
  repayDebtRepossession,
  getNaghaliState,
  saveNaghaliState,
  awardNaghaliPiece,
  getOwnedDecorations,
  saveOwnedDecorations,
  getDailyTipStatus,
  claimDailyTip,
  canRollDiceToday,
  VIP_BOSSES,
} from './services/TeahouseStore';
import { syncWithBackend } from './utils/apiClient';
import { VIPBossCustomer } from './types';
import exactTeahouseBg from './assets/images/teahouse_exact_scene_1791919273685.jpg';

const EXACT_TEAHOUSE_BG = exactTeahouseBg;

const OSTA_SPEECHES = [
  'باریکلا جوون، حواستو جمع کن!',
  'دمت گرم، عجب چای قندپهلوئی شد! دست مریزاد!',
  'شربت خنک زعفران، دوای درد خستگی پهلوون‌هاست.',
  'عجله کار شیطونه! اول فکر کن، بعد استکان رو کج کن.',
  'خاکشیر دوفاز رو دیدی چطور ته‌نشین شد؟ هنر یعنی این!',
  'سماور همیشه در حال جوشه، دل ما هم به دیدارت روشنه!',
];

export default function App() {
  // Game progression state
  const [currentLevel, setCurrentLevel] = useState<number>(1);
  const [coins, setCoins] = useState<number>(540);
  const [stars, setStars] = useState<number>(1);
  const [cups, setCups] = useState<Cup[]>([]);
  const [history, setHistory] = useState<Cup[][]>([]);
  const [selectedCupIdx, setSelectedCupIdx] = useState<number | null>(null);
  const [extraCupUsed, setExtraCupUsed] = useState<boolean>(false);
  const [movesCount, setMovesCount] = useState<number>(0);

  // Pouring animation state
  const [pouringCupIdx, setPouringCupIdx] = useState<number | null>(null);
  const [pourDirection, setPourDirection] = useState<'left' | 'right'>('right');

  // Solver hint
  const [hint, setHint] = useState<{ fromIndex: number; toIndex: number } | null>(null);

  // Timed Rush Mode (Every 5th level)
  const [isRushMode, setIsRushMode] = useState<boolean>(false);
  const [rushTimeLeft, setRushTimeLeft] = useState<number>(45);
  const [rushTargets, setRushTargets] = useState<DrinkType[]>([]);
  const [isRushWon, setIsRushWon] = useState<boolean>(false);

  // Audio & Settings
  const [colorblindMode, setColorblindMode] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [volume, setVolume] = useState<number>(0.8);
  const [activeRadioTrack, setActiveRadioTrack] = useState<RadioTrackId>('tar_sonati');

  // Cozy Night Mode (Auto-detected between 20:00 and 06:00, or user toggled)
  const [isNightMode, setIsNightMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('bahman_night_mode');
      if (saved !== null) return saved === 'true';
    } catch {}
    const h = new Date().getHours();
    return h >= 20 || h < 6;
  });

  // Progressive Feature Disclosure: Dev Toggle to Unlock All UI
  const [unlockAll, setUnlockAll] = useState<boolean>(() => {
    try {
      return localStorage.getItem('bahman_unlock_all') === 'true';
    } catch {
      return false;
    }
  });

  // Modals state
  const [isMainMenuOpen, setIsMainMenuOpen] = useState<boolean>(false);
  const [isCounterDrawerOpen, setIsCounterDrawerOpen] = useState<boolean>(false);
  const [isHavalehOpen, setIsHavalehOpen] = useState<boolean>(false);
  const [isRadioOpen, setIsRadioOpen] = useState<boolean>(false);
  const [isSpecialGuestOpen, setIsSpecialGuestOpen] = useState<boolean>(false);
  const [isFortuneOpen, setIsFortuneOpen] = useState<boolean>(false);
  const [isShopOpen, setIsShopOpen] = useState<boolean>(false);
  const [isNeighborhoodOpen, setIsNeighborhoodOpen] = useState<boolean>(false);
  const [isDailyRewardOpen, setIsDailyRewardOpen] = useState<boolean>(false);
  const [dailyRewardStatus, setDailyRewardStatus] = useState<DailyRewardStatus>(() =>
    getDailyRewardStatus()
  );
  const [isVictoryOpen, setIsVictoryOpen] = useState<boolean>(false);
  const [isRegisterOpen, setIsRegisterOpen] = useState<boolean>(false);
  const [isWeeklyChallengeOpen, setIsWeeklyChallengeOpen] = useState<boolean>(false);
  const [isContactOpen, setIsContactOpen] = useState<boolean>(false);

  // 10 Viral Mechanics Modals & State
  const [isDaftarHesabOpen, setIsDaftarHesabOpen] = useState<boolean>(false);
  const [debtState, setDebtState] = useState(() => getDaftarHesab());
  const [isNaghaliOpen, setIsNaghaliOpen] = useState<boolean>(false);
  const [naghaliState, setNaghaliState] = useState(() => getNaghaliState());
  const [isRenovationsOpen, setIsRenovationsOpen] = useState<boolean>(false);
  const [ownedDecorations, setOwnedDecorations] = useState<string[]>(() => getOwnedDecorations());
  const [isPatoghOpen, setIsPatoghOpen] = useState<boolean>(false);
  const [isSiniGardaniOpen, setIsSiniGardaniOpen] = useState<boolean>(false);
  const [isTakhtehNardOpen, setIsTakhtehNardOpen] = useState<boolean>(false);
  const [isPahlavaniCardOpen, setIsPahlavaniCardOpen] = useState<boolean>(false);

  // In-App Direct APK & OTA Update
  const [isAppUpdateOpen, setIsAppUpdateOpen] = useState<boolean>(false);
  const [appUpdateInfo, setAppUpdateInfo] = useState<AppUpdateInfo | null>(null);

  // Direct Self-Updater & Live Server Config (https://mrasan.ir/api/config.php)
  const [serverConfig, setServerConfig] = useState<ServerConfig | null>(null);
  const [isAutoUpdateOpen, setIsAutoUpdateOpen] = useState<boolean>(false);

  // VIP Boss Customer
  const [activeVIPBoss, setActiveVIPBoss] = useState<VIPBossCustomer | null>(null);
  const [vipBossTimeLeft, setVipBossTimeLeft] = useState<number | undefined>(undefined);
  const [vipBossMovesLeft, setVipBossMovesLeft] = useState<number | undefined>(undefined);

  // Weekly Challenge Active Play State
  const [activeWeeklyStage, setActiveWeeklyStage] = useState<WeeklyChallengeStage | null>(null);
  const [weeklyCompletedIds, setWeeklyCompletedIds] = useState<number[]>(() => {
    return getWeeklyChallengeState().completedStageIds;
  });
  const [weeklyPointsWon, setWeeklyPointsWon] = useState<number>(0);
  const [weeklyEarnedCoins, setWeeklyEarnedCoins] = useState<number>(0);

  // Player Profile
  const [playerProfile, setPlayerProfile] = useState<PlayerProfile>(getStoredPlayerProfile());

  // Customization & Collections
  const [unlockedShopItems, setUnlockedShopItems] = useState<string[]>([
    'carpet_gelim',
    'samovar_halabi',
    'window_khaki',
  ]);
  const [equippedCarpet, setEquippedCarpet] = useState<string>('carpet_gelim');
  const [equippedSamovar, setEquippedSamovar] = useState<string>('samovar_halabi');
  const [equippedWindow, setEquippedWindow] = useState<string>('window_khaki');
  const [sugarCubes, setSugarCubes] = useState<number[]>([1]);
  const [isSpecialChallengeAccepted, setIsSpecialChallengeAccepted] = useState<boolean>(false);

  // Osta Bahman & Guidance
  const [speechText, setSpeechText] = useState<string>(OSTA_SPEECHES[0]);
  const stuckSecondsRef = useRef<number>(0);
  const [failCount, setFailCount] = useState<number>(0);
  const [isStuckAlert, setIsStuckAlert] = useState<boolean>(false);
  const [onboardingActive, setOnboardingActive] = useState<boolean>(true);
  const speechResetTimerRef = useRef<number | null>(null);

  // Non-intrusive speech notification dispatcher with 4-second auto-dismiss
  const setCozySpeech = useCallback((text: string, isPersistent: boolean = false) => {
    setSpeechText(text);
    if (speechResetTimerRef.current) {
      clearTimeout(speechResetTimerRef.current);
      speechResetTimerRef.current = null;
    }
    if (!isPersistent) {
      speechResetTimerRef.current = window.setTimeout(() => {
        setSpeechText(OSTA_SPEECHES[Math.floor(Math.random() * OSTA_SPEECHES.length)]);
      }, 4000);
    }
  }, []);

  // Level progress percentage
  const levelProgressPercent = Math.min(100, 20 + ((currentLevel % 5) / 5) * 80);

  // Penalty lock state: active if debt was defaulted and item repossessed
  const isPenaltyLocked = Boolean(debtState.repossessedItem);

  // Load saved state on mount
  useEffect(() => {
    const saved = loadLocalState();
    if (saved) {
      setCurrentLevel(saved.currentLevel || 1);
      setCoins(saved.coins ?? 540);
      setStars(saved.stars || 1);
      setColorblindMode(!!saved.colorblindMode);
      setSoundEnabled(saved.soundEnabled !== false);
      if (saved.unlockedShopItems) setUnlockedShopItems(saved.unlockedShopItems);
      if (saved.equippedCarpet) setEquippedCarpet(saved.equippedCarpet);
      if (saved.equippedSamovar) setEquippedSamovar(saved.equippedSamovar);
      if (saved.equippedWindow) setEquippedWindow(saved.equippedWindow);
      if (saved.sugarCubesCollected) setSugarCubes(saved.sugarCubesCollected);
      if (saved.activeTrack) setActiveRadioTrack(saved.activeTrack);
    }
  }, []);

  // Daily Login Reward Auto-check
  useEffect(() => {
    const status = getDailyRewardStatus();
    setDailyRewardStatus(status);
    if (status.canClaim) {
      const timer = setTimeout(() => {
        setIsDailyRewardOpen(true);
      }, 750);
      return () => clearTimeout(timer);
    }
  }, []);

  // In-App Direct APK & OTA Update Automatic Check on Launch
  useEffect(() => {
    let isMounted = true;
    const checkUpdates = async () => {
      try {
        const info = await checkForAppUpdate();
        if (!isMounted) return;
        setAppUpdateInfo(info);
        recordUpdateCheckedNow();
        if (shouldPromptUpdate(info)) {
          // Delay display slightly so initial game UI renders smoothly
          setTimeout(() => {
            if (isMounted) setIsAppUpdateOpen(true);
          }, 1400);
        }
      } catch {}
    };

    checkUpdates();
    return () => {
      isMounted = false;
    };
  }, []);

  // Direct Self-Updater & Live Server Config System (https://mrasan.ir/api/config.php)
  useEffect(() => {
    let isMounted = true;
    const checkLiveServerConfig = async () => {
      try {
        const config = await fetchServerConfig();
        if (!isMounted || !config) return;
        setServerConfig(config);

        // 3. If data.announcement is returned, display it in Uncle Bahman's speech bubble
        if (config.announcement && config.announcement.trim()) {
          setCozySpeech(config.announcement.trim(), true);
        }

        // 4. If data.current_version !== APP_VERSION, automatically open AutoUpdateModal
        if (config.current_version && config.current_version !== APP_VERSION) {
          setTimeout(() => {
            if (isMounted) {
              setIsAutoUpdateOpen(true);
            }
          }, 1200);
        }
      } catch (err) {
        console.warn('Failed to fetch server config on startup:', err);
      }
    };

    checkLiveServerConfig();
    return () => {
      isMounted = false;
    };
  }, [setCozySpeech]);

  // Initialize level
  const initLevel = useCallback(
    (lvl: number) => {
      const config: LevelConfig = generateLevel(lvl);
      setCups(config.cups);
      setHistory([]);
      setSelectedCupIdx(null);
      setExtraCupUsed(false);
      setMovesCount(0);
      setHint(null);
      stuckSecondsRef.current = 0;
      setFailCount(0);
      setIsStuckAlert(false);
      setIsRushWon(false);

      // VIP Boss Customer every 10 levels
      if (lvl % 10 === 0) {
        const bossKeys = Object.keys(VIP_BOSSES);
        const boss = VIP_BOSSES[bossKeys[(Math.floor(lvl / 10) - 1) % bossKeys.length]];
        setActiveVIPBoss(boss);
        setVipBossTimeLeft(boss.timeLimit);
        setVipBossMovesLeft(boss.movesLimit);
        if (boss.id === 'poet_shekasteh') {
          config.cups.forEach((c) => {
            if (c.layers.length > 0) c.isSteamy = true;
          });
        }
        setCozySpeech(`«${boss.dialogue[0]}»`, true);
      } else {
        setActiveVIPBoss(null);
        setVipBossTimeLeft(undefined);
        setVipBossMovesLeft(undefined);
        setCozySpeech(OSTA_SPEECHES[Math.floor(Math.random() * OSTA_SPEECHES.length)]);
      }

      setIsRushMode(config.isRushMode);
      if (config.isRushMode && config.rushTargets) {
        setRushTargets(config.rushTargets);
        setRushTimeLeft(config.rushTimeLimit || 45);
      }

      setOnboardingActive(lvl === 1);
    },
    [setCozySpeech]
  );

  useEffect(() => {
    initLevel(currentLevel);
  }, [currentLevel, initLevel]);

  // VIP Boss Impatient Timer
  useEffect(() => {
    if (!vipBossTimeLeft || vipBossTimeLeft <= 0 || !activeVIPBoss) return;
    const timer = setInterval(() => {
      setVipBossTimeLeft((prev) => {
        if (!prev || prev <= 1) {
          clearInterval(timer);
          soundEngine.playTrayClatter();
          setCozySpeech('«جواد سبیل: دیر کردی رفیق! سرویس رفت، منم رفتم!»');
          setTimeout(() => initLevel(currentLevel), 1500);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [vipBossTimeLeft, activeVIPBoss, currentLevel, initLevel, setCozySpeech]);

  // Rush Order Timer
  useEffect(() => {
    if (!isRushMode || isRushWon || rushTimeLeft <= 0) return;
    const timer = setInterval(() => {
      setRushTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          soundEngine.playTrayClatter();
          setCozySpeech('«سفارش فوری سوخت! دست بجنبون پهلوون.»');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [isRushMode, isRushWon, rushTimeLeft, setCozySpeech]);

  // Stuck Detection
  useEffect(() => {
    if (isBoardSolved(cups) || isVictoryOpen) return;
    const interval = setInterval(() => {
      stuckSecondsRef.current += 1;
      if (stuckSecondsRef.current >= 60 && !isStuckAlert) {
        setIsStuckAlert(true);
        setCozySpeech('«خسته شدی پهلوون؟ این راهنما مهمون من!»', true);
        const solution = solveWaterSort(cups);
        if (solution && solution.length > 0) {
          setHint(solution[0]);
        }
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [cups, isStuckAlert, isVictoryOpen, setCozySpeech]);

  // Sound Engine sync
  useEffect(() => {
    soundEngine.setMuted(!soundEnabled);
  }, [soundEnabled]);

  useEffect(() => {
    soundEngine.setVolume(volume);
  }, [volume]);

  // Save state helper
  const persistState = useCallback(
    async (lvl: number, c: number, s: number) => {
      const hash = await createPayloadSignature({ level: lvl, coins: c, stars: s });
      saveLocalState({
        currentLevel: lvl,
        coins: c,
        stars: s,
        extraCupsUsedInLevel: 0,
        colorblindMode,
        soundEnabled,
        musicEnabled: true,
        volume,
        activeTrack: activeRadioTrack,
        sugarCubesCollected: sugarCubes,
        unlockedShopItems,
        equippedCarpet,
        equippedSamovar,
        equippedWindow,
        lastDailyChallengeDate: new Date().toISOString().split('T')[0],
        stateHash: hash,
      });

      queueOfflineSync({
        id: `sync_${Date.now()}`,
        timestamp: Date.now(),
        levelCompleted: lvl,
        coinsEarned: c,
        signature: hash,
      });
    },
    [
      colorblindMode,
      soundEnabled,
      volume,
      activeRadioTrack,
      sugarCubes,
      unlockedShopItems,
      equippedCarpet,
      equippedSamovar,
      equippedWindow,
    ]
  );

  // Claim daily reward
  const handleClaimDailyReward = (rewardAmount: number) => {
    const res = claimDailyReward();
    if (res.success) {
      setCoins((prev) => {
        const next = prev + res.rewardAmount;
        persistState(currentLevel, next, stars);
        return next;
      });
      setDailyRewardStatus(getDailyRewardStatus());
      setCozySpeech('«عیدی عمو بهمن نوش جونت پهلوون! دشت اول صبح برکت چایخانه‌ست.»');
    }
  };

  // Check valid target cups from source
  const getValidTargetIndices = useCallback(
    (sourceIdx: number, cupList: Cup[]): number[] => {
      const source = cupList[sourceIdx];
      if (!source || source.layers.length === 0 || source.hasSugarCubeBlocker || source.isFrozenSolid) {
        return [];
      }
      const sourceTop = source.layers[source.layers.length - 1];

      const validList: number[] = [];
      cupList.forEach((target, idx) => {
        if (idx === sourceIdx || target.isFrozenSolid || target.layers.length >= 4) return;
        if (target.layers.length === 0) {
          validList.push(idx);
        } else {
          const targetTop = target.layers[target.layers.length - 1];
          if (targetTop === sourceTop) {
            validList.push(idx);
          }
        }
      });
      return validList;
    },
    []
  );

  // Execute valid pour from source to target
  const executePour = useCallback(
    (fromIdx: number, toIdx: number) => {
      const sourceCup = cups[fromIdx];
      const targetCup = cups[toIdx];

      setHistory((prev) => [...prev, cups.map((c) => ({ ...c, layers: [...c.layers] }))]);

      const sourceTop = sourceCup.layers[sourceCup.layers.length - 1];
      let count = 0;
      for (let k = sourceCup.layers.length - 1; k >= 0; k--) {
        if (sourceCup.layers[k] === sourceTop) count++;
        else break;
      }

      const availableSpace = 4 - targetCup.layers.length;
      const transferCount = Math.min(count, availableSpace);

      setPouringCupIdx(fromIdx);
      setPourDirection(fromIdx < toIdx ? 'right' : 'left');
      soundEngine.playPouring(targetCup.layers.length);

      setTimeout(() => {
        const nextCups = cups.map((c) => ({ ...c, layers: [...c.layers] }));
        const newSource = nextCups[fromIdx];
        const newTarget = nextCups[toIdx];

        for (let i = 0; i < transferCount; i++) {
          newSource.layers.pop();
          newTarget.layers.push(sourceTop);
        }

        // Feature 1: Sugar Cube Blocker Melt (melted by Hot Red Tea or Saffron)
        if (newTarget.hasSugarCubeBlocker && (sourceTop === 'tea' || sourceTop === 'saffron')) {
          newTarget.hasSugarCubeBlocker = false;
          soundEngine.playSugarMelt();
          setCozySpeech('«ایول پهلوون! قند حبه با چای داغ ذوب شد و مسیر استکان باز شد!»');
        }

        // Feature 1: Steamy Mystery Glass Reveal
        if (newSource.isSteamy) {
          newSource.isSteamy = false;
          soundEngine.playClick();
          setCozySpeech('«بخار استکان کنار رفت و رنگ چای آشکار شد!»');
        }

        // Feature 1: Decrement Cooling Tea Move Count
        nextCups.forEach((c) => {
          if (c.coolingMovesLeft !== undefined && !c.isFrozenSolid) {
            c.coolingMovesLeft = Math.max(0, c.coolingMovesLeft - 1);
            if (c.coolingMovesLeft === 0) {
              c.isFrozenSolid = true;
              soundEngine.playIceFreeze();
              setCozySpeech('«وای وای! چای سرد شد و استکان یخ زد و قفل شد!»');
            }
          }
        });

        // VIP Boss Moves Limit Check
        if (vipBossMovesLeft !== undefined) {
          const nextMoves = vipBossMovesLeft - 1;
          setVipBossMovesLeft(nextMoves);
          if (nextMoves <= 0) {
            soundEngine.playTrayClatter();
            setCozySpeech('«حاج‌آقا بازاری: چرتکه انداختم، حرکت‌هات تموم شد! از سود افتادیم!»');
            setTimeout(() => initLevel(currentLevel), 1500);
            return;
          }
        }

        setCups(nextCups);
        setSelectedCupIdx(null);
        setPouringCupIdx(null);
        setMovesCount((prev) => prev + 1);
        setHint(null);

        // Feature 5: Visual Closure celebration
        const targetIsNowComplete =
          newTarget.layers.length === 4 && newTarget.layers.every((l) => l === newTarget.layers[0]);

        if (targetIsNowComplete) {
          soundEngine.playSaucerClink();
          soundEngine.playCupServedSteam();
          setCozySpeech('«نوش جان مشتری! یه استکان دیشلمه با نعلبکی و قند پهلو چیده شد.»');
        }

        if (isBoardSolved(nextCups)) {
          setTimeout(
            () => {
              handleWin(nextCups);
            },
            targetIsNowComplete ? 700 : 200
          );
        }
      }, 280);
    },
    [cups, vipBossMovesLeft, initLevel, currentLevel, setCozySpeech]
  );

  // Handle cup tap with useCallback to prevent re-rendering Estekans
  const handleCupClick = React.useCallback(
    (cupIdx: number) => {
      if (onboardingActive) setOnboardingActive(false);
      stuckSecondsRef.current = 0;

      // Obstacle Check: Frozen solid
      if (cups[cupIdx].isFrozenSolid) {
        soundEngine.playIceFreeze();
        setCozySpeech('«این استکان یخ زده و قفله پهلوون! نمی‌تونی بهش دست بزنی.»');
        return;
      }

      if (selectedCupIdx === null) {
        // Obstacle Check: Cannot pour FROM sugar cube blocker
        if (cups[cupIdx].hasSugarCubeBlocker) {
          soundEngine.playGlassClink();
          setCozySpeech('«قند حبه راه این استکان رو بسته! اول باید با چای داغ قرمز ذوبش کنی!»');
          return;
        }
        if (cups[cupIdx].layers.length === 0) {
          soundEngine.playGlassClink();
          return;
        }
        soundEngine.playGlassClink();
        setSelectedCupIdx(cupIdx);
        return;
      }

      if (selectedCupIdx === cupIdx) {
        soundEngine.playGlassClink();
        setSelectedCupIdx(null);
        return;
      }

      const sourceCup = cups[selectedCupIdx];
      const targetCup = cups[cupIdx];

      if (targetCup.layers.length >= 4) {
        soundEngine.playGlassClink();
        setSelectedCupIdx(cupIdx);
        return;
      }

      const sourceTop = sourceCup.layers[sourceCup.layers.length - 1];
      const targetTop = targetCup.layers[targetCup.layers.length - 1];

      if (targetCup.layers.length > 0 && targetTop !== sourceTop) {
        soundEngine.playGlassClink();
        setSelectedCupIdx(cupIdx);
        setFailCount((prev) => {
          const next = prev + 1;
          if (next >= 3 && !isStuckAlert) {
            setIsStuckAlert(true);
            setCozySpeech('«حواست کجاست پهلوون؟ رنگ‌ها باید یکی باشن. بذار کمکت کنم!»', true);
            const solution = solveWaterSort(cups);
            if (solution && solution.length > 0) {
              setHint(solution[0]);
            }
          }
          return next;
        });
        return;
      }

      // VALID POUR!
      executePour(selectedCupIdx, cupIdx);
    },
    [onboardingActive, cups, selectedCupIdx, isStuckAlert, setCozySpeech, executePour]
  );

  // Smart Double-Tap Quick Pour: automatically pours to best target without reaching across screen!
  const handleDoubleTapCup = React.useCallback(
    (cupIdx: number) => {
      const cup = cups[cupIdx];
      if (!cup || cup.layers.length === 0 || cup.hasSugarCubeBlocker || cup.isFrozenSolid) {
        handleCupClick(cupIdx);
        return;
      }

      const validTargets = getValidTargetIndices(cupIdx, cups);
      if (validTargets.length === 0) {
        handleCupClick(cupIdx);
        return;
      }

      const sourceTop = cup.layers[cup.layers.length - 1];
      // First preference: cup with matching color
      let bestTarget = validTargets.find(
        (idx) =>
          cups[idx].layers.length > 0 &&
          cups[idx].layers[cups[idx].layers.length - 1] === sourceTop
      );
      // Second preference: empty cup
      if (bestTarget === undefined) {
        bestTarget = validTargets[0];
      }

      executePour(cupIdx, bestTarget);
    },
    [cups, handleCupClick, executePour]
  );

  const handleStartWeeklyStage = (stage: WeeklyChallengeStage) => {
    setActiveWeeklyStage(stage);
    setCups(stage.initialCups.map((c) => ({ ...c, layers: [...c.layers] })));
    setHistory([]);
    setSelectedCupIdx(null);
    setExtraCupUsed(false);
    setMovesCount(0);
    setHint(null);
    stuckSecondsRef.current = 0;
    setFailCount(0);
    setIsStuckAlert(false);
    setIsRushMode(false);
    setOnboardingActive(false);
    setCozySpeech(
      `«مرحله ${toPersianDigits(stage.id)} چالش دوشنبه: ${stage.title}! یا علی بگو و استکان‌ها رو بچین.»`
    );
  };

  const handleWin = (finalCups: Cup[]) => {
    soundEngine.playSanturVictory();
    try {
      confetti({
        particleCount: 90,
        spread: 75,
        origin: { y: 0.6 },
        colors: ['#F59E0B', '#0D9488', '#8B0000', '#FDE047'],
      });
    } catch {}

    if (activeWeeklyStage) {
      const res = completeWeeklyStage(activeWeeklyStage.id);
      const earned = res.rewardCoins;
      const weeklyScoreBonus = res.rewardWeeklyScore;
      setWeeklyPointsWon(weeklyScoreBonus);
      setWeeklyEarnedCoins(earned);

      const newCoins = coins + earned;
      setCoins(newCoins);
      persistState(currentLevel, newCoins, stars + 1);

      const updatedState = getWeeklyChallengeState();
      setWeeklyCompletedIds(updatedState.completedStageIds);

      syncProgressToServer({
        coins: newCoins,
        currentLevel: currentLevel,
        weeklyScoreDelta: weeklyScoreBonus,
        decorations: {
          carpet: equippedCarpet,
          samovar: equippedSamovar,
          window: equippedWindow,
        },
      }).catch(() => {});

      setIsVictoryOpen(true);
      return;
    }

    let earned = 60;
    if (isSpecialChallengeAccepted) {
      earned *= 2;
    }
    if (isRushMode && rushTimeLeft > 0) {
      earned += 150;
      setIsRushWon(true);
    }

    // 1. VIP Boss Tip
    if (activeVIPBoss) {
      earned += activeVIPBoss.tipReward;
      setCozySpeech(`«${activeVIPBoss.dialogue[2]}»`);
      setActiveVIPBoss(null);
    }

    // 2. Daftar Hesab: Advance debt win streak
    if (debtState.isDebtActive) {
      const debtRes = advanceDebtStreak();
      setDebtState(debtRes.state);
      if (debtRes.cleared) {
        setCozySpeech('«حسابت صاف شد پهلوون! حلالت باشه! اسمت از دفتر خط خورد.»', true);
      }
    }

    // 3. Naghali piece
    if (naghaliState.isActive) {
      const pieceRes = awardNaghaliPiece();
      setNaghaliState(getNaghaliState());
      if (pieceRes.newPiece !== null) {
        setCozySpeech(
          `«۱ قطعه دیگر از تابلوی نقاشی رستم آزاد شد (${toPersianDigits(pieceRes.total)}/۹)!»`
        );
      }
    }

    const newCoins = coins + earned;
    setCoins(newCoins);
    persistState(currentLevel + 1, newCoins, stars + 1);

    // 4. Trigger 20-second Sini-Gardani Bonus every 5 levels
    if ((currentLevel + 1) % 5 === 0) {
      setTimeout(() => setIsSiniGardaniOpen(true), 1200);
    }

    // 5. Progressive Feature Disclosure Toasts
    const nextLevel = currentLevel + 1;
    if (nextLevel === 3) {
      setCozySpeech('«ماشاءالله! به مرحله ۳ رسیدی! دکوراسیون چایخانه و تخته‌نرد برات باز شد!»', true);
    } else if (nextLevel === 5) {
      setCozySpeech('«ایوالله پهلوون! به مرحله ۵ رسیدی! دفتر حساب، رادیو لامپی و حواله سکه باز شد!»', true);
    } else if (nextLevel === 8) {
      setCozySpeech('«دمت گرم سالار! به مرحله ۸ رسیدی! پاتوق‌کشی محله و رویداد نقالی باز شد!»', true);
    }

    // 6. Live HMAC Sync
    syncWithBackend({
      device_id: playerProfile?.deviceId || 'device_guest',
      nickname: playerProfile?.nickname || 'پهلوان چایخانه',
      coins: newCoins,
      current_level: nextLevel,
      weekly_score_delta: earned,
      decorations: ownedDecorations,
    }).catch(() => {});

    setIsVictoryOpen(true);
  };

  const handleUndo = () => {
    if (history.length === 0) return;
    soundEngine.playClick();
    const prev = history[history.length - 1];
    setHistory((h) => h.slice(0, -1));
    setCups(prev);
    setSelectedCupIdx(null);
    setHint(null);

    if (activeVIPBoss?.id === 'poet_shekasteh') {
      setCozySpeech('«چنان در غم فرو رفتم که رنگ از چای هم بگریخت... (برگشت به عقب)»');
    }
  };

  const handleAddCup = () => {
    if (isPenaltyLocked) {
      soundEngine.playGlassClink();
      setCozySpeech('«استکان کمکی در توقیف نسیه عمو بهمن است! اول بدهی‌ات را تسویه کن.»');
      return;
    }
    if (extraCupUsed || cups.length >= 8) return;
    soundEngine.playGlassClink();
    setHistory((prev) => [...prev, cups.map((c) => ({ ...c, layers: [...c.layers] }))]);
    const newCup: Cup = {
      id: cups.length,
      layers: [],
      isExtra: true,
    };
    setCups((prev) => [...prev, newCup]);
    setExtraCupUsed(true);
    setCozySpeech('«یه استکان نو گذاشتم تو سینی، حالا راحت‌تر دستت بازه!»');
  };

  const handleHint = () => {
    soundEngine.playClick();
    const solution = solveWaterSort(cups);
    if (solution && solution.length > 0) {
      setHint(solution[0]);
      setCozySpeech('«اینم راهنما! استکان مبدأ و مقصد رو چشمک‌زن کردم برات.»');
    } else {
      setCozySpeech('«راهی نمونده پهلوون! دکمه برگشت یا استکان نو رو بزن.»');
    }
  };

  const handleNextLevel = () => {
    setIsVictoryOpen(false);
    if (activeWeeklyStage) {
      const allStages = getWeeklyStagesForCurrentWeek();
      const nextStage = allStages.find((s) => s.id === activeWeeklyStage.id + 1);
      if (nextStage) {
        handleStartWeeklyStage(nextStage);
      } else {
        setActiveWeeklyStage(null);
        setIsWeeklyChallengeOpen(true);
        initLevel(currentLevel);
        setCozySpeech('«ایوالله پهلوون! تمام مراحل چالش دوشنبه رو با سربلندی فتح کردی!»');
      }
      return;
    }

    setCurrentLevel((lvl) => lvl + 1);
    setIsSpecialChallengeAccepted(false);
  };

  // Borrow credit from Uncle Bahman
  const handleBorrowCredit = () => {
    const res = borrowDebt();
    if (res.success) {
      const newCoins = coins + res.coinsGranted;
      setCoins(newCoins);
      setDebtState(res.state);
      persistState(currentLevel, newCoins, stars);
      setCozySpeech('«۳۰۰ سکه نسیه به جیبت واریز شد! ۳ مرحله بدون باخت ببر تا صاف شه!»', true);
    }
  };

  // Repay repossession debt (350 coins)
  const handleRepayDebt = () => {
    if (coins < 350) return;
    const res = repayDebtRepossession();
    if (res.success) {
      const newCoins = coins - 350;
      setCoins(newCoins);
      setDebtState(res.state);
      persistState(currentLevel, newCoins, stars);
      setCozySpeech('«دمت گرم! ۳۵۰ سکه تسویه شد و توقیف وسایل چایخانه برداشته شد!»', true);
    }
  };

  // Fail level penalty trigger
  const handleRestartLevel = () => {
    if (debtState.isDebtActive) {
      const res = failDebtStreak(ownedDecorations);
      setDebtState(res.state);
      setCozySpeech(
        '«مأمور وصول عمو بهمن: ریستارت کردی و شرط ۳ برد باطل شد! یکی از وسایل توقیف شد تا ۳۵۰ سکه تسویه کنی!»',
        true
      );
    }
    initLevel(currentLevel);
  };

  // Buy and equip items
  const handleBuyShopItem = (item: ShopItem) => {
    if (coins < item.price) {
      // Auto prompt debt if coins not enough!
      setCozySpeech('«سکه کم داری پهلوون! می‌تونی از دفتر حساب نسیه بگیری!»');
      setIsDaftarHesabOpen(true);
      return;
    }
    const newCoins = coins - item.price;
    setCoins(newCoins);
    const newUnlocked = [...unlockedShopItems, item.id];
    setUnlockedShopItems(newUnlocked);
    persistState(currentLevel, newCoins, stars);

    if (item.category === 'carpet') setEquippedCarpet(item.id);
    if (item.category === 'samovar') setEquippedSamovar(item.id);
    if (item.category === 'window') setEquippedWindow(item.id);
  };

  const handleEquipShopItem = (item: ShopItem) => {
    if (item.category === 'carpet') setEquippedCarpet(item.id);
    if (item.category === 'samovar') setEquippedSamovar(item.id);
    if (item.category === 'window') setEquippedWindow(item.id);
  };

  // Valid target indices calculation for Smart Auto-Target highlight
  const validTargetIndices = selectedCupIdx !== null ? getValidTargetIndices(selectedCupIdx, cups) : [];

  return (
    <main
      className="relative w-full h-[100dvh] overflow-hidden flex items-center justify-center bg-[#241107]"
      dir="rtl"
    >
      {/* Desktop Atmospheric Teahouse Background Blur */}
      <div
        className="absolute inset-0 bg-cover bg-center opacity-45 pointer-events-none filter blur-md scale-105"
        style={{ backgroundImage: `url(${EXACT_TEAHOUSE_BG})` }}
      />
      <div className="absolute inset-0 bg-radial from-transparent via-[#2E1609]/70 to-[#180A04] pointer-events-none" />

      {/* Responsive Game Cabinet Container: Edge-to-edge on mobile, Royal Persian Arcade Frame on Tablet & Laptop */}
      <section
        className="relative w-full max-w-[440px] sm:max-w-[480px] md:max-w-[500px] h-[100dvh] sm:h-[97dvh] sm:my-auto sm:rounded-[36px] sm:border-[4px] sm:border-[#854D27] sm:shadow-[0_25px_80px_rgba(0,0,0,0.9),0_0_0_2px_rgba(245,158,11,0.25)] flex flex-col justify-between overflow-hidden shadow-[0_0_60px_rgba(30,12,4,0.85)] border-x-2 border-[#683C1D]/80 select-none bg-cover bg-center transition-all duration-500"
        style={{ backgroundImage: `url(${EXACT_TEAHOUSE_BG})` }}
      >
        {/* Soft Warm Top & Bottom Ambient Gradients */}
        <div className="absolute top-0 inset-x-0 h-14 bg-gradient-to-b from-[#2E1508]/35 to-transparent pointer-events-none z-10" />
        <div className="absolute bottom-0 inset-x-0 h-12 bg-gradient-to-t from-[#2E1508]/35 to-transparent pointer-events-none z-10" />

        {/* Ambient Effects */}
        <TeahouseAtmosphere />

        {/* Top HUD with Progressive Feature Disclosure & Consolidated Triggers */}
        <HUD
          currentLevel={currentLevel}
          coins={coins}
          levelProgressPercent={levelProgressPercent}
          soundEnabled={soundEnabled}
          isNightMode={isNightMode}
          unlockAll={unlockAll}
          isDebtActive={debtState.isDebtActive}
          debtStreakLeft={Math.max(0, 3 - debtState.debtStreak)}
          onOpenMenu={() => setIsMainMenuOpen(true)}
          onOpenCounterDrawer={() => setIsCounterDrawerOpen(true)}
          onOpenHavaleh={() => setIsHavalehOpen(true)}
          onOpenDaftarHesab={() => setIsDaftarHesabOpen(true)}
          onToggleSound={() => {
            soundEngine.playClick();
            setSoundEnabled((prev) => !prev);
          }}
          onToggleNightMode={() => {
            soundEngine.playClick();
            setIsNightMode((prev) => {
              const next = !prev;
              try {
                localStorage.setItem('bahman_night_mode', String(next));
              } catch {}
              return next;
            });
          }}
          onToggleUnlockAll={() => {
            soundEngine.playClick();
            setUnlockAll((prev) => {
              const next = !prev;
              try {
                localStorage.setItem('bahman_unlock_all', String(next));
              } catch {}
              setCozySpeech(
                next
                  ? '«حالت توسعه فعال شد: همه امکانات و بخش‌ها باز شدند!»'
                  : '«حالت عادی: امکانات طبق مرحله باز می‌شوند.»'
              );
              return next;
            });
          }}
          hasDailyRewardAvailable={dailyRewardStatus.canClaim}
          hasUnclaimedWeekly={weeklyCompletedIds.length < 5}
        />

        {/* Character Banner: Uncle Bahman Avatar & Non-Intrusive Speech Bubble */}
        <CharacterSpeech
          speechText={speechText}
          isStuckAlert={isStuckAlert}
          onAvatarClick={() => {
            soundEngine.playClick();
            setCozySpeech(OSTA_SPEECHES[Math.floor(Math.random() * OSTA_SPEECHES.length)]);
          }}
        />

        {/* Active Weekly Monday Challenge Banner */}
        {activeWeeklyStage && (
          <div className="z-20 px-2 py-0.5 animate-fade-in">
            <div className="flex items-center justify-between p-2 rounded-2xl bg-gradient-to-r from-amber-950/95 via-[#351909] to-amber-950/95 border-2 border-yellow-400 shadow-xl text-amber-100">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-xl bg-gradient-to-tr from-amber-500 to-yellow-300 text-amber-950 font-lalezar text-xs flex items-center justify-center font-bold shadow">
                  {toPersianDigits(activeWeeklyStage.id)}
                </div>
                <div>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="font-lalezar text-xs text-yellow-300">
                      چالش دوشنبه: {activeWeeklyStage.title}
                    </span>
                    {activeWeeklyStage.modifierLabel && (
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-900/80 text-amber-200 border border-amber-600/60 font-vazir">
                        {activeWeeklyStage.modifierLabel}
                      </span>
                    )}
                  </div>
                  <span className="text-[9px] text-amber-200/80 font-vazir block">
                    پاداش: +{formatPersianCoins(activeWeeklyStage.rewardCoins)} سکه ★ و +
                    {toPersianDigits(activeWeeklyStage.rewardWeeklyScore)} امتیاز لیگ
                  </span>
                </div>
              </div>

              <button
                onClick={() => {
                  soundEngine.playClick();
                  setActiveWeeklyStage(null);
                  initLevel(currentLevel);
                }}
                className="px-2 py-1 rounded-xl bg-[#200D04] hover:bg-[#381708] border border-amber-600/70 text-amber-300 text-[10px] font-lalezar transition-all active:scale-95 cursor-pointer"
                title="بازگشت به مراحل اصلی چایخانه"
              >
                انصراف
              </button>
            </div>
          </div>
        )}

        {/* Timed Rush Order Banner */}
        {!activeWeeklyStage && isRushMode && (
          <div className="z-20 px-2">
            <RushOrderBanner
              timeLeft={rushTimeLeft}
              targets={rushTargets}
              isCompleted={isRushWon}
            />
          </div>
        )}

        {/* VIP Boss Customer Banner (Every 10 levels) */}
        {!activeWeeklyStage && activeVIPBoss && (
          <div className="z-20 px-2 py-0.5">
            <VIPBossBanner
              boss={activeVIPBoss}
              timeLeft={vipBossTimeLeft}
              movesLeft={vipBossMovesLeft}
            />
          </div>
        )}

        {/* Center Gameplay Area with Eye-Comfort Palette & Diegetic Teahouse Scene */}
        <div className="relative flex-1 flex flex-col justify-end items-center px-1 pb-1 z-20 overflow-hidden">
          <OnboardingPointer isVisible={onboardingActive && currentLevel === 1 && !activeWeeklyStage} />

          <PersianTeahouseScene
            isNightMode={isNightMode}
            currentLevel={currentLevel}
            unlockAll={unlockAll}
            onOpenRenovations={() => setIsRenovationsOpen(true)}
            onOpenRadio={() => setIsRadioOpen(true)}
            onOpenDaftarHesab={() => setIsDaftarHesabOpen(true)}
            onOpenPatogh={() => setIsPatoghOpen(true)}
          >
            {cups.map((cup, idx) => {
              const isSelected = selectedCupIdx === idx;
              const isValidTarget = validTargetIndices.includes(idx);
              const isInvalidDimmed = selectedCupIdx !== null && !isValidTarget && !isSelected;

              return (
                <Estekan
                  key={cup.id}
                  cup={cup}
                  cupIndex={idx}
                  isSelected={isSelected}
                  isValidTarget={isValidTarget}
                  isInvalidDimmed={isInvalidDimmed}
                  isHintSource={hint?.fromIndex === idx}
                  isHintTarget={hint?.toIndex === idx}
                  isPouring={pouringCupIdx === idx}
                  pourDirection={pourDirection}
                  colorblindMode={colorblindMode}
                  hasGoldenSugarCube={idx === 0 && currentLevel % 2 === 1 && !activeWeeklyStage}
                  onCupClick={handleCupClick}
                  onCupDoubleTap={handleDoubleTapCup}
                />
              );
            })}
          </PersianTeahouseScene>
        </div>

        {/* Bottom Ergonomic Action Bar (Thumb-Zone strictly in bottom 25%) */}
        <ActionBar
          canUndo={history.length > 0}
          undoCount={history.length}
          canAddExtraCup={!extraCupUsed && cups.length < 8}
          isPenaltyLocked={isPenaltyLocked}
          onUndo={handleUndo}
          onAddCup={handleAddCup}
          onHint={handleHint}
          onOpenFortune={() => setIsFortuneOpen(true)}
        />
      </section>

      {/* Diegetic Drawer: میز دخل عمو بهمن */}
      <DakhleBahmanDrawer
        isOpen={isCounterDrawerOpen}
        onClose={() => setIsCounterDrawerOpen(false)}
        currentLevel={currentLevel}
        unlockAll={unlockAll}
        onOpenRenovations={() => setIsRenovationsOpen(true)}
        onOpenRadio={() => setIsRadioOpen(true)}
        onOpenDaftarHesab={() => setIsDaftarHesabOpen(true)}
        onOpenTakhtehNard={() => setIsTakhtehNardOpen(true)}
        onOpenPatogh={() => setIsPatoghOpen(true)}
        onOpenPahlavaniCard={() => setIsPahlavaniCardOpen(true)}
        onOpenHavaleh={() => setIsHavalehOpen(true)}
        hasDailyTipAvailable={getDailyTipStatus().canClaim}
        hasDiceRollAvailable={canRollDiceToday()}
        isDebtActive={debtState.isDebtActive}
      />

      {/* Peer-to-Peer Coin Sharing / Havaleh Modal */}
      <HavalehModal
        isOpen={isHavalehOpen}
        onClose={() => setIsHavalehOpen(false)}
        currentLevel={currentLevel}
        coins={coins}
        onCoinsChange={(newCoins) => {
          setCoins(newCoins);
          persistState(currentLevel, newCoins, stars);
        }}
        senderId={playerProfile.deviceId}
        unlockAll={unlockAll}
        onGenerosityAward={(msg) => setCozySpeech(msg, true)}
      />

      {/* Interactive Cultural Modals */}
      <RadioModal
        isOpen={isRadioOpen}
        onClose={() => setIsRadioOpen(false)}
        activeTrack={activeRadioTrack}
        volume={volume}
        onTrackChange={(track) => {
          setActiveRadioTrack(track);
          soundEngine.playRadioTrack(track);
        }}
        onVolumeChange={(vol) => setVolume(vol)}
      />

      <SpecialGuestModal
        isOpen={isSpecialGuestOpen}
        onClose={() => setIsSpecialGuestOpen(false)}
        isAccepted={isSpecialChallengeAccepted}
        onAcceptChallenge={() => {
          setIsSpecialChallengeAccepted(true);
          setIsSpecialGuestOpen(false);
          setCozySpeech('«پهلوان غفور مهمون ماست، چالش ۲ برابر سکه فعال شد!»');
        }}
      />

      <FortuneModal
        isOpen={isFortuneOpen}
        onClose={() => setIsFortuneOpen(false)}
        onRewardCoins={(reward) => {
          setCoins((prev) => {
            const next = prev + reward;
            persistState(currentLevel, next, stars);
            return next;
          });
        }}
      />

      <DecorationShopModal
        isOpen={isShopOpen}
        onClose={() => setIsShopOpen(false)}
        coins={coins}
        unlockedItems={unlockedShopItems}
        equippedCarpet={equippedCarpet}
        equippedSamovar={equippedSamovar}
        equippedWindow={equippedWindow}
        sugarCubesCollected={sugarCubes}
        onBuyItem={handleBuyShopItem}
        onEquipItem={handleEquipShopItem}
      />

      <NeighborhoodModal
        isOpen={isNeighborhoodOpen}
        onClose={() => setIsNeighborhoodOpen(false)}
        playerLevel={currentLevel}
        playerScore={coins + stars * 50}
        onOpenRegister={() => setIsRegisterOpen(true)}
        playerProfile={playerProfile}
        onOpenWeeklyChallenge={() => {
          setIsNeighborhoodOpen(false);
          setIsWeeklyChallengeOpen(true);
        }}
      />

      <WeeklyChallengeModal
        isOpen={isWeeklyChallengeOpen}
        onClose={() => setIsWeeklyChallengeOpen(false)}
        onStartStage={(stage) => handleStartWeeklyStage(stage)}
        onOpenLeaderboard={() => {
          setIsWeeklyChallengeOpen(false);
          setIsNeighborhoodOpen(true);
        }}
        onRewardsClaimed={(bonus) => {
          setCoins((prev) => {
            const next = prev + bonus;
            persistState(currentLevel, next, stars);
            return next;
          });
          setWeeklyCompletedIds(getWeeklyChallengeState().completedStageIds);
        }}
      />

      <DailyRewardModal
        isOpen={isDailyRewardOpen}
        onClose={() => setIsDailyRewardOpen(false)}
        onClaim={handleClaimDailyReward}
        currentStreak={dailyRewardStatus.streak}
        todayRewardAmount={dailyRewardStatus.todayRewardAmount}
        isClaimedToday={dailyRewardStatus.isClaimedToday}
      />

      <DaftarHesabModal
        isOpen={isDaftarHesabOpen}
        onClose={() => setIsDaftarHesabOpen(false)}
        debtState={debtState}
        coins={coins}
        onBorrow={handleBorrowCredit}
        onRepay={handleRepayDebt}
      />

      <TakhtehNardModal
        isOpen={isTakhtehNardOpen}
        onClose={() => setIsTakhtehNardOpen(false)}
        onAwardCoins={(earned: number) => {
          setCoins((prev) => {
            const next = prev + earned;
            persistState(currentLevel, next, stars);
            return next;
          });
        }}
      />

      <DecorationRenovationModal
        isOpen={isRenovationsOpen}
        onClose={() => setIsRenovationsOpen(false)}
        coins={coins}
        ownedIds={ownedDecorations}
        equippedSamovar={equippedSamovar}
        equippedCarpet={equippedCarpet}
        onBuyItem={(item) => {
          if (coins < item.price) return;
          const nextCoins = coins - item.price;
          setCoins(nextCoins);
          const nextOwned = [...ownedDecorations, item.id];
          setOwnedDecorations(nextOwned);
          saveOwnedDecorations(nextOwned);
          persistState(currentLevel, nextCoins, stars);
        }}
        onEquipItem={(item) => {
          if (item.category === 'samovar') setEquippedSamovar(item.id);
          else if (item.category === 'carpet') setEquippedCarpet(item.id);
        }}
        onCoinsAwarded={(amount: number) => {
          setCoins((prev) => {
            const next = prev + amount;
            persistState(currentLevel, next, stars);
            return next;
          });
          setCozySpeech(`«انعام روزانه دخل (${toPersianDigits(amount)} سکه) نوش جونت پهلوون!»`);
        }}
      />

      <PatoghModal
        isOpen={isPatoghOpen}
        onClose={() => setIsPatoghOpen(false)}
        deviceId={playerProfile.deviceId}
        playerName={playerProfile.nickname || 'پهلوان چایخانه'}
      />

      <PahlavaniCardModal
        isOpen={isPahlavaniCardOpen}
        onClose={() => setIsPahlavaniCardOpen(false)}
        nickname={playerProfile.nickname || 'پهلوان چایخانه'}
        level={currentLevel}
        coins={coins}
        ownedDecorations={ownedDecorations}
        onRewardCoins={(amt: number) => {
          setCoins((prev) => {
            const next = prev + amt;
            persistState(currentLevel, next, stars);
            return next;
          });
        }}
      />

      <NaghaliModal
        isOpen={isNaghaliOpen}
        onClose={() => setIsNaghaliOpen(false)}
        naghaliState={naghaliState}
        onToggleActive={() => {
          const nextState = { ...naghaliState, isActive: !naghaliState.isActive };
          setNaghaliState(nextState);
          saveNaghaliState(nextState);
        }}
        onClaimPrize={() => {
          setCoins((prev) => {
            const next = prev + 500;
            persistState(currentLevel, next, stars);
            return next;
          });
          const nextState = { ...naghaliState, hasClaimedReward: true };
          setNaghaliState(nextState);
          saveNaghaliState(nextState);
          setCozySpeech('«تبریک پهلوون! جایزه بزرگ رویداد نقالی (۵۰۰ سکه طلا) تقدیم شما!»');
        }}
      />

      <SiniGardaniModal
        isOpen={isSiniGardaniOpen}
        onClose={() => setIsSiniGardaniOpen(false)}
        onFinish={(bonus: number) => {
          setCoins((prev) => {
            const next = prev + bonus;
            persistState(currentLevel, next, stars);
            return next;
          });
          setCozySpeech(`«دستخوش! سینی‌گردانی عالی بود، +${toPersianDigits(bonus)} سکه انعام گرفتی!»`);
        }}
      />

      <ContactModal
        isOpen={isContactOpen}
        onClose={() => setIsContactOpen(false)}
      />

      <MainMenuModal
        isOpen={isMainMenuOpen}
        onClose={() => setIsMainMenuOpen(false)}
        playerProfile={playerProfile}
        currentLevel={currentLevel}
        coins={coins}
        soundEnabled={soundEnabled}
        colorblindMode={colorblindMode}
        weeklyStagesCompleted={weeklyCompletedIds.length}
        hasDailyRewardAvailable={dailyRewardStatus.canClaim}
        hasDiceRollAvailable={canRollDiceToday()}
        hasDailyTipAvailable={getDailyTipStatus().canClaim}
        isDebtActive={debtState.isDebtActive}
        onOpenRegister={() => setIsRegisterOpen(true)}
        onOpenShop={() => setIsShopOpen(true)}
        onOpenNeighborhood={() => setIsNeighborhoodOpen(true)}
        onOpenSpecialGuest={() => setIsSpecialGuestOpen(true)}
        onOpenWeeklyChallenge={() => setIsWeeklyChallengeOpen(true)}
        onOpenDailyReward={() => setIsDailyRewardOpen(true)}
        onOpenRadio={() => setIsRadioOpen(true)}
        onOpenContact={() => setIsContactOpen(true)}
        onOpenDaftarHesab={() => setIsDaftarHesabOpen(true)}
        onOpenNaghali={() => setIsNaghaliOpen(true)}
        onOpenRenovations={() => setIsRenovationsOpen(true)}
        onOpenPatogh={() => setIsPatoghOpen(true)}
        onOpenSiniGardani={() => setIsSiniGardaniOpen(true)}
        onOpenTakhtehNard={() => setIsTakhtehNardOpen(true)}
        onOpenPahlavaniCard={() => setIsPahlavaniCardOpen(true)}
        hasUpdateAvailable={
          Boolean(
            (serverConfig && serverConfig.current_version !== APP_VERSION) ||
              appUpdateInfo?.hasUpdate
          )
        }
        onCheckUpdate={async () => {
          if (serverConfig && serverConfig.current_version !== APP_VERSION) {
            setIsAutoUpdateOpen(true);
            return;
          }
          const cfg = await fetchServerConfig();
          if (cfg) {
            setServerConfig(cfg);
            if (cfg.current_version !== APP_VERSION) {
              setIsAutoUpdateOpen(true);
              return;
            }
          }
          // If already on latest version, notify user happily
          setCozySpeech(
            `شما در حال حاضر از آخرین نسخه (${toPersianDigits(APP_VERSION)}) چایخانه عمو بهمن استفاده می‌کنید! دمت گرم.`,
            false
          );
          setIsAppUpdateOpen(true);
        }}
        onToggleSound={() => {
          soundEngine.playClick();
          setSoundEnabled((prev) => !prev);
        }}
        onToggleColorblind={() => {
          soundEngine.playClick();
          setColorblindMode((prev) => !prev);
        }}
      />

      {/* Direct Self-Updater & Live Server Config Modal */}
      <AutoUpdateModal
        isOpen={isAutoUpdateOpen}
        onClose={() => setIsAutoUpdateOpen(false)}
        config={
          serverConfig || {
            current_version: '1.1.0',
            direct_apk_url: 'https://mrasan.ir/api/bahman-latest.apk',
            changelog:
              '• ارتقای کامل سرعت بازی و رفع هرگونه لگ در موبایل\n• اضافه شدن مراحل جذاب و چالش‌های هفتگی جدید\n• هماهنگی با لیگ محله و سینی گردانی',
            force_update: false,
          }
        }
      />

      {/* Direct In-App APK & OTA Update Modal */}
      <AppUpdateModal
        isOpen={isAppUpdateOpen}
        onClose={() => setIsAppUpdateOpen(false)}
        updateInfo={appUpdateInfo}
        onCheckAgain={async () => {
          const info = await checkForAppUpdate();
          setAppUpdateInfo(info);
        }}
      />

      <RegisterPlayerModal
        isOpen={isRegisterOpen}
        onClose={() => setIsRegisterOpen(false)}
        currentProfile={playerProfile}
        onProfileUpdated={(updated) => setPlayerProfile(updated)}
      />

      <VictoryModal
        isOpen={isVictoryOpen}
        level={currentLevel}
        earnedCoins={
          activeWeeklyStage
            ? weeklyEarnedCoins
            : isSpecialChallengeAccepted
            ? 120
            : 60
        }
        movesCount={movesCount}
        isRushOrderWon={isRushWon}
        onNextLevel={handleNextLevel}
        isWeeklyMode={!!activeWeeklyStage}
        weeklyStageTitle={activeWeeklyStage?.title}
        weeklyPointsEarned={weeklyPointsWon}
        specialItemReward={activeWeeklyStage?.specialItemReward}
        onViewLeaderboard={() => {
          setIsVictoryOpen(false);
          setIsNeighborhoodOpen(true);
        }}
      />
    </main>
  );
}
