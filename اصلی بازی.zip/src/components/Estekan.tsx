import React, { useRef } from 'react';
import { Cup } from '../types';
import { DRINKS_DATA } from '../constants/drinks';
import { toPersianDigits } from '../utils/persianNumbers';

interface EstekanProps {
  cup: Cup;
  cupIndex?: number;
  isSelected: boolean;
  isHintSource?: boolean;
  isHintTarget?: boolean;
  isPouring?: boolean;
  pourDirection?: 'left' | 'right';
  colorblindMode: boolean;
  isValidTarget?: boolean;
  isInvalidDimmed?: boolean;
  onClick?: () => void;
  onDoubleTap?: () => void;
  onCupClick?: (index: number) => void;
  onCupDoubleTap?: (index: number) => void;
  hasGoldenSugarCube?: boolean;
}

export const Estekan: React.FC<EstekanProps> = React.memo(({
  cup,
  cupIndex,
  isSelected,
  isHintSource,
  isHintTarget,
  isPouring,
  pourDirection = 'right',
  colorblindMode,
  isValidTarget = false,
  isInvalidDimmed = false,
  onClick,
  onDoubleTap,
  onCupClick,
  onCupDoubleTap,
  hasGoldenSugarCube,
}) => {
  const lastTapRef = useRef<number>(0);

  const isFullAndPure =
    cup.layers.length === 4 && cup.layers.every((l) => l === cup.layers[0]);

  // Exact Iranian Waisted Curve Path
  const cupPathD =
    'M 10,8 C 25,14 55,14 70,8 C 66,38 54,58 58,85 C 62,110 68,122 60,132 C 48,138 32,138 20,132 C 12,122 18,110 22,85 C 26,58 14,38 10,8 Z';

  const layerHeight = 28;
  const liquidBaseY = 132;

  // Active pouring rotation tilt or selection lift
  const tiltClass = isPouring
    ? pourDirection === 'right'
      ? 'rotate-50 translate-x-6 -translate-y-12 z-50 scale-110 drop-shadow-[0_15px_30px_rgba(245,158,11,0.6)]'
      : '-rotate-50 -translate-x-6 -translate-y-12 z-50 scale-110 drop-shadow-[0_15px_30px_rgba(245,158,11,0.6)]'
    : isSelected
    ? '-translate-y-6 z-30 scale-105'
    : isFullAndPure
    ? 'translate-y-0 scale-95 opacity-90 transition-all duration-300'
    : isValidTarget
    ? 'translate-y-0 scale-102 ring-2 ring-amber-400/80 rounded-2xl shadow-[0_0_16px_rgba(245,158,11,0.7)] animate-pulse'
    : isInvalidDimmed
    ? 'translate-y-0 opacity-75'
    : 'translate-y-0 z-20';

  const topLayer = cup.layers[cup.layers.length - 1];
  const topDrink = topLayer ? DRINKS_DATA[topLayer] : null;

  const handleClick = () => {
    if (isFullAndPure || cup.isFrozenSolid) return;

    const now = Date.now();
    if (now - lastTapRef.current < 300) {
      // Double tap detected!
      lastTapRef.current = 0;
      if (onCupDoubleTap && cupIndex !== undefined) {
        onCupDoubleTap(cupIndex);
        return;
      }
      if (onDoubleTap) {
        onDoubleTap();
        return;
      }
    }
    lastTapRef.current = now;
    if (onCupClick && cupIndex !== undefined) {
      onCupClick(cupIndex);
    } else if (onClick) {
      onClick();
    }
  };

  return (
    <div
      onClick={handleClick}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (!isFullAndPure && !cup.isFrozenSolid && (e.key === 'Enter' || e.key === ' ')) {
          handleClick();
        }
      }}
      className={`relative flex flex-col items-center justify-end select-none group touch-manipulation transition-transform duration-200 cursor-pointer w-[68px] h-[126px] sm:w-[80px] sm:h-[148px] ${tiltClass} ${
        cup.isFrozenSolid ? 'cursor-not-allowed filter grayscale-[0.2]' : ''
      }`}
      aria-label={`استکان ${cup.id + 1} با ${cup.layers.length} لایه`}
    >
      {/* Contact shadow on copper tray */}
      <div className="absolute -bottom-1.5 w-14 sm:w-16 h-3.5 sm:h-4 bg-[#1E0E05]/45 rounded-full filter blur-[3px] pointer-events-none" />

      {/* Royal Persian Coaster / Saucer left on tray when cup is served */}
      {isFullAndPure && (
        <div className="absolute -bottom-2 w-20 h-6 flex items-center justify-center pointer-events-none z-10">
          {/* Detailed Persian Saucer (نعلبکی) with Engraved Rim */}
          <div className="relative w-18 h-5 rounded-[50%] bg-gradient-to-r from-[#5B2E10] via-[#C06A26] to-[#5B2E10] border-2 border-[#FDE047] shadow-[0_4px_10px_rgba(0,0,0,0.8)] flex items-center justify-center">
            <div className="w-13 h-3 rounded-[50%] border border-amber-200/70 bg-gradient-to-r from-[#321706] via-[#5C2E11] to-[#321706] flex items-center justify-center">
              <span className="text-[7px] text-yellow-300 font-bold font-lalezar">✓ تحویل</span>
            </div>
            {/* Traditional Sugar Cube beside the glass on the saucer */}
            <div
              className="absolute -right-2 top-0.5 w-3.5 h-3.5 rounded-sm bg-gradient-to-br from-white via-amber-50 to-amber-100 border border-amber-200 shadow-sm flex items-center justify-center rotate-12"
              title="قند پهلو"
            >
              <div className="w-1.5 h-1.5 bg-white/80 rounded-xs" />
            </div>
          </div>
        </div>
      )}

      {/* Cooling Tea Timer Countdown Badge */}
      {cup.coolingMovesLeft !== undefined && !cup.isFrozenSolid && (
        <div className="absolute -top-4 z-40 px-2 py-0.5 rounded-full bg-gradient-to-r from-sky-900 to-cyan-950 border border-sky-300 text-sky-100 font-lalezar text-[10px] shadow-lg animate-pulse flex items-center gap-1">
          <span>❄️</span>
          <span>{toPersianDigits(cup.coolingMovesLeft)} حرکت</span>
        </div>
      )}

      {/* Cup Visual Body Wrapper */}
      <div className="relative flex flex-col items-center justify-end w-full h-full">
        {/* Active Pouring Stream */}
        {isPouring && topDrink && (
          <div
            className={`absolute top-12 pointer-events-none z-50 ${
              pourDirection === 'right' ? 'left-16' : 'right-16'
            }`}
          >
            <svg width="60" height="110" viewBox="0 0 60 110" fill="none" className="overflow-visible">
              <defs>
                <linearGradient id="stream-gold-grad" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#FFFBEB" />
                  <stop offset="25%" stopColor="#FDE047" />
                  <stop offset="70%" stopColor="#F59E0B" />
                  <stop offset="100%" stopColor="#D97706" />
                </linearGradient>
                <filter id="stream-glow" x="-20%" y="-20%" width="140%" height="140%">
                  <feGaussianBlur stdDeviation="3" result="blur" />
                  <feComposite in="SourceGraphic" in2="blur" operator="over" />
                </filter>
              </defs>

              <path
                d={pourDirection === 'right' ? 'M 0 0 C 35 30, 42 70, 50 110' : 'M 60 0 C 25 30, 18 70, 10 110'}
                stroke="#F59E0B"
                strokeWidth="10"
                strokeLinecap="round"
                opacity="0.5"
                filter="url(#stream-glow)"
              />
              <path
                d={pourDirection === 'right' ? 'M 0 0 C 35 30, 42 70, 50 110' : 'M 60 0 C 25 30, 18 70, 10 110'}
                stroke="url(#stream-gold-grad)"
                strokeWidth="6"
                strokeLinecap="round"
              />
            </svg>
          </div>
        )}

        {/* 3D Glass SVG Container */}
        <svg
          viewBox="0 0 80 140"
          className="w-full h-full max-h-[140px] overflow-visible filter drop-shadow-[0_8px_12px_rgba(0,0,0,0.5)]"
        >
          <defs>
            <clipPath id={`cup-inner-clip-${cup.id}`}>
              <path d={cupPathD} />
            </clipPath>

            <linearGradient id={`glass-glare-${cup.id}`} x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.4" />
              <stop offset="20%" stopColor="#FFFFFF" stopOpacity="0.1" />
              <stop offset="65%" stopColor="#FFFFFF" stopOpacity="0.02" />
              <stop offset="90%" stopColor="#FFFFFF" stopOpacity="0.25" />
              <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0.5" />
            </linearGradient>

            <filter id={`glass-blur-${cup.id}`}>
              <feGaussianBlur stdDeviation="0.8" />
            </filter>

            {cup.layers.map((layer, idx) => {
              const drink = DRINKS_DATA[layer];
              if (!drink) return null;
              return (
                <linearGradient
                  key={`grad-${cup.id}-${idx}`}
                  id={`liquid-grad-${cup.id}-${idx}`}
                  x1="0"
                  y1="0"
                  x2="0"
                  y2="1"
                >
                  <stop offset="0%" stopColor={drink.gradient[0]} />
                  <stop offset="100%" stopColor={drink.gradient[1]} />
                </linearGradient>
              );
            })}
          </defs>

          {/* Liquid Layers inside Glass */}
          <g clipPath={`url(#cup-inner-clip-${cup.id})`}>
            {cup.layers.map((layer, index) => {
              const drink = DRINKS_DATA[layer];
              if (!drink) return null;
              const layerY = liquidBaseY - (index + 1) * layerHeight;

              return (
                <g key={index}>
                  {/* Base Liquid Fill */}
                  <rect
                    x="0"
                    y={layerY}
                    width="80"
                    height={layerHeight + 2}
                    fill={`url(#liquid-grad-${cup.id}-${index})`}
                  />

                  {/* Frothy Doogh Top */}
                  {drink.textureType === 'foam' && index === cup.layers.length - 1 && (
                    <g fill="#FFFFFF" opacity="0.98">
                      <rect x="0" y={layerY} width="80" height="7" fill="#FFFFFF" />
                      <circle cx="20" cy={layerY + 2} r="2.5" />
                      <circle cx="35" cy={layerY + 2.5} r="3" />
                      <circle cx="50" cy={layerY + 2} r="2.7" />
                      <circle cx="65" cy={layerY + 2.8} r="2.2" />
                    </g>
                  )}

                  {/* Clear Tea meniscus */}
                  {drink.textureType === 'clear' && index === cup.layers.length - 1 && (
                    <ellipse cx="40" cy={layerY} rx="24" ry="2.5" fill="#2E0101" opacity="0.6" />
                  )}

                  {/* Saffron Sparkle */}
                  {drink.textureType === 'sparkle' && (
                    <g fill="#FFFFFF" opacity="0.85">
                      <circle cx="35" cy={layerY + 12} r="1.3" />
                      <circle cx="48" cy={layerY + 18} r="1.5" />
                    </g>
                  )}

                  {/* Meniscus division line */}
                  <line
                    x1="10"
                    y1={layerY}
                    x2="70"
                    y2={layerY}
                    stroke="#FFFFFF"
                    strokeOpacity="0.3"
                    strokeWidth="0.8"
                  />

                  {/* Steamy Mystery Layer Mask: "?" for steamy mystery glasses */}
                  {cup.isSteamy && index < cup.layers.length - 1 && (
                    <g>
                      <rect
                        x="0"
                        y={layerY}
                        width="80"
                        height={layerHeight}
                        fill="#CBD5E1"
                        fillOpacity="0.94"
                      />
                      <text
                        x="40"
                        y={layerY + 19}
                        textAnchor="middle"
                        fill="#334155"
                        fontSize="14"
                        fontWeight="900"
                      >
                        ?
                      </text>
                    </g>
                  )}

                  {/* Sugar Cube Blocker Layer Graphic */}
                  {cup.hasSugarCubeBlocker && index === cup.layers.length - 1 && (
                    <g className="animate-pulse">
                      <rect
                        x="27"
                        y={layerY - 14}
                        width="26"
                        height="18"
                        rx="3"
                        fill="#FFFFFF"
                        stroke="#E2E8F0"
                        strokeWidth="2"
                      />
                      <line x1="27" y1={layerY - 5} x2="53" y2={layerY - 5} stroke="#CBD5E1" strokeWidth="1" />
                      <circle cx="34" cy={layerY - 9} r="1.5" fill="#94A3B8" />
                      <circle cx="46" cy={layerY - 9} r="1.5" fill="#94A3B8" />
                    </g>
                  )}

                  {/* Colorblind Initial Letter */}
                  {colorblindMode && (!cup.isSteamy || index === cup.layers.length - 1) && (
                    <text
                      x="40"
                      y={layerY + 19}
                      textAnchor="middle"
                      fill={layer === 'doogh' ? '#1F2937' : '#FFFFFF'}
                      fontSize="13"
                      fontWeight="800"
                      fontFamily="Lalezar, Vazirmatn, sans-serif"
                      style={{ textShadow: '0 1px 2px rgba(0,0,0,0.7)' }}
                    >
                      {drink.char}
                    </text>
                  )}
                </g>
              );
            })}
          </g>

          {/* Frozen Solid Ice Overlay */}
          {cup.isFrozenSolid && (
            <g>
              <path
                d={cupPathD}
                fill="#0284C7"
                fillOpacity="0.75"
                stroke="#BAE6FD"
                strokeWidth="2.5"
              />
              <path
                d="M 25 40 L 55 100 M 55 40 L 25 100 M 40 30 L 40 110"
                stroke="#FFFFFF"
                strokeWidth="1.5"
                strokeOpacity="0.7"
                strokeDasharray="4 2"
              />
              <text
                x="40"
                y="74"
                textAnchor="middle"
                fill="#FFFFFF"
                fontSize="12"
                fontWeight="900"
                fontFamily="Lalezar, sans-serif"
              >
                قفل یخ‌زده
              </text>
            </g>
          )}

          {/* 3D Glass Outer Contour */}
          <path
            d={cupPathD}
            fill={`url(#glass-glare-${cup.id})`}
            stroke="#F8FAFC"
            strokeOpacity="0.82"
            strokeWidth="1.8"
          />

          {/* Specular highlights */}
          <path
            d="M 14,14 C 18,38 28,58 24,85 C 20,110 14,122 22,130"
            stroke="#FFFFFF"
            strokeOpacity="0.75"
            strokeWidth="2.5"
            strokeLinecap="round"
            filter={`url(#glass-blur-${cup.id})`}
          />
          <path
            d="M 66,14 C 62,38 52,58 56,85 C 60,110 66,122 58,130"
            stroke="#FFFFFF"
            strokeOpacity="0.35"
            strokeWidth="1.4"
            strokeLinecap="round"
          />

          {/* Golden Rim Seal on completed glass (Visual Closure) */}
          {isFullAndPure ? (
            <g>
              <ellipse
                cx="40"
                cy="8"
                rx="30"
                ry="5"
                fill="#F59E0B"
                fillOpacity="0.8"
                stroke="#FDE047"
                strokeOpacity="1"
                strokeWidth="2.2"
              />
              <ellipse
                cx="40"
                cy="8"
                rx="20"
                ry="3"
                fill="#D97706"
                stroke="#FFFBEB"
                strokeWidth="1"
              />
            </g>
          ) : (
            <ellipse
              cx="40"
              cy="8"
              rx="30"
              ry="5"
              fill="#FFFFFF"
              fillOpacity="0.25"
              stroke="#FFFFFF"
              strokeOpacity="0.92"
              strokeWidth="1.8"
            />
          )}
        </svg>

        {/* Completed Seal Badge on Top */}
        {isFullAndPure && (
          <div className="absolute -top-3 px-2 py-0.5 rounded-full bg-gradient-to-r from-amber-500 to-yellow-400 border border-yellow-200 text-amber-950 font-lalezar text-[10px] font-bold shadow-md flex items-center gap-1">
            <span>✨</span>
            <span>تکمیل</span>
          </div>
        )}
      </div>
    </div>
  );
});
