import React from 'react';
import { RotateCcw, Plus, Lightbulb, Coffee } from 'lucide-react';
import { toPersianDigits } from '../utils/persianNumbers';

interface ActionBarProps {
  canUndo: boolean;
  undoCount: number;
  canAddExtraCup: boolean;
  isPenaltyLocked?: boolean;
  onUndo: () => void;
  onAddCup: () => void;
  onHint: () => void;
  onOpenFortune: () => void;
}

// 12-Petal Scalloped Golden Floral Medallion Outer Path
const SCALLOPED_12_PETAL_PATH = `
  M 30 2
  C 34 2, 36 6, 40 7
  C 44 8, 48 6, 51 9
  C 54 12, 53 17, 56 21
  C 58 24, 62 27, 62 31
  C 62 35, 58 38, 56 42
  C 54 45, 55 50, 52 53
  C 48 56, 44 54, 40 55
  C 36 57, 34 60, 30 60
  C 26 60, 24 57, 20 55
  C 16 54, 12 56, 8 53
  C 6 50, 7 45, 5 42
  C 2 38, -2 35, -2 31
  C -2 27, 2 24, 4 21
  C 7 17, 6 12, 9 9
  C 12 6, 16 8, 20 7
  C 24 6, 26 2, 30 2 Z
`;

export const ActionBar: React.FC<ActionBarProps> = ({
  canUndo,
  undoCount,
  canAddExtraCup,
  isPenaltyLocked = false,
  onUndo,
  onAddCup,
  onHint,
  onOpenFortune,
}) => {
  return (
    <footer className="relative w-full px-3 py-2 z-30 select-none flex items-center justify-between gap-2 max-h-[22vh]">
      {/* 3 Scalloped 12-Petal Medallions (برگشت، استکان جدید، راهنما) */}
      <div className="flex items-center gap-1.5 sm:gap-3">
        {/* 1. Persian Turquoise Scalloped Medallion (برگشت) */}
        <div className="flex flex-col items-center">
          <button
            onClick={onUndo}
            disabled={!canUndo}
            className={`relative w-11 h-11 sm:w-14 sm:h-14 rounded-full flex items-center justify-center transition-transform active:scale-90 ${
              canUndo
                ? 'cursor-pointer hover:brightness-110 drop-shadow-[0_8px_16px_rgba(13,148,136,0.65)]'
                : 'opacity-50 cursor-not-allowed'
            }`}
            title="برگشت به حرکت قبل"
          >
            <svg viewBox="0 0 60 62" className="absolute inset-0 w-full h-full overflow-visible">
              <defs>
                <linearGradient id="scallop-gold-rim" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#FFFBEB" />
                  <stop offset="30%" stopColor="#FBBF24" />
                  <stop offset="70%" stopColor="#D97706" />
                  <stop offset="100%" stopColor="#92400E" />
                </linearGradient>
                <linearGradient id="turquoise-inner-medallion" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#2DD4BF" />
                  <stop offset="45%" stopColor="#0D9488" />
                  <stop offset="100%" stopColor="#044E46" />
                </linearGradient>
              </defs>
              <path
                d={SCALLOPED_12_PETAL_PATH}
                fill="url(#scallop-gold-rim)"
                stroke="#B45309"
                strokeWidth="1.5"
                className="filter drop-shadow-[0_3px_5px_rgba(0,0,0,0.5)]"
              />
              <circle cx="30" cy="31" r="21" fill="url(#turquoise-inner-medallion)" stroke="#CCFBF1" strokeWidth="1.5" />
            </svg>

            {/* 3D White Curved Undo Arrow */}
            <div className="relative z-10 text-white flex items-center justify-center filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.6)]">
              <RotateCcw className="w-4 h-4 sm:w-5 sm:h-5 stroke-[2.8]" />
            </div>
          </button>
          <span className="font-lalezar text-[10px] sm:text-xs text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.95)] mt-1 tracking-wide">
            برگشت {undoCount > 0 && `(${toPersianDigits(undoCount)})`}
          </span>
        </div>

        {/* 2. Emerald-Teal Scalloped Medallion (استکان جدید) */}
        <div className="flex flex-col items-center">
          <button
            onClick={onAddCup}
            disabled={!canAddExtraCup || isPenaltyLocked}
            className={`relative w-11 h-11 sm:w-14 sm:h-14 rounded-full flex items-center justify-center transition-transform active:scale-90 ${
              isPenaltyLocked
                ? 'opacity-60 cursor-not-allowed filter grayscale-[0.4]'
                : canAddExtraCup
                ? 'cursor-pointer hover:brightness-110 drop-shadow-[0_8px_16px_rgba(20,184,166,0.65)]'
                : 'opacity-50 cursor-not-allowed'
            }`}
            title={isPenaltyLocked ? 'استکان کمکی در توقیف نسیه عمو بهمن است!' : 'افزودن استکان کمکی جدید'}
          >
            <svg viewBox="0 0 60 62" className="absolute inset-0 w-full h-full overflow-visible">
              <defs>
                <linearGradient id="green-inner-medallion" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#34D399" />
                  <stop offset="50%" stopColor="#059669" />
                  <stop offset="100%" stopColor="#064E3B" />
                </linearGradient>
              </defs>
              <path
                d={SCALLOPED_12_PETAL_PATH}
                fill="url(#scallop-gold-rim)"
                stroke="#B45309"
                strokeWidth="1.5"
                className="filter drop-shadow-[0_3px_5px_rgba(0,0,0,0.5)]"
              />
              <circle cx="30" cy="31" r="21" fill="url(#green-inner-medallion)" stroke="#DCFCE7" strokeWidth="1.5" />
            </svg>

            {/* White Estekan Icon with + badge or red lock if penalty */}
            <div className="relative z-10 flex items-center justify-center text-white filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.6)]">
              {isPenaltyLocked ? (
                <span className="text-xs sm:text-sm">🔒</span>
              ) : (
                <div className="w-3.5 h-5 sm:w-4 sm:h-6 border-2 border-white rounded-t-sm rounded-b-md relative flex items-center justify-center">
                  <Plus className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-white stroke-[3.5] -mr-3 -mt-2.5 bg-teal-700 rounded-full" />
                </div>
              )}
            </div>
          </button>
          <span className="font-lalezar text-[10px] sm:text-xs text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.95)] mt-1 tracking-wide">
            {isPenaltyLocked ? 'توقیف نسیه' : 'استکان جدید'}
          </span>
        </div>

        {/* 3. Amber Gold Scalloped Medallion (راهنما) */}
        <div className="flex flex-col items-center">
          <button
            onClick={onHint}
            className="relative w-11 h-11 sm:w-14 sm:h-14 rounded-full flex items-center justify-center cursor-pointer hover:brightness-110 drop-shadow-[0_8px_16px_rgba(245,158,11,0.75)] transition-transform active:scale-90"
            title="راهنمای هوشمند A*"
          >
            <svg viewBox="0 0 60 62" className="absolute inset-0 w-full h-full overflow-visible">
              <defs>
                <linearGradient id="yellow-inner-medallion" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#FEF08A" />
                  <stop offset="50%" stopColor="#F59E0B" />
                  <stop offset="100%" stopColor="#B45309" />
                </linearGradient>
              </defs>
              <path
                d={SCALLOPED_12_PETAL_PATH}
                fill="url(#scallop-gold-rim)"
                stroke="#B45309"
                strokeWidth="1.5"
                className="filter drop-shadow-[0_3px_5px_rgba(0,0,0,0.5)]"
              />
              <circle cx="30" cy="31" r="21" fill="url(#yellow-inner-medallion)" stroke="#FFFBEB" strokeWidth="1.5" />
            </svg>

            {/* Glowing Lightbulb Icon */}
            <div className="relative z-10 flex items-center justify-center text-amber-950 filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)]">
              <Lightbulb className="w-4 h-4 sm:w-5 sm:h-5 fill-amber-950 stroke-amber-950 stroke-[2]" />
            </div>
          </button>
          <span className="font-lalezar text-[10px] sm:text-xs text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.95)] mt-1 tracking-wide">
            راهنما
          </span>
        </div>
      </div>

      {/* 4. Ornate Persian Turquoise & Burnt Wood Button: فال چای */}
      <button
        onClick={onOpenFortune}
        className="flex-1 max-w-[125px] sm:max-w-[155px] h-11 sm:h-13 px-2 sm:px-3 rounded-2xl bg-gradient-to-r from-[#005B60] via-[#0E8A8A] to-[#1D4A48] border-2 border-[#FDE047] text-white shadow-[0_8px_18px_rgba(0,0,0,0.7)] flex items-center justify-center gap-1.5 sm:gap-2 hover:brightness-110 active:scale-95 transition-all group"
      >
        <div className="flex flex-col items-start text-right min-w-0">
          <span className="font-lalezar text-xs sm:text-sm text-[#FEF08A] tracking-wider drop-shadow-[0_1px_3px_rgba(0,0,0,0.9)] truncate">
            فال چای
          </span>
          <span className="text-[8px] sm:text-[9px] text-teal-200/90 -mt-0.5 font-vazir truncate">
            حکمت و غزل
          </span>
        </div>
        <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-amber-400/25 border border-amber-300 flex items-center justify-center group-hover:rotate-12 transition-transform shadow-inner shrink-0">
          <Coffee className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-[#FDE047]" />
        </div>
      </button>
    </footer>
  );
};
