import React, { useState } from 'react';
import { X, UserCheck, ShieldCheck, Sparkles, AlertCircle } from 'lucide-react';
import { PlayerProfile } from '../../types';
import { registerPlayerOnServer } from '../../services/backendApi';
import { soundEngine } from '../../audio/SoundEngine';

interface RegisterPlayerModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentProfile: PlayerProfile;
  onProfileUpdated: (profile: PlayerProfile) => void;
}

export const RegisterPlayerModal: React.FC<RegisterPlayerModalProps> = ({
  isOpen,
  onClose,
  currentProfile,
  onProfileUpdated,
}) => {
  const [firstName, setFirstName] = useState(currentProfile.firstName || '');
  const [lastName, setLastName] = useState(currentProfile.lastName || '');
  const [nickname, setNickname] = useState(currentProfile.nickname || '');
  const [isLoading, setIsLoading] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firstName.trim() || !lastName.trim()) {
      setFeedback({
        type: 'error',
        message: 'لطفاً نام و نام خانوادگی خود را کامل وارد نمایید.',
      });
      return;
    }

    setIsLoading(true);
    setFeedback(null);
    soundEngine.playClick();

    try {
      const res = await registerPlayerOnServer(firstName, lastName, nickname);
      setIsLoading(false);

      const updated: PlayerProfile = {
        ...currentProfile,
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        nickname: nickname.trim() || `${firstName.trim()} ${lastName.trim()}`,
        isRegistered: true,
        registeredAt: Date.now(),
      };
      onProfileUpdated(updated);

      setFeedback({
        type: 'success',
        message: res.message || 'مشخصات شما با موفقیت ثبت شد!',
      });

      soundEngine.playSanturVictory();
      setTimeout(() => {
        onClose();
      }, 1400);
    } catch {
      setIsLoading(false);
      setFeedback({
        type: 'error',
        message: 'خطایی رخ داد، اما نام شما به صورت محلی ذخیره شد.',
      });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-[#180A03]/85 backdrop-blur-sm animate-fade-in select-none">
      {/* Persian Tile Frame */}
      <div className="relative w-full max-w-sm rounded-[32px] p-2 bg-gradient-to-b from-[#0D9488] via-[#096057] to-[#04332F] border-4 border-[#5EEAD4] shadow-[0_15px_50px_rgba(0,0,0,0.9)] text-[#FFFBF0]">
        {/* Close Button */}
        <button
          onClick={() => {
            soundEngine.playClick();
            onClose();
          }}
          className="absolute -top-3 -right-3 z-30 w-9 h-9 rounded-full bg-gradient-to-b from-rose-500 to-red-700 hover:brightness-110 text-white flex items-center justify-center border-2 border-white shadow-xl transition-transform active:scale-90 cursor-pointer"
          title="بستن"
        >
          <X className="w-5 h-5 stroke-[2.5]" />
        </button>

        {/* Content Box */}
        <div className="rounded-[26px] p-4 bg-gradient-to-b from-[#FFFBF0] via-[#FDF8E7] to-[#F7EDCE] border-2 border-[#D97706]/40 flex flex-col text-[#2C1A11]">
          {/* Header */}
          <div className="text-center mb-3">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-amber-100 border-2 border-amber-500 text-amber-700 mb-1 shadow-inner">
              <UserCheck className="w-6 h-6 stroke-[2.5]" />
            </div>
            <h2 className="font-lalezar text-lg text-[#3E2211]">
              ثبت‌نام اوستای چایخانه
            </h2>
            <p className="text-[11px] text-amber-900/80 font-vazir mt-0.5 font-medium">
              بدون نیاز به رمز عبور و لاگین؛ فقط نام و فامیلی برای تابلوی رتبه‌بندی
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-[#42220F] mb-1 font-vazir text-right">
                نام: <span className="text-rose-600">*</span>
              </label>
              <input
                type="text"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                placeholder="مثلاً: سهراب"
                className="w-full px-3 py-2 text-sm rounded-xl bg-white border-2 border-[#C9A26B] text-[#2C1A11] focus:outline-none focus:border-teal-600 transition-colors text-right font-vazir shadow-sm"
                required
                maxLength={40}
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#42220F] mb-1 font-vazir text-right">
                نام خانوادگی: <span className="text-rose-600">*</span>
              </label>
              <input
                type="text"
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                placeholder="مثلاً: مرادی"
                className="w-full px-3 py-2 text-sm rounded-xl bg-white border-2 border-[#C9A26B] text-[#2C1A11] focus:outline-none focus:border-teal-600 transition-colors text-right font-vazir shadow-sm"
                required
                maxLength={40}
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#42220F] mb-1 font-vazir text-right">
                لقب یا نام در تابلوی محله (اختیاری):
              </label>
              <input
                type="text"
                value={nickname}
                onChange={(e) => setNickname(e.target.value)}
                placeholder={firstName && lastName ? `${firstName} ${lastName}` : 'مثلاً: داش سهراب'}
                className="w-full px-3 py-2 text-sm rounded-xl bg-white border-2 border-[#C9A26B] text-[#2C1A11] focus:outline-none focus:border-teal-600 transition-colors text-right font-vazir shadow-sm"
                maxLength={50}
              />
            </div>

            {/* Privacy Note */}
            <div className="bg-amber-100/70 p-2.5 rounded-xl border border-amber-300 text-[10px] text-amber-950 flex items-start gap-1.5 font-vazir leading-relaxed">
              <ShieldCheck className="w-4 h-4 text-teal-700 shrink-0 mt-0.5" />
              <span>
                شناسه دستگاه شما به صورت خودکار به نام و فامیلی شما متصل می‌شود. تمام امتیازها و رتبه شما در سرور ذخیره می‌گردد.
              </span>
            </div>

            {/* Feedback alert */}
            {feedback && (
              <div
                className={`p-2 rounded-xl text-xs font-vazir font-semibold flex items-center gap-1.5 ${
                  feedback.type === 'success'
                    ? 'bg-emerald-100 text-emerald-900 border border-emerald-400'
                    : 'bg-rose-100 text-rose-900 border border-rose-400'
                }`}
              >
                {feedback.type === 'success' ? (
                  <Sparkles className="w-4 h-4 text-emerald-700" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-rose-700" />
                )}
                <span>{feedback.message}</span>
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-2.5 rounded-2xl bg-gradient-to-r from-amber-600 via-amber-500 to-yellow-500 hover:from-amber-500 hover:to-yellow-400 text-amber-950 font-lalezar text-base shadow-lg border border-amber-200 transition-transform active:scale-95 flex items-center justify-center gap-2 cursor-pointer font-bold"
            >
              {isLoading ? (
                <span>در حال ثبت...</span>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>ثبت و ورود به جدول رتبه‌بندی</span>
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
