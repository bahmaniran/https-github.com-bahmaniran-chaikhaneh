import React, { useState, useEffect } from 'react';
import {
  X,
  Calendar,
  Clock,
  Trophy,
  Award,
  Sparkles,
  Lock,
  CheckCircle2,
  Play,
  Gift,
  ChevronLeft,
  Flame,
  Star,
  Users,
} from 'lucide-react';
import { WeeklyChallengeStage, WeeklyChallengeState } from '../../types';
import {
  getWeeklyChallengeState,
  getWeeklyStagesForCurrentWeek,
  getTimeRemainingUntilMonday,
  claimWeeklyGrandChest,
} from '../../game/WeeklyChallengeService';
import { formatPersianCoins, toPersianDigits } from '../../utils/persianNumbers';
import { soundEngine } from '../../audio/SoundEngine';

interface WeeklyChallengeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStartStage: (stage: WeeklyChallengeStage) => void;
  onOpenLeaderboard: () => void;
  onRewardsClaimed?: (bonusCoins: number) => void;
}

interface WeeklyStageCardProps {
  stage: WeeklyChallengeStage;
  index: number;
  isCompleted: boolean;
  isLocked: boolean;
  isNextAvailable: boolean;
  onSelect: (stage: WeeklyChallengeStage) => void;
}

const WeeklyStageCard: React.FC<WeeklyStageCardProps> = React.memo(({
  stage,
  index,
  isCompleted,
  isLocked,
  isNextAvailable,
  onSelect,
}) => {
  return (
    <div
      className={`p-3 rounded-2xl border transition-all ${
        isCompleted
          ? 'bg-gradient-to-r from-emerald-950/40 via-[#182C1F]/50 to-emerald-950/40 border-emerald-500/50'
          : isNextAvailable
          ? 'bg-gradient-to-r from-[#3D2010] via-[#2D1609] to-[#3D2010] border-amber-400 shadow-[0_0_12px_rgba(245,158,11,0.25)] ring-1 ring-amber-400/40'
          : 'bg-[#180C06] border-[#381B0D] opacity-70'
      }`}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-start gap-2.5">
          {/* Stage Number Badge */}
          <div
            className={`w-7 h-7 rounded-xl flex items-center justify-center font-lalezar text-xs shrink-0 mt-0.5 ${
              isCompleted
                ? 'bg-emerald-500 text-emerald-950 font-bold'
                : isNextAvailable
                ? 'bg-gradient-to-tr from-amber-500 to-yellow-300 text-amber-950 font-bold shadow'
                : 'bg-[#2E160A] text-amber-400/60'
            }`}
          >
            {isCompleted ? <CheckCircle2 className="w-4 h-4" /> : toPersianDigits(stage.id)}
          </div>

          <div>
            <div className="flex items-center gap-1.5 flex-wrap">
              <h4 className="font-lalezar text-xs text-amber-100">
                {stage.title}
              </h4>
              {stage.modifierLabel && (
                <span className="text-[9px] px-1.5 py-0.2 rounded-md bg-amber-900/60 text-amber-300 border border-amber-700/60 font-vazir">
                  {stage.modifierLabel}
                </span>
              )}
            </div>
            <p className="text-[10px] text-amber-200/70 font-vazir mt-0.5 leading-snug">
              {stage.description}
            </p>

            {/* Rewards Badges */}
            <div className="flex items-center gap-2 mt-2 flex-wrap text-[10px] font-vazir">
              <span className="inline-flex items-center gap-1 bg-[#120703] px-2 py-0.5 rounded-lg border border-amber-800/80 text-yellow-300 font-lalezar">
                <span>+{formatPersianCoins(stage.rewardCoins)}</span>
                <span className="text-[9px]">★</span>
              </span>

              <span className="inline-flex items-center gap-1 bg-[#120703] px-2 py-0.5 rounded-lg border border-teal-800/80 text-teal-300 font-lalezar">
                <span>+{toPersianDigits(stage.rewardWeeklyScore)}</span>
                <span>امتیاز لیگ</span>
              </span>

              {stage.specialItemReward && (
                <span className="inline-flex items-center gap-1 bg-amber-950/80 px-2 py-0.5 rounded-lg border border-amber-600/70 text-amber-200 text-[9px]">
                  <span>{stage.badgeIcon || '🎁'}</span>
                  <span>{stage.specialItemReward}</span>
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Action Button */}
        <div className="shrink-0">
          {isLocked ? (
            <div className="w-8 h-8 rounded-xl bg-[#221008] border border-[#3E1E0F] flex items-center justify-center text-amber-400/40">
              <Lock className="w-3.5 h-3.5" />
            </div>
          ) : (
            <button
              onClick={() => onSelect(stage)}
              className={`px-3 py-1.5 rounded-xl font-lalezar text-xs flex items-center gap-1 transition-all active:scale-95 cursor-pointer shadow-md ${
                isCompleted
                  ? 'bg-[#2A180E] hover:bg-[#3E2315] text-amber-300 border border-amber-600/60'
                  : 'bg-gradient-to-r from-amber-500 to-yellow-400 hover:brightness-110 text-amber-950 font-bold border border-yellow-200'
              }`}
            >
              <Play className="w-3 h-3 fill-current" />
              <span>{isCompleted ? 'تکرار' : 'شروع'}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
});

WeeklyStageCard.displayName = 'WeeklyStageCard';

export const WeeklyChallengeModal: React.FC<WeeklyChallengeModalProps> = React.memo(({
  isOpen,
  onClose,
  onStartStage,
  onOpenLeaderboard,
  onRewardsClaimed,
}) => {
  const [weeklyState, setWeeklyState] = useState<WeeklyChallengeState>(getWeeklyChallengeState());
  const [stages, setStages] = useState<WeeklyChallengeStage[]>(getWeeklyStagesForCurrentWeek());
  const [timeRemaining, setTimeRemaining] = useState(getTimeRemainingUntilMonday());
  const [chestMessage, setChestMessage] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;

    // Refresh state on open
    setWeeklyState(getWeeklyChallengeState());
    setStages(getWeeklyStagesForCurrentWeek());
    setTimeRemaining(getTimeRemainingUntilMonday());

    // Timer tick every second
    const interval = setInterval(() => {
      setTimeRemaining(getTimeRemainingUntilMonday());
    }, 1000);

    return () => clearInterval(interval);
  }, [isOpen]);

  if (!isOpen) return null;

  const completedCount = weeklyState.completedStageIds.length;
  const isGrandUnlocked = completedCount === 5;

  const handleClaimChest = () => {
    soundEngine.playCoin();
    const res = claimWeeklyGrandChest();
    if (res.success) {
      setWeeklyState(getWeeklyChallengeState());
      setChestMessage(res.message);
      if (onRewardsClaimed) {
        onRewardsClaimed(res.bonusCoins);
      }
    }
  };

  const handleStageSelect = React.useCallback((stage: WeeklyChallengeStage) => {
    soundEngine.playClick();
    onClose();
    onStartStage(stage);
  }, [onClose, onStartStage]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-[#180A03]/85 backdrop-blur-sm animate-fade-in select-none">
      <div className="relative w-full max-w-md max-h-[92vh] overflow-y-auto rounded-[32px] p-5 bg-gradient-to-b from-[#3A1E0E] via-[#2C160A] to-[#1E0E06] border-4 border-[#F59E0B] shadow-[0_10px_40px_rgba(245,158,11,0.3)] text-[#FFFBF0]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#522E18]">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-600 via-amber-400 to-yellow-300 p-0.5 flex items-center justify-center shadow-lg">
              <div className="w-full h-full rounded-full bg-[#200F05] flex items-center justify-center text-amber-300">
                <Calendar className="w-4 h-4" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="font-lalezar text-base text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-amber-300 to-yellow-400 leading-tight">
                  چالش هفتگی دوشنبه‌ها
                </h2>
                {timeRemaining.isMondayToday && (
                  <span className="text-[9px] bg-red-600/90 text-white px-1.5 py-0.5 rounded-full font-bold animate-pulse">
                    امروز دوشنبه است!
                  </span>
                )}
              </div>
              <p className="text-[10px] text-amber-200/70 font-vazir">
                مراحل منحصربه‌فرد با جوایز ویژه هر هفته
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playClick();
              onClose();
            }}
            className="w-7 h-7 rounded-full bg-[#4A2613] hover:bg-[#66351B] text-amber-200 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Monday Reset Countdown Pill */}
        <div className="my-2.5 p-2 rounded-2xl bg-gradient-to-r from-amber-950/70 via-[#3A1E0B] to-amber-950/70 border border-amber-600/50 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-400 animate-spin" style={{ animationDuration: '8s' }} />
            <div>
              <span className="text-[10px] text-amber-300/80 block font-vazir">
                زمان تا پایان دور و چالش دوشنبه بعد:
              </span>
              <span className="font-lalezar text-xs text-yellow-300 tracking-wide">
                {toPersianDigits(timeRemaining.days)} روز و {toPersianDigits(timeRemaining.hours)} ساعت و{' '}
                {toPersianDigits(timeRemaining.minutes)} دقیقه
              </span>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playClick();
              onClose();
              onOpenLeaderboard();
            }}
            className="px-2.5 py-1 rounded-xl bg-amber-500/20 hover:bg-amber-500/40 border border-amber-400/60 text-amber-200 font-lalezar text-[11px] flex items-center gap-1 transition-all active:scale-95 cursor-pointer"
          >
            <Trophy className="w-3 h-3 text-amber-300" />
            <span>جدول رتبه‌ها</span>
          </button>
        </div>

        {/* Weekly Cultural Theme Banner */}
        <div className="p-3 rounded-2xl bg-gradient-to-b from-[#3D1E0C] to-[#241107] border border-[#8B5226] mb-3 relative overflow-hidden shadow-md">
          <div className="absolute top-0 left-0 translate-x-2 -translate-y-2 opacity-10">
            <Flame className="w-24 h-24 text-amber-300" />
          </div>

          <div className="relative z-10">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[9px] text-amber-400 bg-amber-950/90 px-2 py-0.5 rounded-full border border-amber-700/80 font-vazir">
                دورهٔ جاری: هفته {toPersianDigits(weeklyState.weekNumber)}
              </span>
              <div className="flex items-center gap-1 text-[11px] font-lalezar text-yellow-300">
                <Star className="w-3 h-3 fill-yellow-400" />
                <span>{toPersianDigits(weeklyState.weeklyScore)} امتیاز چالش</span>
              </div>
            </div>

            <h3 className="font-lalezar text-sm text-amber-100 mb-1">
              {weeklyState.themeTitle}
            </h3>
            <p className="font-vazir text-[11px] text-amber-200/80 leading-relaxed">
              «{weeklyState.themeStory}»
            </p>

            {/* Weekly Progress Meter */}
            <div className="mt-2.5 pt-2 border-t border-amber-900/60 flex items-center justify-between">
              <span className="text-[10px] text-amber-300/80 font-vazir">
                پیشرفت مراحل این دوشنبه:
              </span>
              <span className="font-lalezar text-xs text-yellow-300">
                {toPersianDigits(completedCount)} از ۵ مرحله
              </span>
            </div>
            <div className="w-full h-2 bg-[#120703] rounded-full overflow-hidden border border-[#522E18] mt-1">
              <div
                className="h-full bg-gradient-to-r from-amber-600 via-amber-400 to-yellow-300 rounded-full transition-all duration-500 shadow-[0_0_8px_rgba(245,158,11,0.8)]"
                style={{ width: `${(completedCount / 5) * 100}%` }}
              />
            </div>
          </div>
        </div>

        {/* 5 Unique Weekly Stages Cards (Rendered with React.memo & useCallback) */}
        <div className="space-y-2.5 mb-3">
          {stages.map((stage, idx) => {
            const isCompleted = weeklyState.completedStageIds.includes(stage.id);
            const isLocked = idx > 0 && !weeklyState.completedStageIds.includes(stages[idx - 1].id);
            const isNextAvailable = !isCompleted && !isLocked;

            return (
              <WeeklyStageCard
                key={stage.id}
                stage={stage}
                index={idx}
                isCompleted={isCompleted}
                isLocked={isLocked}
                isNextAvailable={isNextAvailable}
                onSelect={handleStageSelect}
              />
            );
          })}
        </div>

        {/* Grand Chest Section (Unlocks when all 5 stages completed) */}
        <div
          className={`p-3.5 rounded-2xl border transition-all ${
            weeklyState.hasClaimedGrandPrize
              ? 'bg-emerald-950/40 border-emerald-500/50'
              : isGrandUnlocked
              ? 'bg-gradient-to-r from-amber-900/80 via-yellow-900/60 to-amber-900/80 border-yellow-400 ring-2 ring-yellow-400/50 animate-pulse'
              : 'bg-[#180A04] border-[#44200E]'
          }`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div
                className={`w-10 h-10 rounded-2xl flex items-center justify-center ${
                  isGrandUnlocked
                    ? 'bg-gradient-to-tr from-yellow-400 to-amber-500 text-amber-950 shadow-lg'
                    : 'bg-[#251006] text-amber-400/60 border border-[#44200E]'
                }`}
              >
                <Gift className="w-5 h-5" />
              </div>

              <div>
                <h4 className="font-lalezar text-xs sm:text-sm text-yellow-200">
                  صندوقچه زرین قهرمانی دوشنبه
                </h4>
                <p className="text-[10px] text-amber-200/80 font-vazir">
                  {weeklyState.hasClaimedGrandPrize
                    ? 'پاداش ۱۲۰۰ سکه و نشان پهلوانی دریافت شد!'
                    : isGrandUnlocked
                    ? 'همه ۵ مرحله حل شد! صندوقچه آماده گشودن است.'
                    : 'با حل هر ۵ مرحله دوشنبه باز می‌شود (+۱۲۰۰ سکه و ۵۰۰ امتیاز)'}
                </p>
              </div>
            </div>

            {isGrandUnlocked && !weeklyState.hasClaimedGrandPrize && (
              <button
                onClick={handleClaimChest}
                className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-yellow-400 to-amber-500 hover:brightness-110 active:scale-95 text-amber-950 font-lalezar text-xs font-bold shadow-xl border border-yellow-100 flex items-center gap-1 cursor-pointer animate-bounce"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>باز کردن</span>
              </button>
            )}
          </div>

          {chestMessage && (
            <p className="mt-2 text-[11px] text-emerald-300 font-vazir text-center bg-emerald-950/80 p-1.5 rounded-xl border border-emerald-500/50">
              {chestMessage}
            </p>
          )}
        </div>
      </div>
    </div>
  );
});
