import React, { useState, useEffect } from 'react';
import { X, Users, Plus, Shield, Award, Eye, Check } from 'lucide-react';
import { soundEngine } from '../../audio/SoundEngine';
import { toPersianDigits, formatPersianCoins } from '../../utils/persianNumbers';
import {
  fetchNeighborhoods,
  createNeighborhood,
  joinNeighborhood,
  NeighborhoodData,
} from '../../utils/apiClient';

interface PatoghModalProps {
  isOpen: boolean;
  onClose: () => void;
  deviceId: string;
  playerName: string;
}

export const PatoghModal: React.FC<PatoghModalProps> = ({
  isOpen,
  onClose,
  deviceId,
  playerName,
}) => {
  const [patoghs, setPatoghs] = useState<NeighborhoodData[]>([]);
  const [activeTab, setActiveTab] = useState<'list' | 'create' | 'inspect'>('list');
  const [myPatoghId, setMyPatoghId] = useState<string>(() => {
    try {
      return localStorage.getItem('bahman_player_patogh_id') || 'nazi_abad';
    } catch {
      return 'nazi_abad';
    }
  });
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [inspectTarget, setInspectTarget] = useState<NeighborhoodData | null>(null);

  useEffect(() => {
    if (isOpen) {
      fetchNeighborhoods().then(setPatoghs);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleJoin = async (id: string) => {
    soundEngine.playCoins();
    await joinNeighborhood(id, deviceId);
    setMyPatoghId(id);
  };

  const handleCreate = async () => {
    if (!newName.trim()) return;
    soundEngine.playCoins();
    await createNeighborhood(newName, newDesc, playerName || 'پهلوان چایخانه');
    const updated = await fetchNeighborhoods();
    setPatoghs(updated);
    setActiveTab('list');
    setNewName('');
    setNewDesc('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-[#180A03]/85 backdrop-blur-sm animate-fade-in select-none">
      <div className="relative w-full max-w-sm max-h-[92vh] flex flex-col rounded-[32px] p-4 bg-gradient-to-b from-[#3A1E0E] via-[#2C160A] to-[#1E0E06] border-4 border-[#F59E0B] shadow-[0_15px_50px_rgba(245,158,11,0.3)] text-[#FFFBF0]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#522E18]">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-600 via-amber-400 to-yellow-300 p-0.5 flex items-center justify-center shadow-lg">
              <div className="w-full h-full rounded-full bg-[#200F05] flex items-center justify-center text-amber-300">
                <Users className="w-4 h-4" />
              </div>
            </div>
            <div>
              <h2 className="font-lalezar text-base text-yellow-300 leading-tight">
                پاتوق‌کشی و محله‌های لوتی‌ها
              </h2>
              <p className="text-[10px] text-amber-200/70 font-vazir">
                اتصال زنده به سرور • رقابت مرامی محله‌ها
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playClick();
              onClose();
            }}
            className="w-7 h-7 rounded-full bg-[#4A2613] hover:bg-[#66351B] text-amber-200 flex items-center justify-center cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="grid grid-cols-2 gap-1.5 p-1 rounded-xl bg-[#1C0D05] border border-amber-700/50 my-3 text-center">
          <button
            onClick={() => {
              soundEngine.playClick();
              setActiveTab('list');
              setInspectTarget(null);
            }}
            className={`py-1 rounded-lg font-lalezar text-xs cursor-pointer ${
              activeTab === 'list'
                ? 'bg-gradient-to-r from-amber-600 to-yellow-500 text-amber-950 font-bold shadow'
                : 'text-amber-300'
            }`}
          >
            فهرست پاتوق‌ها
          </button>
          <button
            onClick={() => {
              soundEngine.playClick();
              setActiveTab('create');
              setInspectTarget(null);
            }}
            className={`py-1 rounded-lg font-lalezar text-xs cursor-pointer ${
              activeTab === 'create'
                ? 'bg-gradient-to-r from-amber-600 to-yellow-500 text-amber-950 font-bold shadow'
                : 'text-amber-300'
            }`}
          >
            ایجاد پاتوق جدید
          </button>
        </div>

        {/* Content */}
        {activeTab === 'create' ? (
          <div className="space-y-3 my-2 text-right">
            <div>
              <label className="text-[11px] font-lalezar text-yellow-300 block mb-1">
                نام پاتوق (مثلاً: بچه‌های نازی‌آباد، لوتی‌های تجریش):
              </label>
              <input
                type="text"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="نام محله یا پاتوق..."
                className="w-full px-3 py-2 rounded-xl bg-[#1C0D05] border border-amber-600/60 text-amber-100 font-vazir text-xs outline-none focus:border-yellow-400"
              />
            </div>

            <div>
              <label className="text-[11px] font-lalezar text-yellow-300 block mb-1">
                مرام‌نامه و توصیف پاتوق:
              </label>
              <textarea
                value={newDesc}
                onChange={(e) => setNewDesc(e.target.value)}
                placeholder="توضیح کوتاه درباره بچه محل‌ها..."
                rows={3}
                className="w-full px-3 py-2 rounded-xl bg-[#1C0D05] border border-amber-600/60 text-amber-100 font-vazir text-xs outline-none focus:border-yellow-400 resize-none"
              />
            </div>

            <button
              onClick={handleCreate}
              disabled={!newName.trim()}
              className="w-full py-2.5 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-400 text-amber-950 font-lalezar text-sm font-bold shadow-lg hover:brightness-110 active:scale-95 transition-all cursor-pointer"
            >
              ثبت و افتتاح پاتوق رسمی
            </button>
          </div>
        ) : inspectTarget ? (
          // Inspect Teahouse View
          <div className="space-y-3 my-2 p-3 rounded-2xl bg-[#210E05] border border-amber-500/60 text-center">
            <span className="text-3xl">{inspectTarget.badge}</span>
            <h3 className="font-lalezar text-base text-yellow-300">{inspectTarget.name}</h3>
            <p className="text-[11px] text-amber-200 font-vazir">{inspectTarget.description}</p>
            <div className="p-2 rounded-xl bg-black/40 text-[10px] text-amber-300/80 font-vazir text-right space-y-1">
              <div>اوستای پاتوق: {inspectTarget.leader_name}</div>
              <div>تعداد چای‌ریزان: {toPersianDigits(inspectTarget.members_count)} نفر</div>
              <div>سماور مستقر: سماور برنجی قلم‌زنی اعلا</div>
              <div>فرش گسترده: قالیچه کاشان دستباف</div>
            </div>
            <button
              onClick={() => setInspectTarget(null)}
              className="px-4 py-1.5 rounded-xl bg-amber-700 text-yellow-100 font-lalezar text-xs cursor-pointer"
            >
              بازگشت به فهرست
            </button>
          </div>
        ) : (
          // List View
          <div className="flex-1 overflow-y-auto space-y-2 pr-0.5 custom-scrollbar">
            {patoghs.map((p, index) => {
              const isMine = myPatoghId === p.id;
              return (
                <div
                  key={p.id}
                  className={`p-3 rounded-2xl border transition-all ${
                    isMine
                      ? 'bg-amber-950/90 border-yellow-400 shadow-md'
                      : 'bg-[#251207] border-amber-600/40 hover:bg-[#32170A]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xl">{p.badge}</span>
                      <div className="text-right">
                        <span className="font-lalezar text-xs text-yellow-200 block">
                          {toPersianDigits(index + 1)}. {p.name}
                        </span>
                        <span className="text-[9px] text-amber-300/70 font-vazir">
                          اوستا: {p.leader_name} ({p.city})
                        </span>
                      </div>
                    </div>

                    <span className="font-lalezar text-xs text-yellow-400 bg-black/40 px-2 py-0.5 rounded-full">
                      {formatPersianCoins(p.total_score)} امتیاز
                    </span>
                  </div>

                  <p className="text-[10px] text-amber-200/80 font-vazir mb-2 text-right">
                    {p.description}
                  </p>

                  <div className="flex items-center justify-between pt-1 border-t border-amber-800/40">
                    <span className="text-[9px] text-amber-400/80 font-vazir">
                      👥 {toPersianDigits(p.members_count)} عضو
                    </span>
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => {
                          soundEngine.playClick();
                          setInspectTarget(p);
                        }}
                        className="px-2 py-0.5 rounded-lg bg-[#3C1D0B] text-amber-200 text-[10px] font-vazir flex items-center gap-1 hover:bg-[#522810] cursor-pointer"
                        title="مشاهده دکوراسیون چایخانه پاتوق"
                      >
                        <Eye className="w-3 h-3" />
                        <span>سرک کشیدن</span>
                      </button>
                      <button
                        onClick={() => handleJoin(p.id)}
                        disabled={isMine}
                        className={`px-3 py-0.5 rounded-lg font-lalezar text-xs transition-all ${
                          isMine
                            ? 'bg-emerald-800 text-emerald-200 cursor-default'
                            : 'bg-amber-600 hover:bg-amber-500 text-amber-950 font-bold active:scale-95 cursor-pointer'
                        }`}
                      >
                        {isMine ? 'عضو هستید' : 'پیوستن'}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Footer */}
        <div className="pt-2 border-t border-[#522E18] text-center">
          <p className="text-[10px] text-amber-300/60 font-vazir">
            پاتوق‌های سراسر کشور • هماهنگ با سرور mrasan.ir
          </p>
        </div>
      </div>
    </div>
  );
};
