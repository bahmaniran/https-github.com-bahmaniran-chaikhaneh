import React from 'react';
import {
  X,
  Radio,
  Store,
  Users,
  Sparkles,
  Calendar,
  Gift,
  Phone,
  Eye,
  Volume2,
  VolumeX,
  UserCheck,
  ChevronLeft,
  Award,
  BookOpen,
  Dice5,
  Share2,
  Download,
} from 'lucide-react';
import { soundEngine } from '../../audio/SoundEngine';
import { PlayerProfile } from '../../types';
import { toPersianDigits, formatPersianCoins } from '../../utils/persianNumbers';
import { APP_VERSION } from '../../services/backendApi';
import { APP_CURRENT_VERSION } from '../../services/UpdateService';
import teahouseBannerImg from '../../assets/images/teahouse_exact_scene_1791919273685.jpg';
import bahmanAvatarImg from '../../assets/images/bahman_exact_avatar_1791919274915.jpg';
import ghafourAvatarImg from '../../assets/images/ghafour_exact_avatar_1791919275034.jpg';

interface MainMenuModalProps {
  isOpen: boolean;
  onClose: () => void;
  playerProfile?: PlayerProfile;
  currentLevel: number;
  coins: number;
  soundEnabled: boolean;
  colorblindMode: boolean;
  weeklyStagesCompleted?: number;
  hasDailyRewardAvailable?: boolean;
  hasDiceRollAvailable?: boolean;
  hasDailyTipAvailable?: boolean;
  isDebtActive?: boolean;
  onOpenRegister?: () => void;
  onOpenShop: () => void;
  onOpenNeighborhood: () => void;
  onOpenSpecialGuest: () => void;
  onOpenWeeklyChallenge?: () => void;
  onOpenDailyReward?: () => void;
  onOpenRadio: () => void;
  onOpenContact?: () => void;
  onOpenDaftarHesab?: () => void;
  onOpenNaghali?: () => void;
  onOpenRenovations?: () => void;
  onOpenPatogh?: () => void;
  onOpenSiniGardani?: () => void;
  onOpenTakhtehNard?: () => void;
  onOpenPahlavaniCard?: () => void;
  onCheckUpdate?: () => void;
  hasUpdateAvailable?: boolean;
  onToggleSound: () => void;
  onToggleColorblind: () => void;
}

export const MainMenuModal: React.FC<MainMenuModalProps> = ({
  isOpen,
  onClose,
  playerProfile,
  currentLevel,
  coins,
  soundEnabled,
  colorblindMode,
  weeklyStagesCompleted = 0,
  hasDailyRewardAvailable = false,
  hasDiceRollAvailable = true,
  hasDailyTipAvailable = false,
  isDebtActive = false,
  hasUpdateAvailable = false,
  onOpenRegister,
  onOpenShop,
  onOpenNeighborhood,
  onOpenSpecialGuest,
  onOpenWeeklyChallenge,
  onOpenDailyReward,
  onOpenRadio,
  onOpenContact,
  onOpenDaftarHesab,
  onOpenNaghali,
  onOpenRenovations,
  onOpenPatogh,
  onOpenSiniGardani,
  onOpenTakhtehNard,
  onOpenPahlavaniCard,
  onCheckUpdate,
  onToggleSound,
  onToggleColorblind,
}) => {
  if (!isOpen) return null;

  const handleAction = (action?: () => void) => {
    if (!action) return;
    soundEngine.playClick();
    onClose();
    setTimeout(() => {
      action();
    }, 120);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-[#180A03]/85 backdrop-blur-sm animate-fade-in select-none">
      <div className="relative w-full max-w-sm max-h-[92vh] flex flex-col rounded-[32px] p-4 bg-gradient-to-b from-[#3A1E0E] via-[#2C160A] to-[#1E0E06] border-4 border-[#F59E0B] shadow-[0_15px_50px_rgba(245,158,11,0.3)] text-[#FFFBF0] overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-2.5 border-b border-[#522E18]">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-600 via-amber-400 to-yellow-300 p-0.5 flex items-center justify-center shadow-lg">
              <div className="w-full h-full rounded-full bg-[#200F05] flex items-center justify-center text-amber-300 font-lalezar text-sm">
                ☰
              </div>
            </div>
            <div>
              <h2 className="font-lalezar text-base text-yellow-300 leading-tight">
                منوی چایخانه عمو بهمن
              </h2>
              <p className="text-[10px] text-amber-200/70 font-vazir">
                رویدادها، نسیه، پاتوق‌ها و امکانات بازی
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playClick();
              onClose();
            }}
            className="w-7 h-7 rounded-full bg-[#4A2613] hover:bg-[#66351B] text-amber-200 flex items-center justify-center transition-colors cursor-pointer"
            title="بستن منو"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto pr-0.5 pl-0.5 py-2.5 space-y-3 custom-scrollbar">
          {/* Authentic Persian Traditional Teahouse Hero Showcase Banner */}
          <div className="relative rounded-2xl overflow-hidden border-2 border-amber-500/60 shadow-lg bg-[#1B0C05]">
            <div className="relative h-28 w-full overflow-hidden">
              <img
                src={teahouseBannerImg}
                alt="صفای چایخانه سنتی عمو بهمن"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover brightness-90 transform hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#1B0C05] via-[#1B0C05]/40 to-transparent" />
              
              {/* Uncle Bahman authentic seal */}
              <div className="absolute bottom-2 right-2.5 flex items-center gap-2">
                <div className="w-11 h-11 rounded-full p-0.5 bg-gradient-to-tr from-amber-500 via-yellow-300 to-amber-600 shadow-lg">
                  <img
                    src={bahmanAvatarImg}
                    alt="اوستا بهمن"
                    referrerPolicy="no-referrer"
                    className="w-full h-full rounded-full object-cover"
                  />
                </div>
                <div className="text-right drop-shadow-md">
                  <span className="font-lalezar text-xs text-yellow-300 block">
                    چایخانه سنتی عمو بهمن
                  </span>
                  <span className="text-[9px] font-vazir text-amber-100/90 block">
                    «خوش‌آمدی پهلوون! صفا آوردی به محله»
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* User Profile Banner & Business Card Link with Authentic Pahlevan Avatar */}
          <div
            onClick={() => onOpenPahlavaniCard && handleAction(onOpenPahlavaniCard)}
            className="p-3 rounded-2xl bg-gradient-to-r from-[#3D1E0C] to-[#251107] border border-amber-500/50 flex items-center justify-between cursor-pointer hover:border-amber-400 transition-all active:scale-[0.99] shadow-md group"
          >
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-300 p-0.5 flex items-center justify-center shadow">
                <img
                  src={ghafourAvatarImg}
                  alt="پهلوان چایخانه"
                  referrerPolicy="no-referrer"
                  className="w-full h-full rounded-full object-cover"
                />
              </div>
              <div className="text-right">
                <div className="flex items-center gap-1.5">
                  <span className="font-lalezar text-sm text-yellow-200">
                    {playerProfile?.isRegistered && playerProfile.firstName
                      ? `${playerProfile.firstName} ${playerProfile.lastName}`
                      : 'پهلوان چایخانه'}
                  </span>
                  <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-amber-950 text-yellow-300 border border-amber-600 font-vazir">
                    کارت ویزیت
                  </span>
                </div>
                <div className="text-[10px] text-amber-200/70 font-vazir flex items-center gap-2 mt-0.5">
                  <span>مرحله {toPersianDigits(currentLevel)}</span>
                  <span>•</span>
                  <span>{formatPersianCoins(coins)} سکه ★</span>
                </div>
              </div>
            </div>
            <ChevronLeft className="w-4 h-4 text-amber-400 group-hover:-translate-x-1 transition-transform" />
          </div>

          {/* Section 1: Mini-games & Events */}
          <div>
            <div className="text-[11px] font-lalezar text-amber-400 mb-1.5 px-1 flex items-center gap-1">
              <Award className="w-3.5 h-3.5 text-yellow-400" />
              <span>بازی‌ها و رویدادهای ویژه</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {/* Backgammon Dice Roll */}
              <button
                onClick={() => onOpenTakhtehNard && handleAction(onOpenTakhtehNard)}
                className="p-2.5 rounded-2xl bg-[#28140A] hover:bg-[#381C0E] border border-amber-500/50 text-right flex flex-col justify-between transition-all active:scale-95 cursor-pointer shadow-sm relative"
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <div className="w-7 h-7 rounded-full bg-amber-950 border border-amber-500 flex items-center justify-center text-sm">
                    🎲
                  </div>
                  {hasDiceRollAvailable && (
                    <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-yellow-400 text-amber-950 font-lalezar animate-bounce">
                      تاس رایگان!
                    </span>
                  )}
                </div>
                <div>
                  <span className="font-lalezar text-xs text-yellow-200 block">
                    تخته‌نرد عمو بهمن
                  </span>
                  <span className="text-[9px] text-amber-200/70 font-vazir">
                    جفت شیش و سکه رایگان
                  </span>
                </div>
              </button>

              {/* Shab-haye Naghali (9-piece painting) */}
              <button
                onClick={() => onOpenNaghali && handleAction(onOpenNaghali)}
                className="p-2.5 rounded-2xl bg-[#28140A] hover:bg-[#381C0E] border border-amber-500/50 text-right flex flex-col justify-between transition-all active:scale-95 cursor-pointer shadow-sm relative"
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <div className="w-7 h-7 rounded-full bg-amber-950 border border-amber-500 flex items-center justify-center text-sm">
                    🪘
                  </div>
                  <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-amber-900 text-yellow-200 font-vazir">
                    ۹ قطعه
                  </span>
                </div>
                <div>
                  <span className="font-lalezar text-xs text-yellow-200 block">
                    شب‌های نقالی شاهنامه
                  </span>
                  <span className="text-[9px] text-amber-200/70 font-vazir">
                    تابلو نقاشی و استکان طلایی
                  </span>
                </div>
              </button>

              {/* Sini-Gardani Mini-game */}
              <button
                onClick={() => onOpenSiniGardani && handleAction(onOpenSiniGardani)}
                className="p-2.5 rounded-2xl bg-[#28140A] hover:bg-[#381C0E] border border-amber-500/50 text-right flex flex-col justify-between transition-all active:scale-95 cursor-pointer shadow-sm"
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <div className="w-7 h-7 rounded-full bg-amber-950 border border-amber-500 flex items-center justify-center text-sm">
                    🍽️
                  </div>
                  <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-emerald-950 text-emerald-300 font-vazir">
                    ۲۰ ثانیه
                  </span>
                </div>
                <div>
                  <span className="font-lalezar text-xs text-yellow-200 block">
                    مینی‌گیم سینی‌گردانی
                  </span>
                  <span className="text-[9px] text-amber-200/70 font-vazir">
                    تعادل سینی و انعام تا ۱۵۰ سکه
                  </span>
                </div>
              </button>

              {/* Monday Challenge */}
              <button
                onClick={() => onOpenWeeklyChallenge && handleAction(onOpenWeeklyChallenge)}
                className="p-2.5 rounded-2xl bg-[#28140A] hover:bg-[#381C0E] border border-amber-500/50 text-right flex flex-col justify-between transition-all active:scale-95 cursor-pointer shadow-sm"
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <div className="w-7 h-7 rounded-full bg-amber-950 border border-amber-500 flex items-center justify-center text-yellow-300">
                    <Calendar className="w-4 h-4" />
                  </div>
                  {weeklyStagesCompleted < 5 && (
                    <span className="w-2 h-2 rounded-full bg-red-400 animate-pulse" />
                  )}
                </div>
                <div>
                  <span className="font-lalezar text-xs text-yellow-200 block">
                    چالش دوشنبه‌ها
                  </span>
                  <span className="text-[9px] text-amber-200/70 font-vazir">
                    ۵ مرحله با پاداش ۳ برابر
                  </span>
                </div>
              </button>
            </div>
          </div>

          {/* Section 2: Economy & Clans */}
          <div>
            <div className="text-[11px] font-lalezar text-amber-400 mb-1.5 px-1 flex items-center gap-1">
              <Store className="w-3.5 h-3.5 text-yellow-400" />
              <span>بازار، نسیه و پاتوق‌ها</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {/* Renovations & Daily Tip Jar */}
              <button
                onClick={() => onOpenRenovations && handleAction(onOpenRenovations)}
                className="p-2.5 rounded-2xl bg-[#28140A] hover:bg-[#381C0E] border border-amber-500/50 text-right flex flex-col justify-between transition-all active:scale-95 cursor-pointer shadow-sm relative"
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <div className="w-7 h-7 rounded-full bg-amber-950 border border-amber-500 flex items-center justify-center text-sm">
                    🏺
                  </div>
                  {hasDailyTipAvailable && (
                    <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-emerald-500 text-amber-950 font-lalezar animate-pulse">
                      دخل آماده!
                    </span>
                  )}
                </div>
                <div>
                  <span className="font-lalezar text-xs text-yellow-200 block">
                    دکور و دخل روزانه
                  </span>
                  <span className="text-[9px] text-amber-200/70 font-vazir">
                    ارتقای سماور و سود دخل
                  </span>
                </div>
              </button>

              {/* Daftar-e-Hesab (Credit & Debt) */}
              <button
                onClick={() => onOpenDaftarHesab && handleAction(onOpenDaftarHesab)}
                className="p-2.5 rounded-2xl bg-[#28140A] hover:bg-[#381C0E] border border-amber-500/50 text-right flex flex-col justify-between transition-all active:scale-95 cursor-pointer shadow-sm relative"
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <div className="w-7 h-7 rounded-full bg-amber-950 border border-amber-500 flex items-center justify-center text-yellow-300">
                    <BookOpen className="w-4 h-4" />
                  </div>
                  {isDebtActive ? (
                    <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-red-900 text-red-200 font-vazir">
                      بدهکار
                    </span>
                  ) : (
                    <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-amber-950 text-amber-300 font-vazir">
                      ۳۰۰ سکه
                    </span>
                  )}
                </div>
                <div>
                  <span className="font-lalezar text-xs text-yellow-200 block">
                    نسیه از عمو بهمن
                  </span>
                  <span className="text-[9px] text-amber-200/70 font-vazir">
                    دفتر حساب با ۳ برد پیاپی
                  </span>
                </div>
              </button>

              {/* Patogh & Neighborhood Clans (Live server) */}
              <button
                onClick={() => onOpenPatogh && handleAction(onOpenPatogh)}
                className="p-2.5 rounded-2xl bg-[#28140A] hover:bg-[#381C0E] border border-amber-500/50 text-right flex flex-col justify-between transition-all active:scale-95 cursor-pointer shadow-sm"
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <div className="w-7 h-7 rounded-full bg-amber-950 border border-amber-500 flex items-center justify-center text-amber-300">
                    <Users className="w-4 h-4" />
                  </div>
                  <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-emerald-950 text-emerald-300 font-vazir">
                    سرور زنده
                  </span>
                </div>
                <div>
                  <span className="font-lalezar text-xs text-yellow-200 block">
                    پاتوق‌ها و محله‌ها
                  </span>
                  <span className="text-[9px] text-amber-200/70 font-vazir">
                    کلن‌ها، رقابت و سرک کشیدن
                  </span>
                </div>
              </button>

              {/* Retro Radio & Gramophone */}
              <button
                onClick={() => handleAction(onOpenRadio)}
                className="p-2.5 rounded-2xl bg-[#28140A] hover:bg-[#381C0E] border border-amber-500/50 text-right flex flex-col justify-between transition-all active:scale-95 cursor-pointer shadow-sm"
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <div className="w-7 h-7 rounded-full bg-amber-950 border border-amber-500 flex items-center justify-center text-amber-300">
                    <Radio className="w-4 h-4" />
                  </div>
                  <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-amber-950 text-amber-300 font-vazir">
                    ۳ موج
                  </span>
                </div>
                <div>
                  <span className="font-lalezar text-xs text-yellow-200 block">
                    رادیو لامپی ۳ موج
                  </span>
                  <span className="text-[9px] text-amber-200/70 font-vazir">
                    تهران قدیم، کوچه‌بازاری و آگهی
                  </span>
                </div>
              </button>
            </div>
          </div>

          {/* Section 3: Settings & Support */}
          <div className="space-y-1.5 pt-1">
            <div className="text-[11px] font-lalezar text-amber-400 mb-1 px-1">
              تنظیمات و پشتیبانی
            </div>

            {/* Colorblind Toggle */}
            <div
              onClick={() => {
                soundEngine.playClick();
                onToggleColorblind();
              }}
              className="p-2.5 rounded-2xl bg-[#28140A] hover:bg-[#33190C] border border-amber-600/30 flex items-center justify-between cursor-pointer transition-all"
            >
              <div className="flex items-center gap-2">
                <div
                  className={`w-7 h-7 rounded-full flex items-center justify-center ${
                    colorblindMode
                      ? 'bg-amber-500 text-amber-950'
                      : 'bg-amber-950 text-amber-300 border border-amber-600/50'
                  }`}
                >
                  <Eye className="w-4 h-4" />
                </div>
                <div className="text-right">
                  <span className="font-lalezar text-xs text-yellow-200 block">
                    حالت دسترس‌پذیری رنگ‌ها
                  </span>
                  <span className="text-[9px] text-amber-200/70 font-vazir">
                    نمایش نمادهای کمکی روی لایه‌ها
                  </span>
                </div>
              </div>
              <span
                className={`text-[10px] font-lalezar px-2 py-0.5 rounded-full ${
                  colorblindMode ? 'bg-amber-500 text-amber-950' : 'bg-amber-950 text-amber-400'
                }`}
              >
                {colorblindMode ? 'روشن' : 'خاموش'}
              </span>
            </div>

            {/* Sound Toggle */}
            <div
              onClick={() => {
                soundEngine.playClick();
                onToggleSound();
              }}
              className="p-2.5 rounded-2xl bg-[#28140A] hover:bg-[#33190C] border border-amber-600/30 flex items-center justify-between cursor-pointer transition-all"
            >
              <div className="flex items-center gap-2">
                <div
                  className={`w-7 h-7 rounded-full flex items-center justify-center ${
                    soundEnabled
                      ? 'bg-amber-950 text-amber-300 border border-amber-600/50'
                      : 'bg-red-950 text-red-300 border border-red-600/50'
                  }`}
                >
                  {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                </div>
                <div className="text-right">
                  <span className="font-lalezar text-xs text-yellow-200 block">
                    صدای بازی و سماور
                  </span>
                  <span className="text-[9px] text-amber-200/70 font-vazir">
                    موسیقی و افکت‌های صوتی
                  </span>
                </div>
              </div>
              <span
                className={`text-[10px] font-lalezar px-2 py-0.5 rounded-full ${
                  soundEnabled ? 'bg-emerald-950 text-emerald-300' : 'bg-red-950 text-red-300'
                }`}
              >
                {soundEnabled ? 'فعال' : 'بی‌صدا'}
              </span>
            </div>

            {/* Direct In-App APK Update Row */}
            {onCheckUpdate && (
              <div
                onClick={() => handleAction(onCheckUpdate)}
                className={`p-2.5 rounded-2xl border flex items-center justify-between cursor-pointer transition-all ${
                  hasUpdateAvailable
                    ? 'bg-gradient-to-r from-amber-600/30 via-yellow-600/20 to-amber-600/30 border-yellow-400 ring-1 ring-yellow-400/50 shadow-md animate-pulse'
                    : 'bg-[#28140A] hover:bg-[#381C0E] border-amber-600/30'
                }`}
              >
                <div className="flex items-center gap-2">
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center ${
                      hasUpdateAvailable
                        ? 'bg-gradient-to-tr from-yellow-400 to-amber-500 text-amber-950 font-bold shadow'
                        : 'bg-amber-950 border border-amber-500/60 text-amber-300'
                    }`}
                  >
                    <Download className="w-4 h-4" />
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-1.5">
                      <span className="font-lalezar text-xs text-yellow-200 block">
                        بروزرسانی مستقیم درون‌برنامه‌ای
                      </span>
                      {hasUpdateAvailable && (
                        <span className="text-[9px] bg-red-600 text-white px-1.5 py-0.2 rounded-full font-bold">
                          نسخه جدید!
                        </span>
                      )}
                    </div>
                    <span className="text-[9px] text-amber-200/70 font-vazir">
                      دانلود فایل APK بدون نیاز به بازار و گوگل‌پلی (نسخه فعلی {toPersianDigits(APP_VERSION)})
                    </span>
                  </div>
                </div>
                <ChevronLeft className="w-4 h-4 text-amber-300" />
              </div>
            )}

            {/* Contact Row */}
            {onOpenContact && (
              <div
                onClick={() => handleAction(onOpenContact)}
                className="p-2.5 rounded-2xl bg-gradient-to-r from-emerald-950/90 to-[#193223] border border-emerald-500/50 flex items-center justify-between cursor-pointer hover:brightness-110 transition-all"
              >
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-full bg-emerald-900 border border-emerald-400/60 flex items-center justify-center text-emerald-300">
                    <Phone className="w-4 h-4" />
                  </div>
                  <div className="text-right">
                    <span className="font-lalezar text-xs text-emerald-200 block">
                      ارتباط با طراح بازی: مهندس بامزد
                    </span>
                    <span className="text-[9px] text-emerald-300/80 font-vazir">
                      bahmanbamzad.ir • ۰۹۱۱۵۶۶۴۲۷۱
                    </span>
                  </div>
                </div>
                <ChevronLeft className="w-4 h-4 text-emerald-300" />
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="pt-2 border-t border-[#522E18] text-center flex items-center justify-between px-2 text-[10px] text-amber-300/60 font-vazir">
          <span>طراحی اختصاصی چایخانه عمو بهمن • مهندس بامزد</span>
          <span className="font-vazir text-amber-400/80">نسخه {toPersianDigits(APP_CURRENT_VERSION)}</span>
        </div>
      </div>
    </div>
  );
};
