import React, { useState, useEffect } from 'react';
import { X, Volume2, Radio as RadioIcon, RadioTower, Sparkles } from 'lucide-react';
import { RadioTrackId } from '../../types';
import { soundEngine } from '../../audio/SoundEngine';
import { toPersianDigits } from '../../utils/persianNumbers';
import {
  RADIO_STATIONS,
  RadioStationId,
  getActiveRadioStation,
  setActiveRadioStation,
} from '../../services/TeahouseStore';

interface RadioModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeTrack: RadioTrackId;
  volume: number;
  onTrackChange: (track: RadioTrackId) => void;
  onVolumeChange: (vol: number) => void;
}

export const RadioModal: React.FC<RadioModalProps> = ({
  isOpen,
  onClose,
  volume,
  onTrackChange,
  onVolumeChange,
}) => {
  const [sliderVol, setSliderVol] = useState(volume);
  const [activeStation, setActiveStation] = useState<RadioStationId>(() => getActiveRadioStation());
  const [tickerIndex, setTickerIndex] = useState(0);

  const currentStation = RADIO_STATIONS.find((s) => s.id === activeStation) || RADIO_STATIONS[0];

  useEffect(() => {
    const timer = setInterval(() => {
      setTickerIndex((prev) => (prev + 1) % currentStation.tickerMessages.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [currentStation]);

  if (!isOpen) return null;

  const handleSelectStation = (station: typeof RADIO_STATIONS[0]) => {
    soundEngine.playClick();
    setActiveStation(station.id);
    setActiveRadioStation(station.id);
    onTrackChange(station.trackId);
  };

  const handleSlider = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setSliderVol(val);
    onVolumeChange(val);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-[#180A03]/85 backdrop-blur-sm animate-fade-in select-none">
      <div className="relative w-full max-w-sm max-h-[92vh] overflow-y-auto bg-gradient-to-b from-[#3D2314] via-[#2A160B] to-[#1C0D05] rounded-3xl p-4 sm:p-5 border-4 border-[#8B5226] shadow-[0_10px_35px_rgba(0,0,0,0.8)] text-[#FFFBF0]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#5C3419]">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-full bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300">
              <RadioTower className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <h2 className="font-lalezar text-base sm:text-lg text-amber-300 leading-none">
                رادیو لامپی ۵ موج چایخانه
              </h2>
              <span className="text-[11px] text-amber-200/70 font-vazir">
                دستگاه‌های اصیل ایرانی، نوای همایون، دشتی و طهران قدیم
              </span>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-[#4A2814] hover:bg-[#63361B] text-amber-200 flex items-center justify-center cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Live Vintage Ticker Display Screen */}
        <div className="my-3 bg-[#140A04] rounded-2xl p-3 border-2 border-[#5A3114] shadow-inner relative overflow-hidden">
          <div className="flex items-center justify-between mb-1.5 border-b border-amber-900/40 pb-1.5">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
              <span className="text-xs sm:text-sm font-lalezar text-yellow-300">
                {currentStation.name}
              </span>
            </div>
            <span className="text-[10px] text-teal-300 font-vazir bg-teal-950/80 px-2 py-0.5 rounded-full border border-teal-700/80">
              {currentStation.dastgahTag}
            </span>
          </div>

          {/* Ticker Text */}
          <div className="h-10 flex items-center justify-center text-center px-1">
            <p className="font-vazir text-xs text-amber-100 font-semibold tracking-wide animate-fade-in drop-shadow line-clamp-2">
              {currentStation.tickerMessages[tickerIndex]}
            </p>
          </div>

          {/* Equalizer Wave Bars */}
          <div className="flex items-end justify-center gap-1.5 h-4 mt-1.5">
            {[40, 80, 55, 95, 70, 85, 45, 90, 60, 100].map((h, i) => (
              <div
                key={i}
                className="w-1.5 rounded-full bg-gradient-to-t from-amber-600 via-amber-400 to-yellow-200 animate-pulse"
                style={{
                  height: `${h}%`,
                  animationDelay: `${i * 100}ms`,
                }}
              />
            ))}
          </div>
        </div>

        {/* 5 Persian Classical Dastgah Stations */}
        <div className="space-y-2 mb-3.5">
          {RADIO_STATIONS.map((station) => {
            const isCurrent = activeStation === station.id;
            return (
              <div
                key={station.id}
                onClick={() => handleSelectStation(station)}
                className={`flex items-center justify-between p-2.5 rounded-2xl border cursor-pointer transition-all ${
                  isCurrent
                    ? 'bg-gradient-to-r from-amber-950/90 via-[#361909] to-amber-900/80 border-yellow-400 shadow-[0_0_14px_rgba(245,158,11,0.35)] text-yellow-100 scale-[1.01]'
                    : 'bg-[#221007]/80 border-[#4D2912] hover:bg-[#2C150A] hover:border-amber-700 text-[#FFE8D6]/80'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <div className={`w-9 h-9 rounded-full flex items-center justify-center text-base border ${
                    isCurrent
                      ? 'bg-amber-900/80 border-yellow-400 text-yellow-300 shadow-sm'
                      : 'bg-[#140803] border-amber-800/50 text-amber-300'
                  }`}>
                    {station.emoji}
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-1.5">
                      <h3 className="text-xs sm:text-sm font-bold font-lalezar text-yellow-200">
                        {station.name}
                      </h3>
                    </div>
                    <p className="text-[10px] text-amber-200/70 font-vazir">
                      {station.genre}
                    </p>
                  </div>
                </div>

                <div>
                  {isCurrent ? (
                    <span className="text-[11px] text-yellow-300 font-bold font-lalezar bg-amber-950/90 px-2.5 py-1 rounded-full border border-yellow-500 shadow">
                      کوک شده ✓
                    </span>
                  ) : (
                    <span className="text-[10px] text-amber-400/60 font-vazir bg-[#180A03] px-2 py-0.5 rounded-full border border-amber-900/60">
                      پخش
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Volume Slider */}
        <div className="bg-[#140A04] rounded-2xl p-3 border border-[#4D2912]">
          <div className="flex items-center justify-between text-xs text-amber-300 mb-1.5 font-vazir">
            <span className="flex items-center gap-1">
              <Volume2 className="w-3.5 h-3.5" />
              <span>میزان بلندی صدای رادیو</span>
            </span>
            <span className="font-lalezar">{toPersianDigits(Math.round(sliderVol * 100))}%</span>
          </div>

          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            value={sliderVol}
            onChange={handleSlider}
            className="w-full accent-amber-500 cursor-pointer h-1.5 bg-[#3D2314] rounded-lg"
          />
        </div>
      </div>
    </div>
  );
};
