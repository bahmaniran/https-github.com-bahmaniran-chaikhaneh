import React from 'react';
import { Trophy, Star, ArrowRight, Sparkles, Calendar, Gift } from 'lucide-react';
import { formatPersianCoins, toPersianDigits } from '../../utils/persianNumbers';
import { soundEngine } from '../../audio/SoundEngine';
import bahmanAvatar from '../../assets/images/bahman_exact_avatar_1791919274915.jpg';

interface VictoryModalProps {
  isOpen: boolean;
  level: number;
  earnedCoins: number;
  movesCount: number;
  isRushOrderWon?: boolean;
  onNextLevel: () => void;
  isWeeklyMode?: boolean;
  weeklyStageTitle?: string;
  weeklyPointsEarned?: number;
  specialItemReward?: string;
  onViewLeaderboard?: () => void;
}

export const VictoryModal: React.FC<VictoryModalProps> = ({
  isOpen,
  level,
  earnedCoins,
  movesCount,
  isRushOrderWon,
  onNextLevel,
  isWeeklyMode = false,
  weeklyStageTitle,
  weeklyPointsEarned,
  specialItemReward,
  onViewLeaderboard,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#180A03]/85 backdrop-blur-sm animate-fade-in select-none">
      <div className="relative w-full max-w-sm max-h-[92vh] overflow-y-auto rounded-[34px] p-1 bg-gradient-to-b from-amber-400 via-amber-600 to-amber-900 border-4 border-yellow-300 shadow-[0_15px_50px_rgba(245,158,11,0.5)] text-[#FFFBF0]">
        <div className="rounded-[30px] p-6 bg-gradient-to-b from-[#3A1E0E] via-[#2C160A] to-[#1E0E06] border-2 border-amber-500/50 flex flex-col items-center text-center">
          {/* Uncle Bahman Authentic Victory Portrait & Golden Laurel */}
          <div className="relative mb-3 flex items-center justify-center">
            <div className="relative w-20 h-20 rounded-full bg-gradient-to-tr from-amber-600 via-yellow-400 to-amber-700 p-1 flex items-center justify-center shadow-2xl animate-bounce">
              <img
                src={bahmanAvatar}
                alt="اوستا بهمن"
                referrerPolicy="no-referrer"
                className="w-full h-full rounded-full object-cover"
              />
              <div className="absolute -top-1 -right-1 text-yellow-300 text-lg">✨</div>
              <div className="absolute -bottom-1 -left-1 w-6 h-6 rounded-full bg-amber-500 border border-yellow-200 flex items-center justify-center text-xs shadow">
                🏆
              </div>
            </div>
          </div>

          {/* Level Complete Heading */}
          <h2 className="font-lalezar text-2xl text-transparent bg-clip-text bg-gradient-to-b from-yellow-200 via-amber-400 to-yellow-500 drop-shadow mb-1">
            {isWeeklyMode
              ? weeklyStageTitle || `پیروزی در چالش دوشنبه!`
              : `مرحله ${toPersianDigits(level)} با موفقیت حل شد!`}
          </h2>

          <p className="font-vazir text-xs text-amber-200/80 mb-4">
            {isWeeklyMode
              ? '«دست مریزاد اوستا! شربت دوشنبه بی‌نقص شد و رتبه‌ات در جدول هفتگی ارتقا یافت.»'
              : '«باریکلا جوون، عجب سلیقه‌ای! چای‌ها یک‌رنگ و قندپهلو شدند.»'}
          </p>

          {/* 3 Golden Stars */}
          <div className="flex items-center justify-center gap-3 my-2">
            {[1, 2, 3].map((starIdx) => (
              <div
                key={starIdx}
                className="w-10 h-10 rounded-2xl bg-amber-500/20 border-2 border-amber-400 flex items-center justify-center text-yellow-300 shadow-md"
              >
                <Star className="w-6 h-6 fill-yellow-400 text-yellow-300 animate-pulse" />
              </div>
            ))}
          </div>

          {/* Rewards Breakdown Box */}
          <div className="w-full bg-[#180B04] rounded-2xl p-3 border border-amber-600/40 my-4 space-y-2">
            <div className="flex items-center justify-between text-xs font-vazir text-amber-200">
              <span>تعداد جابه‌جایی:</span>
              <span className="font-lalezar text-sm text-yellow-300">
                {toPersianDigits(movesCount)} حرکت
              </span>
            </div>

            <div className="flex items-center justify-between text-xs font-vazir text-amber-200">
              <span>سکه پاداش:</span>
              <div className="flex items-center gap-1 font-lalezar text-base text-yellow-400 font-bold">
                <span>+{formatPersianCoins(earnedCoins)}</span>
                <span className="text-xs">★</span>
              </div>
            </div>

            {isWeeklyMode && weeklyPointsEarned !== undefined && (
              <div className="flex items-center justify-between text-xs font-vazir text-teal-300 border-t border-amber-900/60 pt-1.5">
                <span>امتیاز جدول هفتگی:</span>
                <span className="font-lalezar text-sm text-teal-300 font-bold">
                  +{toPersianDigits(weeklyPointsEarned)} امتیاز لیگ
                </span>
              </div>
            )}

            {isWeeklyMode && specialItemReward && (
              <div className="flex items-center justify-between text-xs font-vazir text-amber-300 border-t border-amber-900/60 pt-1.5">
                <span>نشان اختصاصی:</span>
                <span className="font-lalezar text-xs text-amber-300 font-bold flex items-center gap-1">
                  <Gift className="w-3.5 h-3.5 text-yellow-400" />
                  <span>{specialItemReward}</span>
                </span>
              </div>
            )}

            {isRushOrderWon && (
              <div className="flex items-center justify-between text-xs font-vazir text-teal-300 border-t border-amber-900/60 pt-1.5">
                <span>پاداش مشتری عجله‌ای:</span>
                <span className="font-lalezar text-sm text-teal-300 font-bold">+۱۵۰ سکه سرعت!</span>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="w-full space-y-2">
            <button
              onClick={() => {
                soundEngine.playClick();
                onNextLevel();
              }}
              className="w-full py-3 px-6 rounded-2xl bg-gradient-to-r from-amber-600 via-yellow-500 to-amber-600 hover:brightness-110 active:scale-98 text-amber-950 font-lalezar text-base sm:text-lg font-bold shadow-xl border-2 border-yellow-200 flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <span>{isWeeklyMode ? 'مرحله بعدی چالش' : 'مرحله بعدی'}</span>
              <ArrowRight className="w-5 h-5 rotate-180" />
            </button>

            {isWeeklyMode && onViewLeaderboard && (
              <button
                onClick={() => {
                  soundEngine.playClick();
                  onViewLeaderboard();
                }}
                className="w-full py-2 px-4 rounded-xl bg-[#2A160D] hover:bg-[#3D2114] text-amber-300 font-lalezar text-xs border border-amber-700/70 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <Trophy className="w-3.5 h-3.5" />
                <span>مشاهده جدول رتبه‌بندی هفتگی</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
