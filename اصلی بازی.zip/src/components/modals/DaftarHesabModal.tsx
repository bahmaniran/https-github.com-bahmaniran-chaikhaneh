import React from 'react';
import { X, BookOpen, AlertTriangle, CheckCircle, ShieldAlert } from 'lucide-react';
import { soundEngine } from '../../audio/SoundEngine';
import { toPersianDigits, formatPersianCoins } from '../../utils/persianNumbers';
import { DaftarHesabState } from '../../types';

interface DaftarHesabModalProps {
  isOpen: boolean;
  onClose: () => void;
  debtState: DaftarHesabState;
  onBorrow: () => void;
  onRepay: () => void;
  coins: number;
}

export const DaftarHesabModal: React.FC<DaftarHesabModalProps> = ({
  isOpen,
  onClose,
  debtState,
  onBorrow,
  onRepay,
  coins,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-[#180A03]/85 backdrop-blur-sm animate-fade-in select-none">
      <div className="relative w-full max-w-sm max-h-[92vh] overflow-y-auto rounded-[32px] p-5 bg-gradient-to-b from-[#3A1E0E] via-[#2C160A] to-[#1E0E06] border-4 border-[#F59E0B] shadow-[0_15px_50px_rgba(245,158,11,0.3)] text-[#FFFBF0]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#522E18]">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-600 via-amber-400 to-yellow-300 p-0.5 flex items-center justify-center shadow-lg">
              <div className="w-full h-full rounded-full bg-[#200F05] flex items-center justify-center text-amber-300">
                <BookOpen className="w-4 h-4" />
              </div>
            </div>
            <div>
              <h2 className="font-lalezar text-base text-yellow-300 leading-tight">
                دفتر حساب و نسیه عمو بهمن
              </h2>
              <p className="text-[10px] text-amber-200/90 font-vazir font-medium">
                «نسیه، حتی شما پهلوان عزیز! (به شرط مرام)»
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playClick();
              onClose();
            }}
            className="w-7 h-7 rounded-full bg-[#4A2613] hover:bg-[#66351B] text-amber-200 flex items-center justify-center cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content based on state */}
        <div className="my-4 space-y-3">
          {debtState.repossessedItem ? (
            // Repossession / توقیف اموال Alert
            <div className="p-3.5 rounded-2xl bg-red-950/90 border-2 border-red-500 text-center shadow-lg animate-pulse">
              <ShieldAlert className="w-9 h-9 text-red-400 mx-auto mb-1" />
              <h3 className="font-lalezar text-base text-red-200">توقیف اموال!</h3>
              <p className="text-[11px] text-red-200/90 font-vazir mt-1 leading-relaxed">
                «رفیق باصفا! شرط ۳ پیروزی پیاپی باطل شد! یکی از وسایل چایخانه رو گروگان نگه داشتم تا ۳۵۰ سکه رو تسویه کنی!»
              </p>
              <div className="mt-3">
                <button
                  onClick={() => {
                    if (coins >= 350) {
                      soundEngine.playClick();
                      onRepay();
                    } else {
                      soundEngine.playGlassClink();
                    }
                  }}
                  disabled={coins < 350}
                  className={`w-full py-2 rounded-xl font-lalezar text-xs flex items-center justify-center gap-1.5 transition-transform active:scale-95 shadow-md ${
                    coins >= 350
                      ? 'bg-gradient-to-r from-emerald-700 to-teal-600 text-white cursor-pointer hover:brightness-110'
                      : 'bg-stone-800 text-stone-400 cursor-not-allowed opacity-70'
                  }`}
                >
                  <span>تسویه بدهی (۳۵۰ سکه)</span>
                </button>
                {coins < 350 && (
                  <span className="text-[10px] text-red-300 font-vazir block mt-1">
                    سکه کافی نداری! با بردن مراحل عادی سکه جمع کن.
                  </span>
                )}
              </div>
            </div>
          ) : debtState.isDebtActive ? (
            // Active Debt Streak Tracker
            <div className="p-3.5 rounded-2xl bg-[#3D1E0C] border border-amber-500/60 shadow-md">
              <div className="flex items-center justify-between mb-2">
                <span className="font-lalezar text-sm text-yellow-300">
                  وضعیت تسویه نسیه (۳۰۰ سکه)
                </span>
                <span className="text-[11px] font-lalezar text-amber-300 bg-amber-950 px-2 py-0.5 rounded-full border border-amber-600">
                  {toPersianDigits(debtState.debtStreak)} از ۳ پیروزی
                </span>
              </div>
              <p className="text-[11px] text-amber-200/80 font-vazir leading-relaxed">
                باید ۳ مرحله پشت سر هم بدون باخت یا ریستارت پیروز بشی تا نسیه بخشیده بشه!
              </p>

              {/* Progress Steps */}
              <div className="flex items-center justify-center gap-3 my-3">
                {[1, 2, 3].map((step) => {
                  const done = debtState.debtStreak >= step;
                  return (
                    <div
                      key={step}
                      className={`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all ${
                        done
                          ? 'bg-emerald-600 border-emerald-300 text-white shadow-[0_0_10px_rgba(16,185,129,0.7)]'
                          : 'bg-[#1C0D05] border-amber-700/60 text-amber-500'
                      }`}
                    >
                      {done ? <CheckCircle className="w-5 h-5" /> : <span className="font-lalezar text-sm">{toPersianDigits(step)}</span>}
                    </div>
                  );
                })}
              </div>

              <div className="flex items-center gap-1.5 p-2 rounded-xl bg-amber-950/80 border border-amber-700/50 text-[10px] text-amber-300 font-vazir">
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                <span>اگه ببازی یا ریستارت کنی، توقیف اموال کلید می‌خوره!</span>
              </div>
            </div>
          ) : (
            // Ready to borrow 300 coins
            <div className="p-3.5 rounded-2xl bg-[#3D1E0C] border border-amber-500/60 text-center shadow-md">
              <div className="w-14 h-14 mx-auto rounded-full bg-gradient-to-tr from-amber-500 to-yellow-300 p-0.5 mb-2 shadow">
                <div className="w-full h-full rounded-full bg-[#180A04] flex items-center justify-center font-lalezar text-xl text-yellow-300">
                  💰
                </div>
              </div>
              <h3 className="font-lalezar text-base text-yellow-200">
                دریافت ۳۰۰ سکه نسیه فوری
              </h3>
              <p className="text-[11px] text-amber-200/80 font-vazir mt-1 leading-relaxed">
                «دستت خالیه مشتی؟ غمت نباشه! ۳۰۰ تا سکه از جیب من بردار، جاش ۳ تا مرحله رو پشت سر هم ببر تا اسمت از دفتر خط بخوره!»
              </p>

              <button
                onClick={() => {
                  soundEngine.playClick();
                  onBorrow();
                }}
                className="w-full mt-4 py-2.5 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 text-amber-950 font-lalezar text-sm font-bold shadow-lg hover:brightness-110 active:scale-95 transition-transform cursor-pointer"
              >
                یا علی! قرض بده عمو (۳۰۰ سکه)
              </button>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="pt-2 border-t border-[#522E18] text-center">
          <p className="text-[10px] text-amber-300/60 font-vazir">
            دفتر حساب چایخانه • اعتبار هر پهلوان، قول و قرار اوست
          </p>
        </div>
      </div>
    </div>
  );
};
