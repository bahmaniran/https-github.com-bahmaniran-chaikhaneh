import React, { useState } from 'react';
import { X, Sparkles } from 'lucide-react';
import { soundEngine } from '../../audio/SoundEngine';
import { toPersianDigits, formatPersianCoins } from '../../utils/persianNumbers';
import { canRollDiceToday, rollBackgammonDice } from '../../services/TeahouseStore';
import { DiceRollResult } from '../../types';

interface TakhtehNardModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAwardCoins: (coins: number) => void;
}

const DICE_FACES: Record<number, string> = {
  1: '⚀',
  2: '⚁',
  3: '⚂',
  4: '⚃',
  5: '⚄',
  6: '⚅',
};

export const TakhtehNardModal: React.FC<TakhtehNardModalProps> = ({
  isOpen,
  onClose,
  onAwardCoins,
}) => {
  const [isRolling, setIsRolling] = useState(false);
  const [result, setResult] = useState<DiceRollResult | null>(null);
  const [canRoll, setCanRoll] = useState(() => canRollDiceToday());

  if (!isOpen) return null;

  const handleRoll = () => {
    if (!canRoll || isRolling) return;
    setIsRolling(true);
    soundEngine.playDiceRoll();

    // Roll animation delay
    setTimeout(() => {
      const res = rollBackgammonDice();
      setResult(res);
      setIsRolling(false);
      setCanRoll(false);
      soundEngine.playCoins();
      onAwardCoins(res.coinsAwarded);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-[#180A03]/85 backdrop-blur-sm animate-fade-in select-none">
      <div className="relative w-full max-w-sm max-h-[92vh] overflow-y-auto rounded-[32px] p-5 bg-gradient-to-b from-[#3A1E0E] via-[#2C160A] to-[#1E0E06] border-4 border-[#F59E0B] shadow-[0_15px_50px_rgba(245,158,11,0.3)] text-[#FFFBF0]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#522E18]">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-600 via-amber-400 to-yellow-300 p-0.5 flex items-center justify-center shadow-lg">
              <div className="w-full h-full rounded-full bg-[#200F05] flex items-center justify-center text-amber-300 text-sm">
                🎲
              </div>
            </div>
            <div>
              <h2 className="font-lalezar text-base text-yellow-300 leading-tight">
                تخته‌نرد روزانه عمو بهمن
              </h2>
              <p className="text-[10px] text-amber-200/70 font-vazir">
                جایگزین اصیل ایرانی برای گردونه شانس
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playClick();
              onClose();
            }}
            className="w-7 h-7 rounded-full bg-[#4A2613] hover:bg-[#66351B] text-amber-200 flex items-center justify-center cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Backgammon Wooden Board Area */}
        <div className="my-4 p-4 rounded-2xl bg-gradient-to-b from-[#3D1E0C] to-[#251107] border-2 border-amber-600/70 text-center relative overflow-hidden shadow-xl">
          {/* Khatam inlaid border accents */}
          <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-amber-400 via-yellow-200 to-amber-500" />
          <div className="absolute inset-x-0 bottom-0 h-1 bg-gradient-to-r from-amber-400 via-yellow-200 to-amber-500" />

          {/* Dice Display */}
          <div className="flex items-center justify-center gap-6 my-4">
            <div
              className={`w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-100 to-amber-200 text-amber-950 flex items-center justify-center text-5xl shadow-2xl border-2 border-amber-300 transition-all ${
                isRolling ? 'animate-spin' : ''
              }`}
            >
              {result ? DICE_FACES[result.dice1] : '🎲'}
            </div>
            <div
              className={`w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-100 to-amber-200 text-amber-950 flex items-center justify-center text-5xl shadow-2xl border-2 border-amber-300 transition-all ${
                isRolling ? 'animate-spin' : ''
              }`}
            >
              {result ? DICE_FACES[result.dice2] : '🎲'}
            </div>
          </div>

          {/* Result Banner */}
          {result && !isRolling && (
            <div className="my-2 p-2 rounded-xl bg-amber-950/80 border border-yellow-400 text-center animate-bounce">
              {result.isSheshBesh ? (
                <div>
                  <span className="font-lalezar text-base text-yellow-300 block">
                    👑 جفت شیش سلطنتی (شش و بش)!
                  </span>
                  <span className="text-xs text-amber-200 font-vazir">
                    ۵۰۰ سکه جایزه بزرگ + بوستر رایگان
                  </span>
                </div>
              ) : result.isDouble ? (
                <div>
                  <span className="font-lalezar text-sm text-yellow-300 block">
                    ✨ جفت {toPersianDigits(result.dice1)}!
                  </span>
                  <span className="text-xs text-amber-200 font-vazir">
                    ۱۵۰ سکه هدیه تخته‌نرد
                  </span>
                </div>
              ) : (
                <div>
                  <span className="font-lalezar text-sm text-yellow-300 block">
                    تاس خوش‌یمن: {toPersianDigits(result.dice1)} و {toPersianDigits(result.dice2)}
                  </span>
                  <span className="text-xs text-amber-200 font-vazir">
                    +{formatPersianCoins(result.coinsAwarded)} سکه برنده شدی!
                  </span>
                </div>
              )}
            </div>
          )}

          {/* Roll Button */}
          {canRoll ? (
            <button
              onClick={handleRoll}
              disabled={isRolling}
              className="w-full mt-3 py-2.5 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 text-amber-950 font-lalezar text-sm font-bold shadow-lg hover:brightness-110 active:scale-95 transition-all cursor-pointer"
            >
              {isRolling ? 'در حال غلتیدن تاس‌ها...' : 'تاس بریز (رایگان روزانه)'}
            </button>
          ) : (
            <div className="mt-3 p-2 rounded-xl bg-black/40 text-[11px] text-amber-300/80 font-vazir">
              تاس امروزت رو ریختی مشتی! فردا دوباره بیا سر تخته.
            </div>
          )}
        </div>

        {/* Legend */}
        <div className="p-2.5 rounded-xl bg-black/30 border border-amber-800/40 text-[10px] text-amber-200/80 font-vazir space-y-1 text-right">
          <div>• جفت شیش (۶ و ۶): ۵۰۰ سکه جایزه جک‌پات</div>
          <div>• هر جفت دیگر: ۱۵۰ سکه</div>
          <div>• تاس معمولی: مجموع دو تاس × ۱۰ سکه</div>
        </div>

        {/* Footer */}
        <div className="pt-2 mt-2 border-t border-[#522E18] text-center">
          <p className="text-[10px] text-amber-300/60 font-vazir">
            تخته‌نرد چایخانه • بخت و اقبال به کام لوتی‌ها
          </p>
        </div>
      </div>
    </div>
  );
};
