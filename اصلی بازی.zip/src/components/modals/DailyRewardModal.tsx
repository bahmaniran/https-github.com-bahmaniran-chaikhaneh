import React from 'react';
import { X, Gift, Sparkles, Check, Calendar, Star } from 'lucide-react';
import confetti from 'canvas-confetti';
import { soundEngine } from '../../audio/SoundEngine';
import { formatPersianCoins, toPersianDigits } from '../../utils/persianNumbers';
import bahmanAvatar from '../../assets/images/bahman_exact_avatar_1791919274915.jpg';

interface DailyRewardModalProps {
  isOpen: boolean;
  onClose: () => void;
  onClaim: (amount: number) => void;
  currentStreak: number;
  todayRewardAmount: number;
  isClaimedToday: boolean;
}

const STREAK_REWARDS = [
  { day: 1, coins: 50, label: 'روز اول' },
  { day: 2, coins: 70, label: 'روز دوم' },
  { day: 3, coins: 90, label: 'روز سوم' },
  { day: 4, coins: 120, label: 'روز چهارم' },
  { day: 5, coins: 150, label: 'روز پنجم' },
  { day: 6, coins: 180, label: 'روز ششم' },
  { day: 7, coins: 250, label: 'روز هفتم', isSpecial: true },
];

export const DailyRewardModal: React.FC<DailyRewardModalProps> = ({
  isOpen,
  onClose,
  onClaim,
  currentStreak,
  todayRewardAmount,
  isClaimedToday,
}) => {
  if (!isOpen) return null;

  const handleClaim = () => {
    soundEngine.playCoin();
    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#F59E0B', '#FBBF24', '#10B981', '#F43F5E'],
      });
    } catch {}
    onClaim(todayRewardAmount);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#180A03]/85 backdrop-blur-sm animate-fade-in select-none">
      <div className="relative w-full max-w-xs max-h-[92vh] overflow-y-auto rounded-[28px] p-4 bg-gradient-to-b from-[#3A1E0E] via-[#2C160A] to-[#1E0E06] border-3 border-[#F59E0B] shadow-[0_15px_40px_rgba(245,158,11,0.3)] text-[#FFFBF0]">
        {/* Close Button */}
        <button
          onClick={() => {
            soundEngine.playClick();
            onClose();
          }}
          className="absolute top-3 left-3 w-6 h-6 rounded-full bg-[#4A2613] hover:bg-[#66351B] text-amber-200 flex items-center justify-center transition-colors cursor-pointer z-10"
        >
          <X className="w-3.5 h-3.5" />
        </button>

        {/* Top Header Badge */}
        <div className="text-center pt-1 mb-2">
          <div className="relative w-16 h-16 mx-auto mb-2 rounded-full bg-gradient-to-tr from-amber-600 via-yellow-400 to-amber-700 p-0.5 flex items-center justify-center shadow-lg">
            <img
              src={bahmanAvatar}
              alt="اوستا بهمن"
              referrerPolicy="no-referrer"
              className="w-full h-full rounded-full object-cover"
            />
            <div className="absolute -top-1 -right-1 text-yellow-300 text-sm">✨</div>
            <div className="absolute -bottom-1 -left-1 w-5 h-5 rounded-full bg-amber-600 border border-yellow-200 flex items-center justify-center text-[10px] shadow">
              🎁
            </div>
          </div>

          <h2 className="font-lalezar text-base text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-amber-300 to-yellow-400 leading-tight">
            عیدی روزانه عمو بهمن
          </h2>
          <p className="text-[10px] text-amber-200/75 font-vazir mt-0.5">
            «دشت اول صبح و تبرک چایخانه برای پهلوون باوفا»
          </p>
        </div>

        {/* Big Today's Reward Badge */}
        <div className="my-2.5 p-2.5 rounded-2xl bg-gradient-to-r from-amber-950/90 via-[#3A1E0D] to-amber-950/90 border border-amber-500/60 text-center">
          <span className="text-[10px] text-amber-300/80 font-vazir block">
            {isClaimedToday ? 'عیدی امروز شما دریافت شد:' : 'عیدی امروز شما:'}
          </span>
          <div className="flex items-center justify-center gap-1.5 font-lalezar text-xl text-yellow-300 font-bold my-0.5">
            <span>+{formatPersianCoins(todayRewardAmount)}</span>
            <span className="text-sm">سکه زرین ★</span>
          </div>
          <span className="text-[9px] text-amber-200/60 font-vazir block">
            روز {toPersianDigits(currentStreak)} از دورهٔ ۷ روزه
          </span>
        </div>

        {/* 7-Day Streak Pills */}
        <div className="grid grid-cols-7 gap-1 my-3">
          {STREAK_REWARDS.map((item) => {
            const isPast = item.day < currentStreak;
            const isToday = item.day === currentStreak;

            return (
              <div
                key={item.day}
                className={`flex flex-col items-center justify-between p-1 rounded-xl border text-center transition-all ${
                  isToday
                    ? 'bg-amber-500/30 border-amber-300 text-yellow-300 ring-1 ring-amber-300 scale-105'
                    : isPast
                    ? 'bg-emerald-950/50 border-emerald-600/50 text-emerald-300'
                    : 'bg-[#180A04] border-[#381B0B] text-amber-200/50'
                }`}
              >
                <span className="text-[8px] font-vazir block">
                  {toPersianDigits(item.day)}
                </span>

                <div className="my-0.5">
                  {isPast || (isToday && isClaimedToday) ? (
                    <Check className="w-3 h-3 text-emerald-400 mx-auto" />
                  ) : item.isSpecial ? (
                    <Star className="w-3 h-3 text-yellow-400 fill-yellow-400 mx-auto animate-pulse" />
                  ) : (
                    <Gift className="w-2.5 h-2.5 text-amber-300/80 mx-auto" />
                  )}
                </div>

                <span className="text-[8px] font-lalezar font-bold block">
                  {toPersianDigits(item.coins)}
                </span>
              </div>
            );
          })}
        </div>

        {/* Action Button */}
        {isClaimedToday ? (
          <button
            onClick={() => {
              soundEngine.playClick();
              onClose();
            }}
            className="w-full py-2 px-4 rounded-xl bg-[#2A150A] hover:bg-[#3D2010] text-amber-300 font-lalezar text-xs border border-amber-700/60 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
          >
            <Check className="w-3.5 h-3.5 text-emerald-400" />
            <span>عیدی امروز دریافت شد (فردا سر بزن!)</span>
          </button>
        ) : (
          <button
            onClick={handleClaim}
            className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 hover:brightness-110 active:scale-95 text-amber-950 font-lalezar text-sm font-bold shadow-lg border border-yellow-200 flex items-center justify-center gap-1.5 transition-all cursor-pointer animate-pulse"
          >
            <Sparkles className="w-4 h-4" />
            <span>دشت اول صبح (دریافت عیدی)</span>
          </button>
        )}
      </div>
    </div>
  );
};
