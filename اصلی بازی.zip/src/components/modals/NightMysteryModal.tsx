import React, { useState } from 'react';
import { X, Key, Shield, Award, CheckCircle, RefreshCw, FileText, Lock } from 'lucide-react';
import { soundEngine } from '../../audio/SoundEngine';
import { toPersianDigits, formatPersianCoins } from '../../utils/persianNumbers';

interface NightMysteryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRewardCoins: (amount: number) => void;
}

// 4-digit vintage safe secret
const SECRET_CODE = [4, 7, 2, 9];

interface GuessRow {
  guess: number[];
  exact: number;
  partial: number;
}

export const NightMysteryModal: React.FC<NightMysteryModalProps> = ({
  isOpen,
  onClose,
  onRewardCoins,
}) => {
  const [activeTab, setActiveTab] = useState<'safe' | 'case'>('safe');

  // Safe cracking state
  const [currentInput, setCurrentInput] = useState<string>('');
  const [guesses, setGuesses] = useState<GuessRow[]>([]);
  const [isSafeSolved, setIsSafeSolved] = useState<boolean>(false);

  // Case file riddle state
  const [selectedSuspect, setSelectedSuspect] = useState<number | null>(null);
  const [isCaseSolved, setIsCaseSolved] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleKeyPress = (num: number) => {
    if (currentInput.length >= 4 || isSafeSolved) return;
    soundEngine.playClick();
    setCurrentInput((prev) => prev + num);
  };

  const handleDelete = () => {
    soundEngine.playClick();
    setCurrentInput((prev) => prev.slice(0, -1));
  };

  const handleCheckCode = () => {
    if (currentInput.length !== 4 || isSafeSolved) return;
    soundEngine.playGlassClink();

    const guessArr = currentInput.split('').map((c) => parseInt(c, 10));
    let exact = 0;
    let partial = 0;

    const secretCopy = [...SECRET_CODE];
    const guessCopy = [...guessArr];

    // Find exact matches
    for (let i = 0; i < 4; i++) {
      if (guessArr[i] === SECRET_CODE[i]) {
        exact++;
        secretCopy[i] = -1;
        guessCopy[i] = -2;
      }
    }

    // Find partial matches
    for (let i = 0; i < 4; i++) {
      if (guessCopy[i] !== -2) {
        const foundIdx = secretCopy.indexOf(guessCopy[i]);
        if (foundIdx !== -1) {
          partial++;
          secretCopy[foundIdx] = -1;
        }
      }
    }

    const newGuesses = [...guesses, { guess: guessArr, exact, partial }];
    setGuesses(newGuesses);
    setCurrentInput('');

    if (exact === 4) {
      setIsSafeSolved(true);
      soundEngine.playSanturVictory();
      onRewardCoins(250);
    }
  };

  const handleResetSafe = () => {
    soundEngine.playClick();
    setGuesses([]);
    setCurrentInput('');
    setIsSafeSolved(false);
  };

  const handleSolveCase = (suspectIndex: number) => {
    if (isCaseSolved) return;
    setSelectedSuspect(suspectIndex);
    setIsCaseSolved(true);

    if (suspectIndex === 1) {
      // Suspect 1 (مشتی جعفر ساعت‌ساز) is the correct culprit
      soundEngine.playSanturVictory();
      onRewardCoins(200);
    } else {
      soundEngine.playClick();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-[#14081E]/85 backdrop-blur-md animate-fade-in font-vazir select-none">
      <div className="relative w-full max-w-sm rounded-[32px] p-5 bg-gradient-to-b from-[#28183A] via-[#1E112E] to-[#140B20] border-4 border-[#7C3AED] shadow-[0_15px_50px_rgba(124,58,237,0.35)] text-[#FFFBF0]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#3B2254]">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-purple-500/20 border border-purple-400 flex items-center justify-center text-purple-300">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-lalezar text-base text-purple-300 leading-none">
                پرونده‌های شبانه لاله‌زار (حالت معمایی)
              </h2>
              <span className="text-[10px] text-purple-200/60">
                پاداش ویژه: تا ۲۵۰ سکه طلا ★
              </span>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playClick();
              onClose();
            }}
            className="w-7 h-7 rounded-full bg-[#2A1838] hover:bg-[#43265A] text-purple-200 flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Mode Selector Tabs */}
        <div className="flex items-center gap-1.5 my-3 bg-[#0E0617] p-1 rounded-2xl border border-[#3B2254]">
          <button
            onClick={() => {
              soundEngine.playClick();
              setActiveTab('safe');
            }}
            className={`flex-1 py-1.5 rounded-xl font-lalezar text-xs transition-all ${
              activeTab === 'safe'
                ? 'bg-purple-600 text-white shadow'
                : 'text-purple-300/70 hover:text-purple-100'
            }`}
          >
            🔐 باز کردن گاوصندوق
          </button>
          <button
            onClick={() => {
              soundEngine.playClick();
              setActiveTab('case');
            }}
            className={`flex-1 py-1.5 rounded-xl font-lalezar text-xs transition-all ${
              activeTab === 'case'
                ? 'bg-amber-600 text-white shadow'
                : 'text-amber-300/70 hover:text-amber-100'
            }`}
          >
            📜 پرونده عتیقه‌دزدی
          </button>
        </div>

        {/* Tab 1: Vintage Safe Cracking */}
        {activeTab === 'safe' ? (
          <div className="flex flex-col items-center">
            {/* Safe Screen / Combination Display */}
            <div className="w-full bg-[#0A0512] rounded-2xl p-3 border-2 border-purple-500/50 mb-3 text-center">
              <span className="text-[10px] text-purple-300/70 block mb-1">
                رمز ۴ رقمی گاوصندوق عتیقه را حدس بزنید:
              </span>
              <div className="flex items-center justify-center gap-2">
                {[0, 1, 2, 3].map((idx) => {
                  const char = currentInput[idx];
                  return (
                    <div
                      key={idx}
                      className="w-10 h-12 rounded-xl bg-[#1F1030] border border-purple-400 flex items-center justify-center font-lalezar text-xl text-yellow-300 shadow-inner"
                    >
                      {char ? toPersianDigits(char) : '•'}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* History of Previous Guesses */}
            <div className="w-full max-h-24 overflow-y-auto mb-2 space-y-1 pr-1">
              {guesses.map((g, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between px-3 py-1 bg-[#190C28] rounded-lg border border-purple-900/60 text-xs"
                >
                  <span className="font-lalezar text-yellow-200">
                    {g.guess.map((n) => toPersianDigits(n)).join(' ')}
                  </span>
                  <div className="flex items-center gap-2 text-[10px]">
                    <span className="text-emerald-400 font-bold">
                      {toPersianDigits(g.exact)} درست سرجا
                    </span>
                    <span className="text-amber-400">
                      {toPersianDigits(g.partial)} در رمز
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Result Toast if Solved */}
            {isSafeSolved ? (
              <div className="w-full p-3 rounded-2xl bg-emerald-950 border border-emerald-400 text-center my-2 animate-bounce">
                <span className="font-lalezar text-base text-emerald-300 block">
                  🎉 گاوصندوق باز شد!
                </span>
                <span className="text-xs text-emerald-200 font-vazir">
                  ۲۵۰ سکه طلا به صندوق چایخانه اضافه شد.
                </span>
              </div>
            ) : (
              /* Dial Keypad */
              <div className="w-full grid grid-cols-3 gap-1.5 my-1">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
                  <button
                    key={num}
                    onClick={() => handleKeyPress(num)}
                    className="py-2.5 rounded-xl bg-[#231238] hover:bg-[#381D58] active:scale-95 text-purple-100 font-lalezar text-base border border-purple-500/40 shadow transition-all"
                  >
                    {toPersianDigits(num)}
                  </button>
                ))}
                <button
                  onClick={handleDelete}
                  className="py-2.5 rounded-xl bg-[#2F1520] text-rose-300 font-lalezar text-sm border border-rose-900/60"
                >
                  پاک
                </button>
                <button
                  onClick={() => handleKeyPress(0)}
                  className="py-2.5 rounded-xl bg-[#231238] hover:bg-[#381D58] active:scale-95 text-purple-100 font-lalezar text-base border border-purple-500/40"
                >
                  {toPersianDigits(0)}
                </button>
                <button
                  onClick={handleCheckCode}
                  className="py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-lalezar text-sm font-bold border border-purple-300 shadow"
                >
                  بررسی
                </button>
              </div>
            )}
          </div>
        ) : (
          /* Tab 2: Detective Case File */
          <div className="flex flex-col text-right">
            <div className="bg-[#120B1C] p-3 rounded-2xl border border-amber-500/40 mb-3 text-xs leading-relaxed text-amber-100">
              <span className="font-lalezar text-amber-300 block mb-1">
                📋 گزارش کارآگاه: سرقت قندان فیروزه‌ای
              </span>
              <p>
                «دیشب ساعت ۲۲ قندان فیروزه‌ای قاجاری عمو بهمن غیبش زد! ۳ نفر در کافه حضور داشتند:
                ساعت‌ساز ساعت ۲۲:۱۰ دستش بند بود، شاگرد قهوه‌چی در انبار چای بود، اما یک نفر بوی تنباکوی شیرازی می‌داد که ردش کنار طاقچه مانده!»
              </p>
            </div>

            <div className="space-y-1.5 mb-3">
              {[
                { id: 0, name: '۱. اصغر شاگرد قهوه‌چی', alibi: 'می‌گوید تا ۲۲:۳۰ در انبار چای بوده' },
                { id: 1, name: '۲. مشتی جعفر ساعت‌ساز', alibi: 'بوی تنباکوی شیرازی از جیبش می‌آید!' },
                { id: 2, name: '۳. میرزا حبیب روزنامه‌نگار', alibi: 'سرگرم خواندن روزنامه اطلاعات بود' },
              ].map((s) => (
                <button
                  key={s.id}
                  disabled={isCaseSolved}
                  onClick={() => handleSolveCase(s.id)}
                  className={`w-full p-2.5 rounded-xl border text-xs font-vazir text-right transition-all ${
                    isCaseSolved && s.id === 1
                      ? 'bg-emerald-950 border-emerald-400 text-emerald-200 font-bold'
                      : isCaseSolved && selectedSuspect === s.id
                      ? 'bg-rose-950 border-rose-500 text-rose-200'
                      : 'bg-[#1F1030] border-[#3B2254] text-purple-100 hover:bg-[#2C1744]'
                  }`}
                >
                  <span className="font-lalezar text-sm text-yellow-300 block">{s.name}</span>
                  <span className="text-[10px] text-purple-200/70">{s.alibi}</span>
                </button>
              ))}
            </div>

            {isCaseSolved && (
              <div className="text-xs font-vazir text-center p-2 rounded-xl bg-purple-950/80 border border-purple-500/50 text-purple-200">
                {selectedSuspect === 1
                  ? '🎯 آفرین کارآگاه! مشتی جعفر قندان را برداشته بود. ۲۰۰ سکه اضافه شد.'
                  : 'اشتباه حدس زدی پهلوون! مجرم اصلی مشتی جعفر با بوی تنباکو بود.'}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
