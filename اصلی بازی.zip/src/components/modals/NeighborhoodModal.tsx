import React, { useState, useEffect } from 'react';
import {
  X,
  Trophy,
  Users,
  Shield,
  Award,
  Sparkles,
  UserCheck,
  RefreshCw,
  Radio,
  Calendar,
  Clock,
  ChevronLeft,
  Flame,
  Star,
  Gift,
  ArrowRight,
} from 'lucide-react';
import { MahallehMember, PlayerProfile, WeeklyLeaderboardCompetitor } from '../../types';
import { formatPersianCoins, toPersianDigits } from '../../utils/persianNumbers';
import { soundEngine } from '../../audio/SoundEngine';
import { fetchLiveLeaderboard, getStoredPlayerProfile } from '../../services/backendApi';
import {
  getWeeklyChallengeState,
  getWeeklyLeaderboard,
  getTimeRemainingUntilMonday,
} from '../../game/WeeklyChallengeService';

interface NeighborhoodModalProps {
  isOpen: boolean;
  onClose: () => void;
  playerLevel: number;
  playerScore?: number;
  onOpenRegister?: () => void;
  playerProfile?: PlayerProfile;
  onOpenWeeklyChallenge?: () => void;
  initialTab?: 'weekly' | 'neighborhoods';
}

const NEIGHBORHOODS = [
  { id: 'bazaar', name: 'محله بازار کهنه', slogan: 'کاسبان باصفا و چای دیشلمه اعلا', membersCount: 30, rank: 1 },
  { id: 'oodlajan', name: 'محله عودلاجان', slogan: 'تار و تنبور و استکان‌های لب‌سوز', membersCount: 29, rank: 2 },
  { id: 'sanglaj', name: 'محله سنگلج', slogan: 'پهلوانان نامی و مرام چایخانه‌ای', membersCount: 28, rank: 3 },
  { id: 'tajrish', name: 'محله تجریش و دربند', slogan: 'هوای کوهستان و چای دارچینی زعفرانی', membersCount: 30, rank: 4 },
];

const DEFAULT_LEADERBOARD: MahallehMember[] = [
  { id: '1', name: 'داش آکل شیراز', score: 3840, cupsServed: 128, rank: 1, badge: '👑 قهرمان هفته', avatarSeed: 1 },
  { id: '2', name: 'طیّب خان سنگلجی', score: 3420, cupsServed: 114, rank: 2, badge: '🥈 سماور نقره', avatarSeed: 2 },
  { id: '3', name: 'حاج مصطفی بلورفروش', score: 3100, cupsServed: 98, rank: 3, badge: '🥉 سماور برنز', avatarSeed: 3 },
  { id: '4', name: 'عمو رحیم کبابچی', score: 1620, cupsServed: 48, rank: 4, badge: 'عضو قدیمی', avatarSeed: 5 },
  { id: '5', name: 'مشتی صفر درشکه‌چی', score: 1450, cupsServed: 42, rank: 5, badge: 'عضو فعال', avatarSeed: 6 },
  { id: '6', name: 'سید جلال قناد', score: 1320, cupsServed: 39, rank: 6, badge: 'عضو فعال', avatarSeed: 7 },
];

export const NeighborhoodModal: React.FC<NeighborhoodModalProps> = ({
  isOpen,
  onClose,
  playerLevel,
  playerScore = 1850,
  onOpenRegister,
  playerProfile,
  onOpenWeeklyChallenge,
  initialTab = 'weekly',
}) => {
  const [activeTab, setActiveTab] = useState<'weekly' | 'neighborhoods'>(initialTab);
  const [selectedMahalleh, setSelectedMahalleh] = useState('bazaar');
  const [leaderboard, setLeaderboard] = useState<MahallehMember[]>(DEFAULT_LEADERBOARD);
  const [isLiveServer, setIsLiveServer] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [timeRemaining, setTimeRemaining] = useState(getTimeRemainingUntilMonday());

  const profile = playerProfile || getStoredPlayerProfile();
  const displayName =
    profile.isRegistered && profile.firstName
      ? `${profile.firstName} ${profile.lastName}`.trim()
      : profile.nickname || 'اوستای چایخانه (شما)';

  // Weekly Challenge state
  const weeklyState = getWeeklyChallengeState();
  const { leaderboard: weeklyLeaderboard, playerRank: weeklyPlayerRank, playerEntry: weeklyPlayerEntry } =
    getWeeklyLeaderboard(displayName, weeklyState.weeklyScore, weeklyState.completedStageIds.length);

  useEffect(() => {
    if (!isOpen) return;
    setTimeRemaining(getTimeRemainingUntilMonday());
    const interval = setInterval(() => {
      setTimeRemaining(getTimeRemainingUntilMonday());
    }, 1000);
    return () => clearInterval(interval);
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) return;

    let isMounted = true;
    setIsLoading(true);

    fetchLiveLeaderboard()
      .then((res) => {
        if (!isMounted) return;
        setIsLoading(false);
        if (res.isLive && res.topUsers.length > 0) {
          setIsLiveServer(true);
          const hasUser = res.topUsers.some((u) => u.name === displayName);
          if (!hasUser) {
            const userEntry: MahallehMember = {
              id: 'user_current',
              name: `${displayName} (شما)`,
              score: playerScore,
              cupsServed: Math.floor(playerScore / 30) + playerLevel,
              rank: res.topUsers.length + 1,
              badge: profile.isRegistered ? '✨ اوستای ثبت‌شده' : 'عضو نوپا',
              avatarSeed: 4,
            };
            setLeaderboard(
              [...res.topUsers, userEntry].sort((a, b) => b.score - a.score).map((u, i) => ({ ...u, rank: i + 1 }))
            );
          } else {
            setLeaderboard(res.topUsers);
          }
        } else {
          setIsLiveServer(false);
          const userEntry: MahallehMember = {
            id: 'player',
            name: `${displayName} (شما)`,
            score: playerScore,
            cupsServed: Math.floor(playerScore / 30) + playerLevel,
            rank: 4,
            badge: profile.isRegistered ? '✨ اوستای ثبت‌شده' : 'عضو نوپا',
            avatarSeed: 4,
          };
          const list = [...DEFAULT_LEADERBOARD, userEntry]
            .sort((a, b) => b.score - a.score)
            .map((u, i) => ({ ...u, rank: i + 1 }));
          setLeaderboard(list);
        }
      })
      .catch(() => {
        if (isMounted) {
          setIsLoading(false);
          setIsLiveServer(false);
        }
      });

  return () => {
      isMounted = false;
    };
  }, [isOpen, displayName, playerScore, playerLevel, profile.isRegistered]);

  if (!isOpen) return null;

  const currentMahalleh = NEIGHBORHOODS.find((m) => m.id === selectedMahalleh) || NEIGHBORHOODS[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-[#180A03]/85 backdrop-blur-sm animate-fade-in select-none">
      <div className="relative w-full max-w-md max-h-[92vh] overflow-y-auto rounded-[32px] p-5 bg-gradient-to-b from-[#3A1E0E] via-[#2C160A] to-[#1E0E06] border-4 border-[#D97706] shadow-2xl text-[#FFFBF0]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#522E18]">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-amber-500/20 border border-amber-400 flex items-center justify-center text-amber-300">
              <Trophy className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-lalezar text-base text-amber-300 leading-none">
                جام و رتبه‌بندی چایخانه
              </h2>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-[10px] text-amber-200/60 font-vazir">
                  پایان دور: دوشنبه ساعت ۰۰:۰۰
                </span>
                {isLiveServer ? (
                  <span className="inline-flex items-center gap-1 text-[9px] bg-emerald-950/80 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-500 font-bold">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    سرور زنده mrasan.ir
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 text-[9px] bg-amber-950/80 text-amber-300/80 px-2 py-0.5 rounded-full border border-amber-700">
                    <Radio className="w-2.5 h-2.5" />
                    پشتیبان محلی
                  </span>
                )}
              </div>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playClick();
              onClose();
            }}
            className="w-7 h-7 rounded-full bg-[#4A2613] hover:bg-[#66351B] text-amber-200 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* User Registration Status Bar */}
        <div className="my-2.5 p-2.5 rounded-2xl bg-gradient-to-r from-[#1E3A8A]/40 via-[#0D9488]/40 to-[#1E3A8A]/40 border border-[#2DD4BF]/50 flex items-center justify-between">
          <div className="text-right">
            <span className="text-[10px] text-teal-300 block font-vazir">
              اوستای چایخانه:
            </span>
            <span className="font-lalezar text-sm text-amber-200">
              {displayName}
            </span>
          </div>

          <button
            onClick={() => {
              soundEngine.playClick();
              if (onOpenRegister) onOpenRegister();
            }}
            className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-amber-950 font-lalezar text-xs font-bold shadow-md transition-transform active:scale-95 flex items-center gap-1 cursor-pointer"
          >
            <UserCheck className="w-3.5 h-3.5" />
            <span>{profile.isRegistered ? 'ویرایش نام' : 'ثبت نام'}</span>
          </button>
        </div>

        {/* PRIMARY NAVIGATION TABS (Weekly Leaderboard vs Neighborhoods League) */}
        <div className="grid grid-cols-2 gap-2 p-1 bg-[#180A04] rounded-2xl border border-amber-800/60 mb-3">
          <button
            onClick={() => {
              soundEngine.playClick();
              setActiveTab('weekly');
            }}
            className={`py-2 px-3 rounded-xl font-lalezar text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'weekly'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-400 text-amber-950 font-bold shadow-md'
                : 'text-amber-200/80 hover:text-amber-100'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>جدول امتیازات هفتگی</span>
            {weeklyState.completedStageIds.length < 5 && (
              <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            )}
          </button>

          <button
            onClick={() => {
              soundEngine.playClick();
              setActiveTab('neighborhoods');
            }}
            className={`py-2 px-3 rounded-xl font-lalezar text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'neighborhoods'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-400 text-amber-950 font-bold shadow-md'
                : 'text-amber-200/80 hover:text-amber-100'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>رتبه‌بندی محله‌ها</span>
          </button>
        </div>

        {/* TAB 1: WEEKLY LEADERBOARD (جدول امتیازات هفتگی) */}
        {activeTab === 'weekly' && (
          <div className="space-y-3 animate-fade-in">
            {/* Weekly Banner & Countdown */}
            <div className="p-3 rounded-2xl bg-gradient-to-b from-[#3A1B0B] to-[#200E05] border border-amber-500/50 relative overflow-hidden">
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] bg-amber-950 px-2 py-0.5 rounded-full border border-amber-600/80 text-amber-300 font-vazir">
                      هفته {toPersianDigits(weeklyState.weekNumber)}: چالش دوشنبه‌ها
                    </span>
                  </div>
                  <h3 className="font-lalezar text-sm text-yellow-300 mt-1">
                    {weeklyState.themeTitle}
                  </h3>
                </div>

                {onOpenWeeklyChallenge && (
                  <button
                    onClick={() => {
                      soundEngine.playClick();
                      onClose();
                      onOpenWeeklyChallenge();
                    }}
                    className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:brightness-110 text-amber-950 font-lalezar text-xs font-bold shadow-md flex items-center gap-1 transition-all active:scale-95 cursor-pointer"
                  >
                    <span>ورود به چالش</span>
                    <ArrowRight className="w-3 h-3 rotate-180" />
                  </button>
                )}
              </div>

              {/* Countdown clock */}
              <div className="flex items-center gap-1.5 mt-2.5 pt-2 border-t border-amber-900/60 text-[11px] font-vazir text-amber-200/90">
                <Clock className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>زمان تا بازنشانی و شروع چالش دوشنبه بعد:</span>
                <span className="font-lalezar text-yellow-300">
                  {toPersianDigits(timeRemaining.days)} روز و {toPersianDigits(timeRemaining.hours)} ساعت
                </span>
              </div>
            </div>

            {/* Current Player's Weekly Performance Card */}
            <div className="p-3 rounded-2xl bg-gradient-to-r from-amber-950/80 via-[#2A150A] to-amber-950/80 border-2 border-amber-400/80 shadow-md">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[11px] text-amber-300 font-vazir">
                  کارنامه هفتگی شما ({displayName}):
                </span>
                <span className="font-lalezar text-xs text-yellow-300 bg-[#160803] px-2 py-0.5 rounded-lg border border-amber-700">
                  رتبه #{toPersianDigits(weeklyPlayerRank)} در جدول
                </span>
              </div>

              <div className="grid grid-cols-3 gap-2 text-center pt-1">
                <div className="bg-[#180A04]/80 p-1.5 rounded-xl border border-amber-900/60">
                  <span className="text-[9px] text-amber-300/70 block font-vazir">امتیاز چالش</span>
                  <span className="font-lalezar text-sm text-yellow-300 font-bold">
                    {toPersianDigits(weeklyState.weeklyScore)} ★
                  </span>
                </div>

                <div className="bg-[#180A04]/80 p-1.5 rounded-xl border border-amber-900/60">
                  <span className="text-[9px] text-amber-300/70 block font-vazir">مراحل حل‌شده</span>
                  <span className="font-lalezar text-sm text-amber-100 font-bold">
                    {toPersianDigits(weeklyState.completedStageIds.length)} از ۵
                  </span>
                </div>

                <div className="bg-[#180A04]/80 p-1.5 rounded-xl border border-amber-900/60">
                  <span className="text-[9px] text-amber-300/70 block font-vazir">پاداش نهایی</span>
                  <span className="font-lalezar text-xs text-emerald-400 font-bold">
                    {weeklyPlayerRank === 1
                      ? '۲۵۰۰ سکه 👑'
                      : weeklyPlayerRank <= 3
                      ? '۱۵۰۰ سکه 🥈'
                      : weeklyPlayerRank <= 10
                      ? '۵۰۰ سکه 🎖️'
                      : '۲۵۰ سکه'}
                  </span>
                </div>
              </div>
            </div>

            {/* Weekly Reward Tiers Info Box */}
            <div className="p-2.5 rounded-2xl bg-[#180A04] border border-[#3E1E0F] text-[10px] font-vazir text-amber-200/80">
              <div className="flex items-center gap-1 text-amber-300 font-lalezar text-xs mb-1">
                <Gift className="w-3.5 h-3.5" />
                <span>جوایز اهدایی در بامداد هر دوشنبه:</span>
              </div>
              <div className="flex items-center justify-between text-[10px] pt-1 border-t border-amber-950/80">
                <span>🥇 رتبه ۱: ۲۵۰۰ سکه + نشان زرین</span>
                <span>🥈 رتبه ۲: ۱۵۰۰ سکه</span>
                <span>🥉 رتبه ۳: ۱۰۰۰ سکه</span>
                <span>🎖️ ۴ تا ۱۰: ۵۰۰ سکه</span>
              </div>
            </div>

            {/* Weekly Leaderboard List */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between px-3 text-[10px] text-amber-300/70 font-vazir">
                <span>رتبه و اوستای شرکت‌کننده</span>
                <div className="flex items-center gap-4">
                  <span>مراحل</span>
                  <span>امتیاز هفتگی</span>
                </div>
              </div>

              {weeklyLeaderboard.map((member) => {
                const isUser = member.isCurrentPlayer;

                return (
                  <div
                    key={member.id}
                    className={`flex items-center justify-between p-2.5 rounded-xl border transition-all ${
                      isUser
                        ? 'bg-gradient-to-r from-amber-900 via-amber-800 to-amber-900 border-amber-400 shadow-md text-amber-100 ring-2 ring-amber-400/60'
                        : 'bg-[#1F0F06] border-[#3D1E0C] text-[#FFE8D6]'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div
                        className={`w-6 h-6 rounded-full flex items-center justify-center font-lalezar text-xs shrink-0 ${
                          member.rank === 1
                            ? 'bg-yellow-400 text-yellow-950 font-bold'
                            : member.rank === 2
                            ? 'bg-slate-300 text-slate-900 font-bold'
                            : member.rank === 3
                            ? 'bg-amber-700 text-amber-100 font-bold'
                            : 'bg-[#33190C] text-amber-300'
                        }`}
                      >
                        {toPersianDigits(member.rank)}
                      </div>

                      <div className="text-right">
                        <span className="font-lalezar text-xs block text-amber-100">
                          {member.name}
                        </span>
                        <span className="text-[9px] text-amber-300/70 font-vazir block">
                          {member.badge} • {member.neighborhood}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 text-xs font-vazir">
                      <span className="text-amber-200/90 font-vazir text-[11px] bg-[#2A1308] px-2 py-0.5 rounded-md border border-amber-800/60 font-semibold">
                        {toPersianDigits(member.stagesCompleted)}/۵
                      </span>
                      <span className="font-lalezar text-yellow-300 font-bold min-w-[55px] text-left">
                        {formatPersianCoins(member.score)} ★
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 2: NEIGHBORHOODS LEAGUE (رتبه‌بندی محله‌ها) */}
        {activeTab === 'neighborhoods' && (
          <div className="animate-fade-in">
            {/* Mahalleh Selector Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto py-1 mb-2 no-scrollbar">
              {NEIGHBORHOODS.map((m) => (
                <button
                  key={m.id}
                  onClick={() => {
                    soundEngine.playClick();
                    setSelectedMahalleh(m.id);
                  }}
                  className={`px-3 py-1.5 rounded-full font-lalezar text-xs whitespace-nowrap transition-all border cursor-pointer ${
                    selectedMahalleh === m.id
                      ? 'bg-amber-500 text-amber-950 border-amber-300 font-bold shadow'
                      : 'bg-[#241107] text-amber-200/70 border-[#4D2812] hover:text-amber-100'
                  }`}
                >
                  {m.name}
                </button>
              ))}
            </div>

            {/* Neighborhood Banner Box */}
            <div className="bg-[#1A0B04] p-3 rounded-2xl border border-amber-500/40 mb-3 flex items-center justify-between">
              <div className="text-right">
                <div className="flex items-center gap-1.5">
                  <Shield className="w-4 h-4 text-amber-400" />
                  <h3 className="font-lalezar text-sm text-amber-200">{currentMahalleh.name}</h3>
                </div>
                <p className="text-[10px] text-amber-100/70 font-vazir mt-0.5">
                  {currentMahalleh.slogan}
                </p>
              </div>

              <div className="text-left bg-amber-950/60 px-2.5 py-1 rounded-xl border border-amber-800/80">
                <span className="text-[9px] text-amber-300 block">رتبه محله</span>
                <span className="font-lalezar text-base text-yellow-300">
                  #{toPersianDigits(currentMahalleh.rank)}
                </span>
              </div>
            </div>

            {/* Overall Mahalleh Leaderboard Table */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between px-3 text-[10px] text-amber-300/70 font-vazir">
                <span>رتبه و اوستا</span>
                <div className="flex items-center gap-4">
                  <span>استکان</span>
                  <span>امتیاز سماور</span>
                </div>
              </div>

              {leaderboard.map((member) => {
                const isUser =
                  member.name.includes('(شما)') || member.id === 'user_current' || member.id === 'player';

                return (
                  <div
                    key={member.id}
                    className={`flex items-center justify-between p-2.5 rounded-xl border transition-all ${
                      isUser
                        ? 'bg-gradient-to-r from-amber-900/90 via-amber-800/80 to-amber-900/90 border-amber-400 shadow-md text-amber-100 ring-1 ring-amber-400/50'
                        : 'bg-[#1F0F06] border-[#3D1E0C] text-[#FFE8D6]'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div
                        className={`w-6 h-6 rounded-full flex items-center justify-center font-lalezar text-xs shrink-0 ${
                          member.rank === 1
                            ? 'bg-yellow-400 text-yellow-950 font-bold'
                            : member.rank === 2
                            ? 'bg-slate-300 text-slate-900 font-bold'
                            : member.rank === 3
                            ? 'bg-amber-700 text-amber-100 font-bold'
                            : 'bg-[#33190C] text-amber-300'
                        }`}
                      >
                        {toPersianDigits(member.rank)}
                      </div>

                      <div className="text-right">
                        <span className="font-lalezar text-xs block text-amber-100">
                          {member.name}
                        </span>
                        <span className="text-[9px] text-amber-300/70 font-vazir block">
                          {member.badge}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-5 text-xs font-vazir">
                      <span className="text-amber-200/90 font-vazir font-semibold">
                        {toPersianDigits(member.cupsServed)}
                      </span>
                      <span className="font-lalezar text-amber-300 font-bold min-w-[50px] text-left">
                        {formatPersianCoins(member.score)} ★
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Designer Credits Footer */}
        <div className="mt-4 pt-3 border-t border-[#3E1F0F] text-center text-[10px] text-amber-300/80 font-vazir flex items-center justify-between">
          <span className="font-lalezar text-yellow-300">طراح: مهندس بامزد</span>
          <a
            href="https://bahmanbamzad.ir"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:underline font-vazir text-amber-200 font-semibold"
          >
            bahmanbamzad.ir
          </a>
          <a href="tel:09115664271" className="font-vazir text-emerald-400 font-bold">
            ۰۹۱۱۵۶۶۴۲۷۱
          </a>
        </div>
      </div>
    </div>
  );
};
