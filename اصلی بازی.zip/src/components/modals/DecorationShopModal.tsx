import React, { useState } from 'react';
import { X, Check, ShoppingBag, Sparkles, Star } from 'lucide-react';
import { ShopItem, SugarCubeItem } from '../../types';
import { formatPersianCoins, toPersianDigits } from '../../utils/persianNumbers';
import { soundEngine } from '../../audio/SoundEngine';

interface DecorationShopModalProps {
  isOpen: boolean;
  onClose: () => void;
  coins: number;
  unlockedItems: string[];
  equippedCarpet: string;
  equippedSamovar: string;
  equippedWindow: string;
  sugarCubesCollected: number[];
  onBuyItem: (item: ShopItem) => void;
  onEquipItem: (item: ShopItem) => void;
}

const DEFAULT_SHOP_ITEMS: ShopItem[] = [
  // Carpets
  {
    id: 'carpet_gelim',
    category: 'carpet',
    name: 'گلیم ساده عشایری',
    description: 'دستباف و خودمانی',
    price: 0,
    isUnlocked: true,
    isEquipped: true,
    tier: 1,
  },
  {
    id: 'carpet_laki',
    category: 'carpet',
    name: 'قالیچه لاکی کاشان',
    description: 'طرح لچک ترنج اصیل',
    price: 320,
    isUnlocked: false,
    isEquipped: false,
    isSpecialOffer: true, // DECOY EFFECT
    tier: 2,
  },
  {
    id: 'carpet_tabriz',
    category: 'carpet',
    name: 'فرش دستباف تبریز',
    description: 'تار و پود ابریشم اعلی',
    price: 850,
    isUnlocked: false,
    isEquipped: false,
    tier: 3,
  },

  // Samovars
  {
    id: 'samovar_halabi',
    category: 'samovar',
    name: 'سماور حلبی جمع‌وجور',
    description: 'ساده و پرخاطره',
    price: 0,
    isUnlocked: true,
    isEquipped: true,
    tier: 1,
  },
  {
    id: 'samovar_berenji',
    category: 'samovar',
    name: 'سماور برنجی زغالی',
    description: 'حرارت عالی با قلقل دلنشین',
    price: 290,
    isUnlocked: false,
    isEquipped: false,
    isSpecialOffer: true, // DECOY EFFECT
    tier: 2,
  },
  {
    id: 'samovar_talakoob',
    category: 'samovar',
    name: 'سماور طلاکوب درباری',
    description: 'نقش شیر و خورشید سلطنتی',
    price: 900,
    isUnlocked: false,
    isEquipped: false,
    tier: 3,
  },

  // Windows
  {
    id: 'window_khaki',
    category: 'window',
    name: 'کوچه خاکی بازار',
    description: 'هوای تازه کوچه آشتی‌کنان',
    price: 0,
    isUnlocked: true,
    isEquipped: true,
    tier: 1,
  },
  {
    id: 'window_hoz',
    category: 'window',
    name: 'حیاط حوض‌دار با ماهی قرمز',
    description: 'عطر گل شمعدانی و آب‌پاشی',
    price: 350,
    isUnlocked: false,
    isEquipped: false,
    isSpecialOffer: true, // DECOY EFFECT
    tier: 2,
  },
  {
    id: 'window_lalezar',
    category: 'window',
    name: 'ارسی رنگین لاله زار',
    description: 'نورهای رنگی با شیشه قجری',
    price: 950,
    isUnlocked: false,
    isEquipped: false,
    tier: 3,
  },
];

const ANTIQUE_SUGAR_CUBES: SugarCubeItem[] = [
  { id: 1, name: 'قند کله سنقر', era: 'دوران صفوی', unlocked: true, description: 'بلورین و شفاف و خالص' },
  { id: 2, name: 'نبات زعفرانی یزد', era: 'دوران زندیه', unlocked: false, description: 'پر از نگین‌های طلایی زعفران' },
  { id: 3, name: 'حبه قند قجری', era: 'دوران قاجار', unlocked: false, description: 'شیرین‌کننده بزم‌های شاهانه' },
  { id: 4, name: 'پولکی کنجدی اصفهان', era: 'عهد کهن', unlocked: false, description: 'ترد و معطر با عطر هل' },
  { id: 5, name: 'شکرپنیر هل‌دار بجنورد', era: 'عصر طلایی', unlocked: false, description: 'نرم و حل‌شونده روی زبان' },
];

export const DecorationShopModal: React.FC<DecorationShopModalProps> = ({
  isOpen,
  onClose,
  coins,
  unlockedItems,
  equippedCarpet,
  equippedSamovar,
  equippedWindow,
  sugarCubesCollected,
  onBuyItem,
  onEquipItem,
}) => {
  const [activeCategory, setActiveCategory] = useState<'carpet' | 'samovar' | 'window' | 'sugarcubes'>('carpet');

  if (!isOpen) return null;

  const currentCategoryItems = DEFAULT_SHOP_ITEMS.filter((i) => i.category === activeCategory);

  const isEquipped = (item: ShopItem) => {
    if (item.category === 'carpet') return equippedCarpet === item.id;
    if (item.category === 'samovar') return equippedSamovar === item.id;
    if (item.category === 'window') return equippedWindow === item.id;
    return false;
  };

  const isUnlocked = (item: ShopItem) => {
    return item.price === 0 || unlockedItems.includes(item.id);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-[#180A03]/85 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-md max-h-[92vh] overflow-y-auto rounded-[32px] p-5 bg-gradient-to-b from-[#3A1E0E] via-[#2A1408] to-[#1E0E06] border-4 border-[#B86D36] shadow-2xl text-[#FFFBF0]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#522E18]">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-amber-500/20 border border-amber-400 flex items-center justify-center text-amber-300">
              <ShoppingBag className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-lalezar text-base text-amber-300 leading-none">
                دکان عتیقه‌جات و تزیینات عمو بهمن
              </h2>
              <span className="text-[10px] text-amber-200/60 font-vazir">
                موجودی شما: {formatPersianCoins(coins)} سکه طلا ★
              </span>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playClick();
              onClose();
            }}
            className="w-7 h-7 rounded-full bg-[#4A2613] hover:bg-[#66351B] text-amber-200 flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Category Tabs */}
        <div className="flex items-center justify-between gap-1 my-3 bg-[#1A0C05] p-1 rounded-2xl border border-[#4A2711]">
          <button
            onClick={() => {
              soundEngine.playClick();
              setActiveCategory('carpet');
            }}
            className={`flex-1 py-1.5 rounded-xl font-lalezar text-xs transition-all ${
              activeCategory === 'carpet'
                ? 'bg-amber-600 text-white shadow'
                : 'text-amber-200/70 hover:text-amber-100'
            }`}
          >
            فرش و قالی
          </button>
          <button
            onClick={() => {
              soundEngine.playClick();
              setActiveCategory('samovar');
            }}
            className={`flex-1 py-1.5 rounded-xl font-lalezar text-xs transition-all ${
              activeCategory === 'samovar'
                ? 'bg-amber-600 text-white shadow'
                : 'text-amber-200/70 hover:text-amber-100'
            }`}
          >
            سماور
          </button>
          <button
            onClick={() => {
              soundEngine.playClick();
              setActiveCategory('window');
            }}
            className={`flex-1 py-1.5 rounded-xl font-lalezar text-xs transition-all ${
              activeCategory === 'window'
                ? 'bg-amber-600 text-white shadow'
                : 'text-amber-200/70 hover:text-amber-100'
            }`}
          >
            پنجره و ارسی
          </button>
          <button
            onClick={() => {
              soundEngine.playClick();
              setActiveCategory('sugarcubes');
            }}
            className={`flex-1 py-1.5 rounded-xl font-lalezar text-xs transition-all ${
              activeCategory === 'sugarcubes'
                ? 'bg-teal-600 text-white shadow'
                : 'text-teal-200/70 hover:text-teal-100'
            }`}
          >
            کلکسیون قند
          </button>
        </div>

        {/* 3-Column Decoy Effect Layout for Shop Items */}
        {activeCategory !== 'sugarcubes' ? (
          <div className="grid grid-cols-3 gap-2 my-2 items-center">
            {currentCategoryItems.map((item) => {
              const unlocked = isUnlocked(item);
              const equipped = isEquipped(item);
              const isSpecial = item.isSpecialOffer; // Middle Decoy

              return (
                <div
                  key={item.id}
                  className={`relative flex flex-col items-center justify-between p-2.5 rounded-2xl border transition-all ${
                    isSpecial
                      ? 'scale-105 z-10 bg-gradient-to-b from-[#4A2613] to-[#2E1609] border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.3)]'
                      : 'bg-[#221006] border-[#4A2613] text-[#FFE8D6]'
                  }`}
                >
                  {/* Decoy Ribbon */}
                  {isSpecial && (
                    <div className="absolute -top-2.5 bg-gradient-to-r from-red-600 to-amber-500 text-white text-[9px] font-bold px-2 py-0.5 rounded-full shadow border border-amber-200 font-lalezar">
                      پیشنهاد ویژه
                    </div>
                  )}

                  <div className="w-10 h-10 rounded-full bg-[#1A0B04] border border-amber-500/40 flex items-center justify-center text-xl my-1">
                    {item.category === 'carpet' ? '🧶' : item.category === 'samovar' ? '🫖' : '🪟'}
                  </div>

                  <h3 className="font-lalezar text-xs text-amber-200 text-center leading-tight my-1">
                    {item.name}
                  </h3>
                  <p className="text-[9px] text-amber-300/70 text-center font-vazir line-clamp-2 mb-2">
                    {item.description}
                  </p>

                  {/* Price / Equip Button */}
                  {equipped ? (
                    <div className="w-full py-1 text-center bg-teal-900/80 text-teal-200 rounded-lg text-[10px] font-lalezar border border-teal-400 flex items-center justify-center gap-1">
                      <Check className="w-3 h-3" />
                      <span>استفاده شده</span>
                    </div>
                  ) : unlocked ? (
                    <button
                      onClick={() => {
                        soundEngine.playClick();
                        onEquipItem(item);
                      }}
                      className="w-full py-1 bg-amber-500 hover:bg-amber-400 text-amber-950 font-lalezar text-[11px] rounded-lg transition-colors font-bold"
                    >
                      نصب روی دکور
                    </button>
                  ) : (
                    <button
                      onClick={() => {
                        if (coins >= item.price) {
                          soundEngine.playCoin();
                          onBuyItem(item);
                        } else {
                          soundEngine.playClick();
                        }
                      }}
                      disabled={coins < item.price}
                      className={`w-full py-1 text-[10px] font-lalezar rounded-lg transition-all flex items-center justify-center gap-1 ${
                        coins >= item.price
                          ? 'bg-gradient-to-r from-amber-600 to-yellow-500 text-amber-950 font-bold hover:brightness-110'
                          : 'bg-[#3A1E0D] text-amber-400/50 cursor-not-allowed'
                      }`}
                    >
                      <span>{formatPersianCoins(item.price)}</span>
                      <span>★</span>
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          /* Sugar Cubes Collection View */
          <div className="space-y-2 my-2">
            <div className="text-xs text-teal-300 font-vazir mb-2 text-right">
              حلقه‌های زرین قند را با تکمیل استکان‌های درخشان کشف کنید (۱ از ۵ قفل‌گشایی شده):
            </div>
            {ANTIQUE_SUGAR_CUBES.map((cube) => {
              const isFound = cube.unlocked || sugarCubesCollected.includes(cube.id);
              return (
                <div
                  key={cube.id}
                  className={`flex items-center justify-between p-3 rounded-2xl border transition-all ${
                    isFound
                      ? 'bg-[#1D3A34] border-teal-400 text-teal-100 shadow-sm'
                      : 'bg-[#1A0C06] border-[#3D1E0C] text-gray-500 opacity-60'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-black/40 border border-teal-400/50 flex items-center justify-center text-lg">
                      {isFound ? '✨' : '🔒'}
                    </div>
                    <div className="text-right">
                      <h4 className="font-lalezar text-xs sm:text-sm text-amber-200">
                        {cube.name}
                      </h4>
                      <p className="text-[10px] font-vazir text-teal-200/80">
                        {cube.era} · {cube.description}
                      </p>
                    </div>
                  </div>

                  <span className="font-lalezar text-xs text-amber-300">
                    {isFound ? 'موجود در موزه ✓' : 'قفل'}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
