import React, { useState } from 'react';
import { X, Phone, Globe, User, Check, Copy, Heart, ShieldCheck, MessageCircle, Sparkles } from 'lucide-react';
import { soundEngine } from '../../audio/SoundEngine';
import { toPersianDigits } from '../../utils/persianNumbers';

interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ContactModal: React.FC<ContactModalProps> = ({ isOpen, onClose }) => {
  const [copiedField, setCopiedField] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (text: string, field: string) => {
    soundEngine.playClick();
    navigator.clipboard?.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-[#180A03]/85 backdrop-blur-sm animate-fade-in select-none">
      <div className="relative w-full max-w-sm max-h-[92vh] overflow-y-auto rounded-[32px] p-5 bg-gradient-to-b from-[#3A1E0E] via-[#2C160A] to-[#1E0E06] border-4 border-[#F59E0B] shadow-[0_15px_50px_rgba(245,158,11,0.3)] text-[#FFFBF0]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#522E18]">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-600 via-amber-400 to-yellow-300 p-0.5 flex items-center justify-center shadow-lg">
              <div className="w-full h-full rounded-full bg-[#200F05] flex items-center justify-center text-amber-300">
                <Phone className="w-4 h-4" />
              </div>
            </div>
            <div>
              <h2 className="font-lalezar text-base text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-amber-300 to-yellow-400 leading-tight">
                ارتباط با ما و پشتیبانی
              </h2>
              <p className="text-[10px] text-amber-200/70 font-vazir">
                شناسنامه و راه‌های ارتباطی چایخانه
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playClick();
              onClose();
            }}
            className="w-7 h-7 rounded-full bg-[#4A2613] hover:bg-[#66351B] text-amber-200 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Designer Card */}
        <div className="my-3.5 p-3.5 rounded-2xl bg-gradient-to-b from-[#3D1E0C] to-[#251107] border-2 border-amber-500/60 text-center relative overflow-hidden shadow-lg">
          <div className="w-16 h-16 mx-auto rounded-full bg-gradient-to-tr from-amber-600 via-yellow-400 to-amber-700 p-0.5 flex items-center justify-center shadow-md mb-2">
            <div className="w-full h-full rounded-full bg-[#180A04] flex items-center justify-center text-amber-300">
              <User className="w-8 h-8 text-yellow-300" />
            </div>
          </div>

          <span className="text-[10px] text-amber-400 font-vazir bg-amber-950/80 px-2 py-0.5 rounded-full border border-amber-700/80 inline-block mb-1">
            طراح و برنامه‌نویس ارشد
          </span>
          <h3 className="font-lalezar text-lg text-yellow-200">
            طراح مهندس بامزد
          </h3>
          <p className="text-[11px] text-amber-200/80 font-vazir mt-0.5">
            طراحی اختصاصی گیم‌پلی سنتی ایرانی، بهینه‌سازی سبک و اجرای بدون لگ
          </p>
        </div>

        {/* Contact Links */}
        <div className="space-y-2.5 mb-3.5">
          {/* Website */}
          <div className="p-3 rounded-2xl bg-[#1A0B04] border border-amber-600/40 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-amber-950/90 border border-amber-700/70 flex items-center justify-center text-amber-300">
                <Globe className="w-4 h-4" />
              </div>
              <div className="text-right">
                <span className="text-[10px] text-amber-300/70 block font-vazir">وب‌سایت رسمی:</span>
                <a
                  href="https://bahmanbamzad.ir"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-lalezar text-sm text-yellow-300 hover:underline ltr inline-block"
                  dir="ltr"
                >
                  bahmanbamzad.ir
                </a>
              </div>
            </div>

            <button
              onClick={() => handleCopy('https://bahmanbamzad.ir', 'website')}
              className="px-2.5 py-1.5 rounded-xl bg-[#2D160A] hover:bg-[#452310] text-amber-200 text-xs font-vazir flex items-center gap-1 border border-amber-700/60 transition-all active:scale-95 cursor-pointer"
            >
              {copiedField === 'website' ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-300 text-[10px]">کپی شد</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span className="text-[10px]">کپی آدرس</span>
                </>
              )}
            </button>
          </div>

          {/* Phone Number */}
          <div className="p-3 rounded-2xl bg-[#1A0B04] border border-amber-600/40 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-amber-950/90 border border-amber-700/70 flex items-center justify-center text-emerald-400">
                <Phone className="w-4 h-4" />
              </div>
              <div className="text-right">
                <span className="text-[10px] text-amber-300/70 block font-vazir">شماره تماس و پشتیبانی:</span>
                <a
                  href="tel:09115664271"
                  className="font-lalezar text-sm text-emerald-300 hover:underline ltr inline-block tracking-wider"
                  dir="ltr"
                >
                  09115664271 ({toPersianDigits('09115664271')})
                </a>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <a
                href="tel:09115664271"
                className="px-2.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-lalezar flex items-center gap-1 transition-all active:scale-95 cursor-pointer shadow"
              >
                <span>تماس</span>
              </a>

              <button
                onClick={() => handleCopy('09115664271', 'phone')}
                className="p-1.5 rounded-xl bg-[#2D160A] hover:bg-[#452310] text-amber-200 border border-amber-700/60 transition-all active:scale-95 cursor-pointer"
                title="کپی شماره"
              >
                {copiedField === 'phone' ? (
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <Copy className="w-3.5 h-3.5" />
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Lightweight & Performance Guarantee Note */}
        <div className="p-2.5 rounded-2xl bg-[#120703] border border-amber-900/60 flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-amber-400 shrink-0" />
          <p className="text-[10px] text-amber-200/80 font-vazir leading-relaxed">
            نسخه فوق‌سبک و بهینه‌سازی شده چایخانه عمو بهمن؛ بدون مصرف اینترنت سنگین، فریم‌ریت روان ۶۰fps و سازگار با انواع موبایل و وب‌ویو.
          </p>
        </div>
      </div>
    </div>
  );
};
