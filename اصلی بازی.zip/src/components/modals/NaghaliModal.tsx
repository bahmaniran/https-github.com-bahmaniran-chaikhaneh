import React from 'react';
import { X, Sparkles, Award, Check } from 'lucide-react';
import { soundEngine } from '../../audio/SoundEngine';
import { toPersianDigits } from '../../utils/persianNumbers';
import { NaghaliState } from '../../types';

interface NaghaliModalProps {
  isOpen: boolean;
  onClose: () => void;
  naghaliState: NaghaliState;
  onToggleActive: () => void;
  onClaimPrize: () => void;
}

const SHAHNAMEH_VERSES = [
  'به نام خداوند جان و خرد / کزین برتر اندیشه برنگذرد',
  'چنین گفت رستم به سهراب یل / که بی نام هرگز نماند عمل',
  'چو رستم برانگیخت رخش نبرد / برآمد ز قلب سپه تیره گرد',
  'یکی داستان است پر آب چشم / دل نازک از رستم آید به خشم',
];

export const NaghaliModal: React.FC<NaghaliModalProps> = ({
  isOpen,
  onClose,
  naghaliState,
  onToggleActive,
  onClaimPrize,
}) => {
  if (!isOpen) return null;

  const currentVerse = SHAHNAMEH_VERSES[Math.floor(Date.now() / 15000) % SHAHNAMEH_VERSES.length];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-[#180A03]/85 backdrop-blur-sm animate-fade-in select-none">
      <div className="relative w-full max-w-sm max-h-[92vh] overflow-y-auto rounded-[32px] p-5 bg-gradient-to-b from-[#381B0C] via-[#2A1408] to-[#1C0D05] border-4 border-amber-600 shadow-[0_15px_50px_rgba(217,119,6,0.35)] text-[#FFFBF0]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#522E18]">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-600 via-amber-400 to-yellow-300 p-0.5 flex items-center justify-center shadow-lg">
              <div className="w-full h-full rounded-full bg-[#180A04] flex items-center justify-center text-amber-300 font-lalezar text-sm">
                🪘
              </div>
            </div>
            <div>
              <h2 className="font-lalezar text-base text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-amber-300 to-yellow-400 leading-tight">
                رویداد شب‌های نقالی و مرشد
              </h2>
              <p className="text-[10px] text-amber-200/70 font-vazir">
                روایت حماسه رستم و سهراب با ضرب زورخانه
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playClick();
              onClose();
            }}
            className="w-7 h-7 rounded-full bg-[#4A2613] hover:bg-[#66351B] text-amber-200 flex items-center justify-center cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Morshed's Verse */}
        <div className="my-3 p-3 rounded-2xl bg-amber-950/70 border border-amber-600/50 text-center relative overflow-hidden">
          <span className="text-[9px] text-amber-400 font-vazir block mb-1">
            📜 بیت منتخب مرشد چایخانه:
          </span>
          <p className="font-nastaliq text-sm sm:text-base text-yellow-200 tracking-wide drop-shadow leading-loose">
            «{currentVerse}»
          </p>
        </div>

        {/* 9-Piece Traditional Coffeehouse Painting Grid */}
        <div className="my-3">
          <div className="flex items-center justify-between mb-1.5 px-1">
            <span className="font-lalezar text-xs text-yellow-300">
              تابلو نقاشی قهوه‌خانه‌ای رستم دستان
            </span>
            <span className="text-[10px] font-lalezar text-amber-300 bg-amber-950 px-2 py-0.5 rounded-full border border-amber-700">
              {toPersianDigits(naghaliState.collectedPieces.length)} از ۹ قطعه
            </span>
          </div>

          <div className="grid grid-cols-3 gap-1.5 p-2 rounded-2xl bg-[#140803] border-2 border-[#8B5226] shadow-inner">
            {[0, 1, 2, 3, 4, 5, 6, 7, 8].map((idx) => {
              const hasPiece = naghaliState.collectedPieces.includes(idx);
              return (
                <div
                  key={idx}
                  className={`aspect-square rounded-xl flex flex-col items-center justify-center border transition-all ${
                    hasPiece
                      ? 'bg-gradient-to-br from-amber-700 via-amber-600 to-yellow-600 border-yellow-300 shadow-md text-yellow-100'
                      : 'bg-[#210D04]/80 border-stone-800 text-stone-600'
                  }`}
                >
                  {hasPiece ? (
                    <div className="text-center">
                      <span className="text-lg">⚔️</span>
                      <span className="text-[9px] font-lalezar block -mt-1 text-yellow-200">
                        قطعه {toPersianDigits(idx + 1)}
                      </span>
                    </div>
                  ) : (
                    <div className="text-center opacity-40">
                      <span className="text-sm">🔒</span>
                      <span className="text-[8px] font-vazir block mt-0.5">ناپیدا</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
          <span className="text-[9px] text-amber-200/70 font-vazir block text-center mt-1">
            با بردن هر مرحله در حالت نقالی، ۱ قطعه از پازل نقاشی آزاد می‌شود!
          </span>
        </div>

        {/* Reward Status & Grand Prize */}
        {naghaliState.isPaintingCompleted ? (
          <div className="p-3 rounded-2xl bg-gradient-to-r from-emerald-950 to-teal-950 border border-emerald-400 text-center animate-pulse">
            <Award className="w-8 h-8 text-yellow-300 mx-auto mb-1" />
            <h4 className="font-lalezar text-sm text-yellow-200">تابلو کامل شد!</h4>
            <p className="text-[10px] text-emerald-200 font-vazir">
              جایزه ۱۰۰۰ سکه + پوسته اختصاصی «استکان طلایی شاهنامه» آنلاک شد!
            </p>
            {!naghaliState.hasClaimedReward && (
              <button
                onClick={() => {
                  soundEngine.playClick();
                  onClaimPrize();
                }}
                className="mt-2 px-4 py-1.5 rounded-xl bg-gradient-to-r from-yellow-500 to-amber-500 text-amber-950 font-lalezar text-xs font-bold shadow-md hover:brightness-110 cursor-pointer"
              >
                دریافت ۱۰۰۰ سکه و پوسته طلایی
              </button>
            )}
          </div>
        ) : (
          <div className="flex items-center justify-between p-2.5 rounded-2xl bg-[#2A1408] border border-amber-600/40">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-yellow-400" />
              <div>
                <span className="font-lalezar text-xs text-yellow-200 block">
                  حالت نقالی شاهنامه
                </span>
                <span className="text-[9px] text-amber-200/70 font-vazir">
                  نورپردازی فانوس گرم و روایت مرشد
                </span>
              </div>
            </div>
            <button
              onClick={() => {
                soundEngine.playClick();
                onToggleActive();
              }}
              className={`px-3 py-1 rounded-full font-lalezar text-xs transition-all cursor-pointer ${
                naghaliState.isActive
                  ? 'bg-amber-500 text-amber-950 font-bold border border-yellow-200'
                  : 'bg-stone-800 text-stone-300 border border-stone-600'
              }`}
            >
              {naghaliState.isActive ? 'فعال (فانوس روشن)' : 'روشن کردن'}
            </button>
          </div>
        )}

        {/* Footer */}
        <div className="pt-2 mt-2 border-t border-[#522E18] text-center">
          <p className="text-[10px] text-amber-300/60 font-vazir">
            شب‌های نقالی چایخانه • زنده نگه‌داشتن آیین کهن پهلوانی
          </p>
        </div>
      </div>
    </div>
  );
};
