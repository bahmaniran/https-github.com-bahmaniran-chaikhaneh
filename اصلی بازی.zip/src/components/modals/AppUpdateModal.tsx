import React, { useState } from 'react';
import {
  Download,
  Sparkles,
  CheckCircle2,
  X,
  AlertCircle,
  ExternalLink,
  ShieldCheck,
  Smartphone,
  RefreshCw,
} from 'lucide-react';
import { AppUpdateInfo } from '../../types';
import { toPersianDigits } from '../../utils/persianNumbers';
import { soundEngine } from '../../audio/SoundEngine';
import { dismissUpdatePrompt } from '../../services/UpdateService';

interface AppUpdateModalProps {
  isOpen: boolean;
  onClose: () => void;
  updateInfo: AppUpdateInfo | null;
  onCheckAgain?: () => void;
}

export const AppUpdateModal: React.FC<AppUpdateModalProps> = React.memo(({
  isOpen,
  onClose,
  updateInfo,
  onCheckAgain,
}) => {
  const [downloadProgress, setDownloadProgress] = useState<number | null>(null);
  const [isDownloading, setIsDownloading] = useState<boolean>(false);
  const [downloadCompleted, setDownloadCompleted] = useState<boolean>(false);

  if (!isOpen || !updateInfo) return null;

  const handleStartDownload = () => {
    soundEngine.playCoin();
    setIsDownloading(true);
    setDownloadProgress(5);

    // Simulate smooth download progress indicator before triggering direct APK download
    let current = 5;
    const interval = setInterval(() => {
      current += Math.floor(Math.random() * 15) + 10;
      if (current >= 100) {
        current = 100;
        clearInterval(interval);
        setDownloadProgress(100);
        setIsDownloading(false);
        setDownloadCompleted(true);
        soundEngine.playSanturVictory();

        // Trigger direct browser / APK installer download
        try {
          const downloadLink = document.createElement('a');
          downloadLink.href = updateInfo.apkDownloadUrl;
          downloadLink.download = `bahman-teahouse-v${updateInfo.latestVersion}.apk`;
          downloadLink.target = '_blank';
          downloadLink.rel = 'noopener noreferrer';
          document.body.appendChild(downloadLink);
          downloadLink.click();
          document.body.removeChild(downloadLink);
        } catch {
          window.open(updateInfo.apkDownloadUrl, '_blank');
        }
      } else {
        setDownloadProgress(current);
      }
    }, 180);
  };

  const handleDismiss = () => {
    soundEngine.playClick();
    if (!updateInfo.isMandatory) {
      dismissUpdatePrompt(updateInfo.latestVersion);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-[#180A03]/85 backdrop-blur-sm animate-fade-in select-none">
      <div className="relative w-full max-w-sm rounded-[32px] p-5 bg-gradient-to-b from-[#3A1E0E] via-[#2C160A] to-[#1E0E06] border-4 border-[#F59E0B] shadow-[0_15px_50px_rgba(245,158,11,0.35)] text-[#FFFBF0] overflow-hidden">
        {/* Subtle decorative glowing corner */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />

        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#522E18]">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-amber-600 via-amber-400 to-yellow-300 p-0.5 flex items-center justify-center shadow-lg">
              <div className="w-full h-full rounded-full bg-[#200F05] flex items-center justify-center text-amber-300">
                <Download className="w-5 h-5 animate-bounce" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="font-lalezar text-base text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-amber-300 to-yellow-400 leading-tight">
                  بروزرسانی مستقیم درون‌برنامه‌ای
                </h2>
              </div>
              <p className="text-[10px] text-amber-200/70 font-vazir">
                دریافت خودکار آخرین نسخه بدون نیاز به مارکت‌ها
              </p>
            </div>
          </div>

          {!updateInfo.isMandatory && (
            <button
              onClick={handleDismiss}
              className="w-7 h-7 rounded-full bg-[#4A2613] hover:bg-[#66351B] text-amber-200 flex items-center justify-center transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Version Compare Banner */}
        <div className="my-3 p-3 rounded-2xl bg-gradient-to-r from-[#3D1E0C] via-[#2A1408] to-[#3D1E0C] border border-amber-600/40 flex items-center justify-between">
          <div className="text-right">
            <span className="text-[10px] text-amber-300/80 block font-vazir">نسخه فعلی شما:</span>
            <span className="font-lalezar text-xs text-amber-200">
              نسخه {toPersianDigits(updateInfo.currentVersion)}
            </span>
          </div>

          <div className="px-2 py-1 rounded-xl bg-amber-500/20 border border-amber-400/50 flex items-center gap-1 font-lalezar text-yellow-300 text-xs animate-pulse">
            <span>←</span>
            <span>نسخه جدید</span>
            <span>{toPersianDigits(updateInfo.latestVersion)}</span>
          </div>

          {updateInfo.fileSizeMb && (
            <div className="text-left">
              <span className="text-[10px] text-amber-300/80 block font-vazir">حجم فایل:</span>
              <span className="font-lalezar text-xs text-amber-200">
                {toPersianDigits(updateInfo.fileSizeMb)} مگابایت
              </span>
            </div>
          )}
        </div>

        {/* Release Title & Story */}
        <div className="mb-3 p-3 rounded-2xl bg-[#1B0D06] border border-[#4A2411]">
          <div className="flex items-center gap-1.5 mb-1.5">
            <Sparkles className="w-3.5 h-3.5 text-yellow-400 shrink-0" />
            <h4 className="font-lalezar text-xs text-yellow-200">
              {updateInfo.releaseTitle}
            </h4>
          </div>

          {/* Release Notes List */}
          <div className="space-y-1.5 mt-2">
            {updateInfo.releaseNotes.map((note, idx) => (
              <div key={idx} className="flex items-start gap-1.5 text-[11px] text-amber-200/90 font-vazir leading-relaxed">
                <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0 mt-0.5" />
                <span>{note}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Security & Official Guarantee Badge */}
        <div className="mb-3.5 px-3 py-1.5 rounded-xl bg-emerald-950/60 border border-emerald-500/40 flex items-center justify-between text-[10px] text-emerald-200 font-vazir">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>فایل رسمی و امضا شده سرور (مستقیم و امن)</span>
          </div>
          <span className="text-emerald-400/90 font-vazir text-[10px] font-bold">نصب مستقیم APK</span>
        </div>

        {/* Download Progress Bar if active */}
        {downloadProgress !== null && (
          <div className="mb-3.5 p-2.5 rounded-2xl bg-[#1A0B05] border border-amber-600/50">
            <div className="flex items-center justify-between text-[11px] font-lalezar mb-1">
              <span className="text-amber-200">
                {downloadCompleted ? 'دانلود کامل شد! در حال انتقال به نصب...' : 'در حال دانلود بسته آپدیت...'}
              </span>
              <span className="text-yellow-400">
                {toPersianDigits(downloadProgress)}٪
              </span>
            </div>
            <div className="w-full h-2.5 bg-black/60 rounded-full overflow-hidden border border-[#522E18]">
              <div
                className="h-full bg-gradient-to-r from-amber-600 via-amber-400 to-yellow-300 rounded-full transition-all duration-200 shadow-[0_0_10px_rgba(245,158,11,0.8)]"
                style={{ width: `${downloadProgress}%` }}
              />
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="space-y-2">
          {!downloadCompleted ? (
            <button
              onClick={handleStartDownload}
              disabled={isDownloading}
              className={`w-full py-3 rounded-2xl font-lalezar text-sm flex items-center justify-center gap-2 shadow-xl border transition-all ${
                isDownloading
                  ? 'bg-amber-950/70 border-amber-700/50 text-amber-400 cursor-wait'
                  : 'bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 hover:brightness-110 active:scale-95 text-amber-950 font-bold border-yellow-200 cursor-pointer animate-pulse'
              }`}
            >
              <Download className="w-4 h-4" />
              <span>
                {isDownloading ? 'در حال دریافت بسته بروزرسانی...' : 'دریافت و نصب مستقیم بروزرسانی'}
              </span>
            </button>
          ) : (
            <a
              href={updateInfo.apkDownloadUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-emerald-500 hover:brightness-110 active:scale-95 text-white font-lalezar text-sm flex items-center justify-center gap-2 shadow-xl border border-emerald-300 cursor-pointer"
            >
              <ExternalLink className="w-4 h-4" />
              <span>نصب مستقیم فایل APK</span>
            </a>
          )}

          {!updateInfo.isMandatory && (
            <button
              onClick={handleDismiss}
              className="w-full py-2 rounded-xl bg-transparent hover:bg-white/5 text-amber-300/70 font-vazir text-[11px] transition-colors cursor-pointer"
            >
              یادآوری در ورود بعدی
            </button>
          )}
        </div>
      </div>
    </div>
  );
});

AppUpdateModal.displayName = 'AppUpdateModal';
