import React from 'react';
import { formatPersianCoins, toPersianDigits } from '../utils/persianNumbers';
import { Volume2, VolumeX, Menu, Moon, Sun } from 'lucide-react';

interface HUDProps {
  currentLevel: number;
  coins: number;
  levelProgressPercent: number;
  soundEnabled: boolean;
  isNightMode: boolean;
  unlockAll: boolean;
  isDebtActive?: boolean;
  debtStreakLeft?: number;
  onOpenMenu: () => void;
  onOpenCounterDrawer: () => void;
  onOpenHavaleh?: () => void;
  onOpenDaftarHesab: () => void;
  onToggleSound: () => void;
  onToggleNightMode: () => void;
  onToggleUnlockAll?: () => void;
  hasDailyRewardAvailable?: boolean;
  hasUnclaimedWeekly?: boolean;
}

export const HUD: React.FC<HUDProps> = ({
  currentLevel,
  coins,
  levelProgressPercent,
  soundEnabled,
  isNightMode,
  unlockAll,
  isDebtActive = false,
  debtStreakLeft = 3,
  onOpenMenu,
  onOpenCounterDrawer,
  onOpenDaftarHesab,
  onToggleSound,
  onToggleNightMode,
  hasDailyRewardAvailable,
  hasUnclaimedWeekly,
}) => {
  const isLevel3Unlocked = unlockAll || currentLevel >= 3;

  return (
    <header className="relative w-full px-3 pt-0.5 sm:pt-1 pb-1 z-30 select-none">
      {/* Top Ergonomic Control Bar: Clean, elevated, spacious and royal Persian aesthetic */}
      <div className="flex items-center justify-between px-1 -mt-0.5 sm:-mt-1 mb-1 sm:mb-1.5 text-[11px]">
        {/* Right side: Main Menu & Diegetic Counter Drawer (میز دخل) - Brought slightly up */}
        <div className="flex items-center gap-2 -translate-y-1 sm:-translate-y-1.5">
          {/* Main Menu Button */}
          <button
            onClick={onOpenMenu}
            className="px-3 py-1.5 rounded-full bg-gradient-to-r from-[#3D1E0C] via-[#2A1408] to-[#1F0D05] hover:brightness-125 border-2 border-[#D97706]/80 hover:border-yellow-400 text-yellow-200 flex items-center gap-1.5 font-lalezar text-xs shadow-md transition-all active:scale-95 cursor-pointer relative"
            title="منوی اصلی چایخانه"
          >
            <Menu className="w-3.5 h-3.5 text-yellow-400" />
            <span>منو</span>
            {(hasDailyRewardAvailable || hasUnclaimedWeekly) && (
              <span className="w-2 h-2 rounded-full bg-yellow-400 animate-ping absolute -top-0.5 -right-0.5" />
            )}
          </button>

          {/* Diegetic Counter Drawer (میز دخل عمو بهمن) - Unlocked Level 3+ */}
          {isLevel3Unlocked && (
            <button
              onClick={onOpenCounterDrawer}
              className="px-3 py-1.5 rounded-full bg-gradient-to-r from-[#4A2612] via-[#351909] to-[#240F05] hover:brightness-125 border border-amber-500/70 text-amber-200 flex items-center gap-1.5 font-lalezar text-xs shadow-md transition-all active:scale-95 cursor-pointer relative"
              title="میز دخل، انعام و امکانات ویژه عمو بهمن"
            >
              <span>🧮</span>
              <span>میز دخل</span>
              {/* Integrated subtle debt warning badge */}
              {isDebtActive && (
                <span
                  onClick={(e) => {
                    e.stopPropagation();
                    onOpenDaftarHesab();
                  }}
                  className="px-1.5 py-0.5 rounded-full bg-red-900/90 border border-red-500/90 text-red-200 text-[10px] font-sans font-bold animate-pulse shadow"
                  title={`دفتر حساب: ${toPersianDigits(debtStreakLeft)} برد مانده تا تسویه نسیه`}
                >
                  نسیه: {toPersianDigits(debtStreakLeft)}
                </span>
              )}
            </button>
          )}
        </div>

        {/* Left side: Clean Round Controls (Night Mode Lantern & Sound) - Aligned elevated */}
        <div className="flex items-center gap-2 -translate-y-1 sm:-translate-y-1.5">
          {/* Cozy Night Mode Lantern Toggle ("چراغ گردسوز شبانه") */}
          <button
            onClick={onToggleNightMode}
            className={`w-8 h-8 rounded-full border flex items-center justify-center shadow-md transition-all active:scale-90 cursor-pointer ${
              isNightMode
                ? 'bg-gradient-to-b from-amber-900 to-amber-950 border-amber-400 text-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.4)]'
                : 'bg-gradient-to-b from-[#381E10] to-[#241107] border-amber-700/60 text-amber-400 hover:border-amber-400/80 hover:brightness-110'
            }`}
            title={isNightMode ? 'حالت شبانه فعال (چراغ گردسوز)' : 'فعال‌سازی حالت شبانه'}
          >
            {isNightMode ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
          </button>

          {/* Sound Toggle */}
          <button
            onClick={onToggleSound}
            className="w-8 h-8 rounded-full bg-gradient-to-b from-[#381E10] to-[#241107] hover:brightness-110 border border-amber-700/60 hover:border-amber-400/80 text-amber-300 flex items-center justify-center shadow-md transition-all active:scale-90 cursor-pointer"
            title="صدا و موسیقی سنتی"
          >
            {soundEnabled ? (
              <Volume2 className="w-4 h-4" />
            ) : (
              <VolumeX className="w-4 h-4 text-amber-500/60" />
            )}
          </button>
        </div>
      </div>

      {/* Main HUD Bar: Level Pill, 3D Title, Coins */}
      <div className="relative flex items-center justify-between gap-1 sm:gap-2 mt-1">
        {/* Left: Burnt Wood Pill with Persian Turquoise Inlay for Level + Star Progress Bar */}
        <div className="flex flex-col items-start min-w-[75px] sm:min-w-[95px]">
          <div className="flex items-center justify-center px-2.5 sm:px-3.5 py-0.5 sm:py-1 rounded-full bg-gradient-to-b from-[#33180B] via-[#241107] to-[#160A03] border-2 border-[#0D9488]/80 shadow-[inset_0_2px_4px_rgba(0,0,0,0.6),0_4px_10px_rgba(13,148,136,0.35)]">
            <span className="font-lalezar text-xs sm:text-base text-amber-100 tracking-wide drop-shadow">
              مرحله {toPersianDigits(currentLevel)}
            </span>
          </div>

          {/* Star Progress Bar with Turquoise Track */}
          <div className="flex items-center gap-1 mt-1 pr-0.5">
            <div className="w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-300 flex items-center justify-center text-[9px] sm:text-[10px] text-amber-950 font-bold shadow-sm">
              ★
            </div>
            <div className="w-12 sm:w-16 h-1.5 sm:h-2 bg-[#172B28] rounded-full overflow-hidden border border-[#0D9488]/60">
              <div
                className="h-full bg-gradient-to-r from-teal-500 via-amber-400 to-yellow-300 rounded-full transition-all duration-500 shadow-[0_0_6px_rgba(13,148,136,0.8)]"
                style={{ width: `${Math.max(20, Math.min(100, levelProgressPercent))}%` }}
              />
            </div>
          </div>
        </div>

        {/* Center: Glowing Ornate Golden 3D Title ﴿ چایخانه عمو بهمن ﴾ with Turquoise Accents */}
        <div className="flex-1 flex flex-col items-center justify-center min-w-0">
          <div className="flex items-center gap-1 filter drop-shadow-[0_3px_5px_rgba(0,0,0,0.9)]">
            <span className="text-teal-400 text-xs sm:text-sm font-lalezar select-none">❧</span>
            <h1 className="font-lalezar text-base sm:text-2xl text-transparent bg-clip-text bg-gradient-to-b from-[#FFF3B0] via-[#FFD15C] to-[#E68A00] tracking-wider drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)] truncate">
              چایخانه عمو بهمن
            </h1>
            <span className="text-teal-400 text-xs sm:text-sm font-lalezar select-none">☙</span>
          </div>
        </div>

        {/* Right: Coin Counter with Golden Star Coin & Persian Turquoise Frame */}
        <div className="flex items-center justify-end min-w-[75px] sm:min-w-[95px]">
          <button
            onClick={onOpenCounterDrawer}
            className="flex items-center gap-1 sm:gap-2 px-2.5 sm:px-3 py-0.5 sm:py-1 rounded-full bg-gradient-to-b from-[#33180B] via-[#241107] to-[#160A03] border-2 border-[#0D9488]/80 shadow-[inset_0_2px_4px_rgba(0,0,0,0.6),0_4px_10px_rgba(13,148,136,0.35)] hover:border-yellow-400 active:scale-95 transition-all cursor-pointer"
            title="موجودی سکه طلا (کلیک برای باز کردن دخل و حواله)"
          >
            <div className="w-4 h-4 sm:w-5 sm:h-5 rounded-full bg-gradient-to-tr from-[#FFD700] via-[#F59E0B] to-[#D97706] border border-[#FFF3B0] flex items-center justify-center text-amber-950 text-[10px] sm:text-xs font-black shadow-[0_0_8px_rgba(255,215,0,0.7)] animate-pulse">
              ★
            </div>
            <span className="font-lalezar text-xs sm:text-base text-amber-100 tracking-wide font-bold">
              {formatPersianCoins(coins)}
            </span>
          </button>
        </div>
      </div>
    </header>
  );
};
