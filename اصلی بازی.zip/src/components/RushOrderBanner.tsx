import React from 'react';
import { Timer, Zap } from 'lucide-react';
import { DrinkType } from '../types';
import { DRINKS_DATA } from '../constants/drinks';
import { formatTimeSeconds } from '../utils/persianNumbers';

interface RushOrderBannerProps {
  timeLeft: number;
  targets: DrinkType[];
  isCompleted: boolean;
}

export const RushOrderBanner: React.FC<RushOrderBannerProps> = ({
  timeLeft,
  targets,
  isCompleted,
}) => {
  const isUrgent = timeLeft <= 15;

  return (
    <div
      className={`w-full max-w-[390px] mx-auto px-3 py-1.5 rounded-2xl mb-2 flex items-center justify-between border-2 transition-all ${
        isUrgent
          ? 'bg-rose-950/80 border-rose-500 animate-pulse text-rose-100 shadow-[0_0_15px_rgba(244,63,94,0.4)]'
          : 'bg-amber-950/70 border-amber-500 text-amber-100 shadow-md'
      }`}
    >
      <div className="flex items-center gap-2">
        <div
          className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs ${
            isUrgent ? 'bg-rose-600 text-white animate-spin' : 'bg-amber-500 text-amber-950'
          }`}
        >
          <Zap className="w-4 h-4" />
        </div>
        <div className="text-right">
          <span className="font-lalezar text-xs block leading-tight text-yellow-300">
            مشتری عجله‌ای! (+۱۵۰ سکه سرعت)
          </span>
          <div className="flex items-center gap-1 text-[10px] text-amber-200/90 font-vazir">
            <span>سفارش:</span>
            {targets.map((t, idx) => (
              <span key={idx} className="font-bold underline decoration-amber-400">
                {DRINKS_DATA[t]?.persianName.split(' ')[0]}
                {idx < targets.length - 1 ? ' + ' : ''}
              </span>
            ))}
          </div>
        </div>
      </div>

      <div className="flex items-center gap-1 bg-black/40 px-2 py-1 rounded-xl border border-amber-600/50">
        <Timer className={`w-3.5 h-3.5 ${isUrgent ? 'text-rose-400' : 'text-amber-400'}`} />
        <span className="font-lalezar text-sm text-yellow-300 tabular-nums">
          {formatTimeSeconds(timeLeft)}
        </span>
      </div>
    </div>
  );
};
