import React, { useEffect, useState } from 'react';
import bahmanAvatar from '../assets/images/bahman_exact_avatar_1791919274915.jpg';

interface CharacterSpeechProps {
  speechText: string;
  onAvatarClick?: () => void;
  isStuckAlert?: boolean;
}

export const CharacterSpeech: React.FC<CharacterSpeechProps> = ({
  speechText,
  onAvatarClick,
  isStuckAlert,
}) => {
  const [displayedText, setDisplayedText] = useState<string>(speechText);
  const [isFading, setIsFading] = useState<boolean>(false);

  useEffect(() => {
    setIsFading(true);
    const timeout = setTimeout(() => {
      setDisplayedText(speechText);
      setIsFading(false);
    }, 120);

    return () => clearTimeout(timeout);
  }, [speechText]);

  return (
    <div className="relative w-full px-3 py-1 flex items-center justify-between gap-2.5 z-20 select-none">
      {/* Cream Speech Bubble (Exact shape with smooth typewriter/fade-in) */}
      <div
        className={`relative flex-1 bg-[#FFFBF0] text-[#2C1A11] px-4 py-2 rounded-3xl border-2 shadow-[0_6px_14px_rgba(0,0,0,0.5)] transition-all duration-300 ${
          isStuckAlert
            ? 'border-amber-500 shadow-[0_0_15px_rgba(245,158,11,0.6)]'
            : 'border-[#C9A26B]'
        }`}
      >
        <p
          className={`text-xs sm:text-sm font-semibold leading-relaxed font-vazir text-right text-[#3E2211] transition-opacity duration-200 ${
            isFading ? 'opacity-30' : 'opacity-100'
          }`}
        >
          {displayedText}
        </p>

        {/* Speech Bubble Tail pointing right to Uncle Bahman */}
        <div className="absolute top-1/2 -right-2.5 transform -translate-y-1/2 w-0 h-0 border-t-[7px] border-t-transparent border-b-[7px] border-b-transparent border-l-[10px] border-l-[#FFFBF0]" />
      </div>

      {/* Uncle Bahman Circular Avatar with Turquoise & Gold Border */}
      <div
        onClick={onAvatarClick}
        className="relative shrink-0 w-16 h-16 rounded-full p-1 bg-gradient-to-tr from-[#B8860B] via-[#0D9488] to-[#FFD700] shadow-[0_6px_16px_rgba(0,0,0,0.6)] cursor-pointer transform active:scale-95 transition-transform"
        title="اوستا بهمن (کلیک کنید تا گپ بزنه)"
      >
        <div className="w-full h-full rounded-full overflow-hidden border-2 border-[#FFFBF0] bg-[#1F120B]">
          <img
            src={bahmanAvatar}
            alt="اوستا بهمن"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
            onError={(e) => {
              const target = e.currentTarget;
              target.style.display = 'none';
            }}
          />
        </div>
      </div>
    </div>
  );
};
