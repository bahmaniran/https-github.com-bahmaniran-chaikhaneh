import React from 'react';

interface OnboardingPointerProps {
  isVisible: boolean;
}

export const OnboardingPointer: React.FC<OnboardingPointerProps> = ({ isVisible }) => {
  if (!isVisible) return null;

  return (
    <div className="absolute inset-0 pointer-events-none z-30 flex flex-col items-center justify-center">
      {/* Subtle dimming behind tutorial */}
      <div className="absolute inset-0 bg-black/25 transition-opacity duration-500" />

      {/* Animated Hand / Pointer Guidance */}
      <div className="relative flex flex-col items-center">
        <div className="w-12 h-12 flex items-center justify-center text-4xl animate-bounce filter drop-shadow-[0_4px_10px_rgba(245,158,11,0.9)]">
          👆
        </div>
        <div className="bg-[#1C0D05]/90 border border-amber-400 text-amber-200 text-xs font-lalezar px-3 py-1 rounded-full shadow-lg mt-1 tracking-wide">
          استکان مبدأ را انتخاب و در استکان خالی بریزید
        </div>
      </div>
    </div>
  );
};
