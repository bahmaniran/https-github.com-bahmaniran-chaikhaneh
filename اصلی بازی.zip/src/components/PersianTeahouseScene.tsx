import React from 'react';

interface PersianTeahouseSceneProps {
  children: React.ReactNode;
  isNightMode?: boolean;
  onOpenRenovations?: () => void;
  onOpenRadio?: () => void;
  onOpenDaftarHesab?: () => void;
  onOpenPatogh?: () => void;
  currentLevel?: number;
  unlockAll?: boolean;
}

export const PersianTeahouseScene: React.FC<PersianTeahouseSceneProps> = React.memo(({
  children,
  isNightMode = false,
}) => {

  return (
    <div className="relative w-full h-full flex flex-col justify-between overflow-hidden select-none">
      {/* 1. Master Persian Teahouse Scene: Chic Burnt Wood, Antique Persian Brick & 7-Color Tile Accents */}
      <div className="absolute inset-0 pointer-events-none z-0">
        <svg
          viewBox="0 0 440 760"
          className="w-full h-full object-cover transition-all duration-700"
          preserveAspectRatio="xMidYMid slice"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            {/* Burnt Wood & Brick Wall Base Gradient */}
            <linearGradient id="burnt-brick-wall" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#38190B" />
              <stop offset="35%" stopColor="#4A2412" />
              <stop offset="65%" stopColor="#3E1E0E" />
              <stop offset="100%" stopColor="#251006" />
            </linearGradient>

            {/* Traditional Persian Brickwork Pattern (طرح آجر خشتی قزاقی سنتی) */}
            <pattern id="persian-brick-pattern" width="44" height="22" patternUnits="userSpaceOnUse">
              <rect width="44" height="22" fill="#3D1D0D" />
              {/* Row 1 */}
              <rect x="1" y="1" width="42" height="9" rx="1.5" fill="#4B2412" stroke="#281106" strokeWidth="0.8" opacity="0.9" />
              {/* Row 2 (Staggered) */}
              <rect x="1" y="12" width="20" height="9" rx="1.5" fill="#462110" stroke="#281106" strokeWidth="0.8" opacity="0.85" />
              <rect x="23" y="12" width="20" height="9" rx="1.5" fill="#4E2714" stroke="#281106" strokeWidth="0.8" opacity="0.85" />
            </pattern>

            {/* Luxurious Seven-Color Persian Tile Frieze (کاشی هفت‌رنگ درباری: یاقوتی، لاجوردی، فیروزه‌ای، زعفرانی، یشمی) */}
            <pattern id="haftrang-tile-frieze" width="28" height="26" patternUnits="userSpaceOnUse">
              <rect width="28" height="26" fill="#1C0C04" />
              {/* Saffron / Amber Diamond Base */}
              <path d="M 0 13 L 14 0 L 28 13 L 14 26 Z" fill="#D97706" stroke="#FDE047" strokeWidth="0.6" />
              {/* Lapis Lazuli & Royal Turquoise Core Flower */}
              <circle cx="14" cy="13" r="5.5" fill="#1E3A8A" stroke="#0D9488" strokeWidth="1" />
              {/* Pomegranate Ruby Petals */}
              <circle cx="14" cy="4" r="2.2" fill="#BE123C" />
              <circle cx="14" cy="22" r="2.2" fill="#BE123C" />
              <circle cx="5" cy="13" r="2.2" fill="#15803D" />
              <circle cx="23" cy="13" r="2.2" fill="#15803D" />
              {/* Golden Core Dot */}
              <circle cx="14" cy="13" r="1.8" fill="#FDE047" />
            </pattern>

            {/* Burnt Wood Wainscot Planks Texture */}
            <linearGradient id="burnt-wood-plank" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#250F05" />
              <stop offset="30%" stopColor="#3A1C0E" />
              <stop offset="70%" stopColor="#2F1508" />
              <stop offset="100%" stopColor="#1E0B03" />
            </linearGradient>

            <filter id="orosi-glow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation={isNightMode ? '4' : '3.5'} result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* 1. Base Antique Brick Wall */}
          <rect width="440" height="760" fill="url(#burnt-brick-wall)" />
          <rect width="440" height="480" fill="url(#persian-brick-pattern)" opacity="0.75" />

          {/* 2. Seven-Color Persian Ceramic Tile Frieze Ribbon across the upper wall */}
          <g transform="translate(0, 78)">
            {/* Top Carved Burnt Wood Cornice */}
            <rect width="440" height="4" fill="#5C2D16" />
            <line x1="0" y1="1" x2="440" y2="1" stroke="#F59E0B" strokeWidth="0.8" opacity="0.7" />
            {/* The 7-Color Tile Frieze */}
            <rect y="4" width="440" height="26" fill="url(#haftrang-tile-frieze)" />
            {/* Bottom Burnt Wood Molding */}
            <rect y="30" width="440" height="5" fill="#2E1408" stroke="#1A0A03" strokeWidth="0.8" />
            <line x1="0" y1="31" x2="440" y2="31" stroke="#D97706" strokeWidth="0.8" opacity="0.6" />
          </g>

          {/* 3. Burnt Wood Lower Wainscot (ازاره چوب سوخته خراطی شده) */}
          <g transform="translate(0, 480)">
            {/* Upper Rail with Carved Ogee Profiling */}
            <rect width="440" height="8" fill="#522713" stroke="#251006" strokeWidth="1" />
            <line x1="0" y1="2" x2="440" y2="2" stroke="#B45309" strokeWidth="1" opacity="0.6" />
            {/* Wainscot Burnt Wood Paneling */}
            <rect y="8" width="440" height="200" fill="url(#burnt-wood-plank)" />
            {/* Panel divider pilasters */}
            <line x1="110" y1="8" x2="110" y2="208" stroke="#1A0A03" strokeWidth="3" />
            <line x1="111" y1="8" x2="111" y2="208" stroke="#68341A" strokeWidth="1" />
            <line x1="220" y1="8" x2="220" y2="208" stroke="#1A0A03" strokeWidth="3" />
            <line x1="221" y1="8" x2="221" y2="208" stroke="#68341A" strokeWidth="1" />
            <line x1="330" y1="8" x2="330" y2="208" stroke="#1A0A03" strokeWidth="3" />
            <line x1="331" y1="8" x2="331" y2="208" stroke="#68341A" strokeWidth="1" />
          </g>

          {/* 4. Grand Burnt Wood Arch & Doorway (سردر طاق چوب سوخته و درب سنتی) */}
          <g transform="translate(145, 120)">
            {/* Burnt Walnut Outer Arch Profile */}
            <path
              d="M 0,280 L 0,60 C 0,0 150,0 150,60 L 150,280 Z"
              fill="#2A1207"
              stroke="#8C441B"
              strokeWidth="4"
            />
            {/* Golden Carved Inscription Arch Line */}
            <path
              d="M 5,60 C 5,5 145,5 145,60 L 145,275 L 5,275 Z"
              fill="#1F0D05"
              stroke="#D97706"
              strokeWidth="1.5"
            />
            {/* Glowing Amber Transom Fanlight (مهتابی هلالی نورانی) */}
            <path
              d="M 12,60 C 12,14 138,14 138,60 Z"
              fill="#FEF08A"
              fillOpacity={isNightMode ? 0.35 : 0.5}
              stroke="#F59E0B"
              strokeWidth="2"
            />
            {/* Radiating wooden mullions in the transom */}
            <line x1="75" y1="60" x2="75" y2="18" stroke="#5C2B14" strokeWidth="2" />
            <line x1="75" y1="60" x2="42" y2="28" stroke="#5C2B14" strokeWidth="2" />
            <line x1="75" y1="60" x2="108" y2="28" stroke="#5C2B14" strokeWidth="2" />

            {/* Burnt Walnut Door Panels */}
            <rect x="15" y="70" width="36" height="190" rx="4" fill="#301509" stroke="#783A1A" strokeWidth="1.5" />
            <rect x="57" y="70" width="36" height="190" rx="4" fill="#301509" stroke="#783A1A" strokeWidth="1.5" />
            <rect x="99" y="70" width="36" height="190" rx="4" fill="#301509" stroke="#783A1A" strokeWidth="1.5" />

            {/* Antique Brass Rosette Studs (گل‌میخ‌های برنجی کهن) */}
            <circle cx="33" cy="115" r="3" fill="#FBBF24" stroke="#783A1A" strokeWidth="0.8" />
            <circle cx="75" cy="115" r="3" fill="#FBBF24" stroke="#783A1A" strokeWidth="0.8" />
            <circle cx="117" cy="115" r="3" fill="#FBBF24" stroke="#783A1A" strokeWidth="0.8" />
            <circle cx="33" cy="165" r="3" fill="#FBBF24" stroke="#783A1A" strokeWidth="0.8" />
            <circle cx="75" cy="165" r="3" fill="#FBBF24" stroke="#783A1A" strokeWidth="0.8" />
            <circle cx="117" cy="165" r="3" fill="#FBBF24" stroke="#783A1A" strokeWidth="0.8" />
          </g>

          {/* 5. Left Orosi Window with Burnt Wood Frame & Glowing Persian Gem Glass */}
          <g transform="translate(15, 130)" filter="url(#orosi-glow)">
            {/* Burnt Wood Window Outer Frame */}
            <path
              d="M 0,260 L 0,55 C 0,0 85,0 85,55 L 85,260 Z"
              fill="#261006"
              stroke="#8C441B"
              strokeWidth="3.5"
            />
            {/* Glowing Arch Crown in Warm Saffron */}
            <path d="M 5,55 C 5,10 80,10 80,55 Z" fill="#F59E0B" fillOpacity={isNightMode ? 0.55 : 0.7} stroke="#783516" strokeWidth="1.5" />
            {/* Pomegranate Red & Royal Turquoise Panes */}
            <rect x="8" y="65" width="32" height="42" rx="3" fill="#BE123C" fillOpacity={isNightMode ? 0.7 : 0.82} stroke="#5C1625" strokeWidth="1" />
            <rect x="45" y="65" width="32" height="42" rx="3" fill="#0D9488" fillOpacity={isNightMode ? 0.65 : 0.78} stroke="#074E47" strokeWidth="1" />
            {/* Warm Saffron & Persian Emerald Green Panes */}
            <rect x="8" y="115" width="32" height="42" rx="3" fill="#F59E0B" fillOpacity={isNightMode ? 0.7 : 0.82} stroke="#783516" strokeWidth="1" />
            <rect x="45" y="115" width="32" height="42" rx="3" fill="#15803D" fillOpacity={isNightMode ? 0.65 : 0.78} stroke="#0B4622" strokeWidth="1" />
            {/* Royal Lapis & Rose Red Panes */}
            <rect x="8" y="165" width="32" height="42" rx="3" fill="#1E40AF" fillOpacity={isNightMode ? 0.65 : 0.78} stroke="#0F246A" strokeWidth="1" />
            <rect x="45" y="165" width="32" height="42" rx="3" fill="#E11D48" fillOpacity={isNightMode ? 0.7 : 0.82} stroke="#7A1229" strokeWidth="1" />
            {/* Burnt Wood Lower Sash Panel */}
            <rect x="8" y="215" width="69" height="35" rx="3" fill="#3D1A0A" stroke="#783A1A" strokeWidth="1.2" />
          </g>

          {/* 6. Right Orosi Window with Burnt Wood Frame & Glowing Persian Gem Glass */}
          <g transform="translate(340, 130)" filter="url(#orosi-glow)">
            {/* Burnt Wood Window Outer Frame */}
            <path
              d="M 0,260 L 0,55 C 0,0 85,0 85,55 L 85,260 Z"
              fill="#261006"
              stroke="#8C441B"
              strokeWidth="3.5"
            />
            {/* Glowing Arch Crown in Warm Saffron */}
            <path d="M 5,55 C 5,10 80,10 80,55 Z" fill="#F59E0B" fillOpacity={isNightMode ? 0.55 : 0.7} stroke="#783516" strokeWidth="1.5" />
            {/* Royal Turquoise & Pomegranate Red Panes */}
            <rect x="8" y="65" width="32" height="42" rx="3" fill="#0D9488" fillOpacity={isNightMode ? 0.65 : 0.78} stroke="#074E47" strokeWidth="1" />
            <rect x="45" y="65" width="32" height="42" rx="3" fill="#BE123C" fillOpacity={isNightMode ? 0.7 : 0.82} stroke="#5C1625" strokeWidth="1" />
            {/* Persian Emerald Green & Warm Saffron Panes */}
            <rect x="8" y="115" width="32" height="42" rx="3" fill="#15803D" fillOpacity={isNightMode ? 0.65 : 0.78} stroke="#0B4622" strokeWidth="1" />
            <rect x="45" y="115" width="32" height="42" rx="3" fill="#F59E0B" fillOpacity={isNightMode ? 0.7 : 0.82} stroke="#783516" strokeWidth="1" />
            {/* Rose Red & Royal Lapis Panes */}
            <rect x="8" y="165" width="32" height="42" rx="3" fill="#E11D48" fillOpacity={isNightMode ? 0.7 : 0.82} stroke="#7A1229" strokeWidth="1" />
            <rect x="45" y="165" width="32" height="42" rx="3" fill="#1E40AF" fillOpacity={isNightMode ? 0.65 : 0.78} stroke="#0F246A" strokeWidth="1" />
            {/* Burnt Wood Lower Sash Panel */}
            <rect x="8" y="215" width="69" height="35" rx="3" fill="#3D1A0A" stroke="#783A1A" strokeWidth="1.2" />
          </g>
        </svg>
      </div>



      {/* Cozy Night Mode Warm Oil Lantern Atmosphere (No Pitch Black Vignette) */}
      {isNightMode && (
        <div className="absolute inset-0 pointer-events-none z-10 transition-opacity duration-700">
          {/* Warm golden-amber candlelight glow overlay - pure warm lighting */}
          <div className="absolute inset-0 bg-radial from-amber-400/20 via-amber-700/10 to-transparent" />
          {/* Warm lantern focal spotlight above the tea tray */}
          <div className="absolute bottom-20 left-1/2 -translate-x-1/2 w-80 h-80 rounded-full bg-yellow-400/15 filter blur-3xl" />
          {/* Floating warm golden dust particles */}
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute top-1/4 left-1/3 w-1.5 h-1.5 rounded-full bg-amber-200/60 filter blur-xs animate-float" />
            <div className="absolute top-1/2 left-2/3 w-2 h-2 rounded-full bg-yellow-300/50 filter blur-xs animate-float-delayed" />
            <div className="absolute top-1/3 right-1/4 w-1 h-1 rounded-full bg-amber-100/70 filter blur-xs animate-float" />
          </div>
        </div>
      )}

      {/* 2. Top Content Area (HUD + Character Speech sit above) */}
      <div className="relative z-20 w-full" />

      {/* 3. Foreground Table & Low-Glare Matte Wood Puzzle Tray */}
      <div className="relative z-30 w-full flex flex-col items-center justify-end">
        <div className="relative w-full max-w-[420px] mx-auto px-2">
          {/* Wooden Table Top SVG with Warm Low-Glare Matte Wood Textures (#5C3A21 to #3E2412) */}
          <svg viewBox="0 0 420 80" className="w-full h-16 drop-shadow-2xl overflow-visible">
            <defs>
              <linearGradient id="matte-wood-grad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#4A2511" />
                <stop offset="35%" stopColor="#381A0B" />
                <stop offset="75%" stopColor="#2A1206" />
                <stop offset="100%" stopColor="#1B0A03" />
              </linearGradient>
            </defs>

            {/* Thick 3D Tabletop with Chic Burnt Wood Finish */}
            <path
              d="M 5,20 L 415,20 L 405,75 L 15,75 Z"
              fill="url(#matte-wood-grad)"
              stroke="#5C2B14"
              strokeWidth="2.5"
            />
            {/* Top Bevel Highlight Line - Burnished Amber Wood */}
            <line x1="12" y1="21" x2="408" y2="21" stroke="#B87333" strokeWidth="1.2" opacity="0.6" />
            {/* Soft Wood Grain Paths */}
            <path d="M 25,32 Q 180,36 395,31" stroke="#1A0C05" strokeWidth="1.2" opacity="0.5" fill="none" />
            <path d="M 35,46 Q 220,49 385,44" stroke="#1A0C05" strokeWidth="1" opacity="0.4" fill="none" />
            <path d="M 45,60 Q 190,62 375,59" stroke="#1A0C05" strokeWidth="1" opacity="0.3" fill="none" />
          </svg>

          {/* Warm Chic Burnt Wood & Chased Copper Tray with Persian Turquoise Inlay (فیروزه‌کوبی اصفهان) */}
          <div
            className={`relative -mt-16 w-full rounded-[55px] p-2.5 sm:p-3 pt-4 sm:pt-5 pb-3 flex flex-wrap items-center justify-center border-[4px] sm:border-[5px] shadow-[inset_0_8px_25px_rgba(25,10,4,0.5),0_15px_35px_rgba(15,6,2,0.7)] transition-colors duration-500 ${
              isNightMode
                ? 'bg-gradient-to-br from-[#45220F] via-[#321609] to-[#1E0C04] border-[#8C461F]'
                : 'bg-gradient-to-br from-[#542812] via-[#3D1A0A] to-[#240E04] border-[#9E5225]'
            }`}
          >
            {/* Outer Persian Turquoise Inlay Rim (طرح فیروزه‌کوبی درباری) */}
            <div className="absolute inset-1.5 rounded-[50px] border-2 border-[#0D9488]/50 shadow-[0_0_12px_rgba(13,148,136,0.3)] pointer-events-none" />
            <div className="absolute inset-3 rounded-[46px] border border-dashed border-[#F59E0B]/30 pointer-events-none" />

            {/* Soft Warm Reflection */}
            <div className="absolute top-1 inset-x-12 h-6 rounded-full bg-gradient-to-b from-amber-200/15 to-transparent pointer-events-none" />

            {/* Central Engraved Toranj Mandala with Turquoise Glow */}
            <div className="absolute inset-6 rounded-[40px] border border-[#0D9488]/25 bg-gradient-to-radial from-[#5C3217]/30 via-transparent to-[#281308]/40 pointer-events-none flex items-center justify-center">
              <div className="w-28 sm:w-32 h-28 sm:h-32 rounded-full border border-[#0D9488]/30 flex items-center justify-center text-[#2DD4BF]/30 text-3xl sm:text-4xl font-lalezar">
                ❖
              </div>
            </div>

            {/* Estekans Container with Responsive Gap */}
            <div className="relative z-10 w-full flex flex-wrap items-end justify-center gap-x-1 sm:gap-x-2 gap-y-2 sm:gap-y-3 pt-2 pb-1">
              {children}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
});
