import React, { useEffect, useRef, useState } from 'react';
import { soundEngine } from '../audio/SoundEngine';

interface Particle {
  x: number;
  y: number;
  size: number;
  speedY: number;
  speedX: number;
  alpha: number;
  maxAlpha: number;
  wobbleSpeed: number;
  wobbleOffset: number;
}

export const TeahouseAtmosphere: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [lampFlare, setLampFlare] = useState<boolean>(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = canvas.parentElement?.clientWidth || 400);
    let height = (canvas.height = canvas.parentElement?.clientHeight || 700);

    const handleResize = () => {
      if (!canvas.parentElement) return;
      width = canvas.width = canvas.parentElement.clientWidth;
      height = canvas.height = canvas.parentElement.clientHeight;
    };

    window.addEventListener('resize', handleResize);

    // Initialize 18 lightweight floating golden dust motes (optimized for 60fps zero lag)
    const particlesCount = 18;
    const particles: Particle[] = [];

    for (let i = 0; i < particlesCount; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        size: 0.8 + Math.random() * 1.8,
        speedY: -(0.15 + Math.random() * 0.3), // gentle upward float
        speedX: (Math.random() - 0.5) * 0.15,
        alpha: Math.random() * 0.5,
        maxAlpha: 0.3 + Math.random() * 0.4,
        wobbleSpeed: 0.01 + Math.random() * 0.02,
        wobbleOffset: Math.random() * Math.PI * 2,
      });
    }

    // Touch & pointer interaction tracking
    let pointerX = -999;
    let pointerY = -999;
    let pointerIntensity = 0;

    const handlePointerMove = (e: MouseEvent | TouchEvent) => {
      const rect = canvas.getBoundingClientRect();
      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
      pointerX = clientX - rect.left;
      pointerY = clientY - rect.top;
      pointerIntensity = 1.0;
    };

    const parent = canvas.parentElement;
    if (parent) {
      parent.addEventListener('mousemove', handlePointerMove, { passive: true });
      parent.addEventListener('touchmove', handlePointerMove, { passive: true });
      parent.addEventListener('touchstart', handlePointerMove, { passive: true });
    }

    let time = 0;

    const render = () => {
      if (document.hidden) {
        animationFrameId = requestAnimationFrame(render);
        return;
      }

      time += 0.03;
      ctx.clearRect(0, 0, width, height);

      // Decay pointer push
      if (pointerIntensity > 0.05) {
        pointerIntensity *= 0.95;
      } else {
        pointerIntensity = 0;
      }

      // Draw and update dust particles (ultra-fast direct fill, zero blur lag)
      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];

        // Browninan wobble
        p.y += p.speedY;
        p.x += p.speedX + Math.sin(time + p.wobbleOffset) * 0.2;

        // Interactive dispersion if cursor/touch is near
        if (pointerIntensity > 0) {
          const dx = p.x - pointerX;
          const dy = p.y - pointerY;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 80 && dist > 0) {
            const force = ((80 - dist) / 80) * 2.0 * pointerIntensity;
            p.x += (dx / dist) * force;
            p.y += (dy / dist) * force;
          }
        }

        // Natural looping when particle drifts off screen
        if (p.y < -10) {
          p.y = height + 10;
          p.x = Math.random() * width;
        }
        if (p.x < -10) p.x = width + 10;
        if (p.x > width + 10) p.x = -10;

        // Twinkle effect
        const twinkle = 0.5 + 0.5 * Math.sin(time * 2 + p.wobbleOffset * 3);
        const currentAlpha = p.maxAlpha * twinkle;

        // Draw soft golden particle efficiently without expensive shadowBlur
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(254, 240, 138, ${currentAlpha.toFixed(2)})`;
        ctx.fill();
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      if (parent) {
        parent.removeEventListener('mousemove', handlePointerMove);
        parent.removeEventListener('touchmove', handlePointerMove);
        parent.removeEventListener('touchstart', handlePointerMove);
      }
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  const handleLampClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    soundEngine.playGlassClink();
    setLampFlare(true);
    setTimeout(() => setLampFlare(false), 800);
  };

  return (
    <div className="absolute inset-0 pointer-events-none z-10 overflow-hidden select-none">
      {/* 1. Hanging Oil Lantern (فانوس دیوارکوب چایخانه) on Upper Left Wall */}
      <div
        onClick={handleLampClick}
        role="button"
        tabIndex={0}
        className="absolute top-[8%] left-[7%] w-24 h-24 pointer-events-auto cursor-pointer"
        title="چراغ موشی سنتی چایخانه (برای بازی با شعله کلیک کنید)"
      >
        {/* Pulsing Warm Amber Halo Glow */}
        <div
          className={`absolute inset-0 rounded-full transition-all duration-300 ${
            lampFlare
              ? 'scale-150 bg-gradient-to-radial from-amber-300/80 via-yellow-500/40 to-transparent'
              : 'animate-lamp-flicker bg-gradient-to-radial from-amber-400/50 via-orange-500/20 to-transparent'
          }`}
        />

        {/* Core Lamp Flame Spark */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-6 rounded-full bg-yellow-200/90 blur-[1px] shadow-[0_0_12px_rgba(255,215,0,0.9)] animate-pulse" />
      </div>

      {/* 2. Secondary Warm Oil Lamp Light on Upper Right Wall */}
      <div className="absolute top-[14%] right-[5%] w-20 h-20 pointer-events-none">
        <div className="absolute inset-0 rounded-full animate-lamp-flicker-delayed bg-gradient-to-radial from-amber-400/40 via-orange-600/15 to-transparent" />
      </div>

      {/* 3. Subtle Warm Daylight Caustics Beam from Stained Glass Orosi */}
      <div
        className="absolute top-[18%] inset-x-0 h-48 opacity-25 pointer-events-none transform -skew-y-3"
        style={{
          background:
            'radial-gradient(ellipse at 50% 30%, rgba(254, 243, 199, 0.25) 0%, rgba(217, 119, 6, 0.08) 50%, transparent 80%)',
        }}
      />

      {/* 4. Canvas for Floating Interactive Golden Dust Motes */}
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full pointer-events-none" />
    </div>
  );
};
