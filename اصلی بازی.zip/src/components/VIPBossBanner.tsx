import React from 'react';
import { VIPBossCustomer } from '../types';
import { toPersianDigits, formatPersianCoins } from '../utils/persianNumbers';
import { Clock, Hash, AlertTriangle } from 'lucide-react';

interface VIPBossBannerProps {
  boss: VIPBossCustomer;
  timeLeft?: number;
  movesLeft?: number;
  onDismiss?: () => void;
}

export const VIPBossBanner: React.FC<VIPBossBannerProps> = ({
  boss,
  timeLeft,
  movesLeft,
}) => {
  return (
    <div className="z-20 px-2 py-0.5 animate-fade-in select-none">
      <div className="flex items-center justify-between p-2 rounded-2xl bg-gradient-to-r from-red-950/95 via-[#381109] to-amber-950/95 border-2 border-red-500 shadow-xl text-amber-100">
        <div className="flex items-center gap-2">
          {/* Boss Avatar */}
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-red-700 via-amber-600 to-yellow-500 p-0.5 flex items-center justify-center shadow">
            <div className="w-full h-full rounded-2xl bg-[#1C0803] flex items-center justify-center text-xl">
              {boss.avatarEmoji}
            </div>
          </div>

          <div className="text-right">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="font-lalezar text-xs text-yellow-300">
                مشتری VIP: {boss.name}
              </span>
              <span className="text-[9px] px-1.5 py-0.2 rounded bg-red-900/80 text-red-200 border border-red-600/60 font-vazir">
                انعام: +{formatPersianCoins(boss.tipReward)} سکه ★
              </span>
            </div>
            <span className="text-[9px] text-amber-200/90 font-vazir block">
              {boss.description}
            </span>
          </div>
        </div>

        {/* Constraint Indicator */}
        <div className="flex flex-col items-center pl-1">
          {timeLeft !== undefined && (
            <div
              className={`flex items-center gap-1 px-2 py-1 rounded-xl font-lalezar text-xs border ${
                timeLeft <= 10
                  ? 'bg-red-600 text-white border-white animate-ping'
                  : 'bg-black/50 text-yellow-300 border-amber-600'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              <span>{toPersianDigits(timeLeft)} ثانیه</span>
            </div>
          )}

          {movesLeft !== undefined && (
            <div
              className={`flex items-center gap-1 px-2 py-1 rounded-xl font-lalezar text-xs border ${
                movesLeft <= 3
                  ? 'bg-red-600 text-white border-white animate-pulse'
                  : 'bg-black/50 text-yellow-300 border-amber-600'
              }`}
            >
              <Hash className="w-3.5 h-3.5" />
              <span>{toPersianDigits(movesLeft)} حرکت</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
