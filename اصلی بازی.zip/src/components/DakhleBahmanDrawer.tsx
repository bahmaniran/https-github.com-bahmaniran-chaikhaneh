import React from 'react';
import {
  X,
  Radio,
  BookOpen,
  Sparkles,
  Dice5,
  Gift,
  Share2,
  Lock,
  Coins,
  Store,
  Users,
  Compass,
} from 'lucide-react';
import { soundEngine } from '../audio/SoundEngine';
import { toPersianDigits, formatPersianCoins } from '../utils/persianNumbers';

interface DakhleBahmanDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  currentLevel: number;
  unlockAll: boolean;
  onOpenRenovations: () => void;
  onOpenRadio: () => void;
  onOpenDaftarHesab: () => void;
  onOpenTakhtehNard: () => void;
  onOpenPatogh: () => void;
  onOpenPahlavaniCard: () => void;
  onOpenHavaleh: () => void;
  hasDailyTipAvailable?: boolean;
  hasDiceRollAvailable?: boolean;
  isDebtActive?: boolean;
}

export const DakhleBahmanDrawer: React.FC<DakhleBahmanDrawerProps> = ({
  isOpen,
  onClose,
  currentLevel,
  unlockAll,
  onOpenRenovations,
  onOpenRadio,
  onOpenDaftarHesab,
  onOpenTakhtehNard,
  onOpenPatogh,
  onOpenPahlavaniCard,
  onOpenHavaleh,
  hasDailyTipAvailable = false,
  hasDiceRollAvailable = true,
  isDebtActive = false,
}) => {
  if (!isOpen) return null;

  const handleSelect = (action: () => void, isLocked: boolean) => {
    if (isLocked) {
      soundEngine.playGlassClink();
      return;
    }
    soundEngine.playClick();
    onClose();
    setTimeout(action, 100);
  };

  // Progressive unlock tiers
  const isLevel3Unlocked = unlockAll || currentLevel >= 3;
  const isLevel5Unlocked = unlockAll || currentLevel >= 5;
  const isLevel8Unlocked = unlockAll || currentLevel >= 8;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-[#180A03]/85 backdrop-blur-sm animate-fade-in select-none">
      <div className="w-full max-w-[440px] max-h-[90vh] overflow-y-auto rounded-t-[32px] p-5 pb-6 bg-gradient-to-b from-[#3A1E0E] via-[#2A1408] to-[#1E0E06] border-t-4 border-x-2 border-[#0D9488] shadow-[0_-15px_40px_rgba(25,10,3,0.85)] text-[#FFFBF0]">
        {/* Drawer Handle & Header */}
        <div className="flex items-center justify-between pb-3 border-b border-amber-900/60">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-amber-600 to-yellow-400 p-0.5 flex items-center justify-center shadow">
              <span className="text-sm">🧮</span>
            </div>
            <div>
              <h2 className="font-lalezar text-base text-yellow-300 leading-tight">
                میز دخل و پیشخوان عمو بهمن
              </h2>
              <p className="text-[10px] text-amber-300/70 font-vazir">
                اشیاء تعاملی و امکانات ویژه چایخانه
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playClick();
              onClose();
            }}
            className="w-7 h-7 rounded-full bg-[#422110] hover:bg-[#5C2E17] text-amber-200 flex items-center justify-center cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Diegetic Interactive Objects Grid */}
        <div className="grid grid-cols-2 gap-2.5 my-3.5">
          {/* 1. Interactive Samovar: Teahouse Renovations & Daily Tip Jar */}
          <button
            onClick={() => handleSelect(onOpenRenovations, !isLevel3Unlocked)}
            className={`p-3 rounded-2xl border-2 flex items-center gap-2.5 text-right transition-all cursor-pointer relative overflow-hidden ${
              isLevel3Unlocked
                ? 'bg-gradient-to-br from-[#3D2111] to-[#251208] border-amber-600/70 hover:border-yellow-400 shadow-md active:scale-95'
                : 'bg-[#1C0D05]/80 border-stone-800 opacity-60'
            }`}
          >
            <div className="w-10 h-10 rounded-xl bg-amber-950 border border-amber-700/80 flex items-center justify-center text-xl shrink-0 shadow">
              🫖
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <span className="font-lalezar text-xs text-yellow-300 truncate">
                  سماور و دخل روزانه
                </span>
                {!isLevel3Unlocked && <Lock className="w-3 h-3 text-amber-600 shrink-0" />}
              </div>
              <span className="text-[9px] text-amber-200/70 font-vazir block truncate">
                {isLevel3Unlocked ? 'دکوراسیون و انعام' : 'قفل تا مرحله ۳'}
              </span>
            </div>
            {hasDailyTipAvailable && isLevel3Unlocked && (
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping absolute top-2 left-2" />
            )}
          </button>

          {/* 2. Interactive Vintage Radio Widget */}
          <button
            onClick={() => handleSelect(onOpenRadio, !isLevel5Unlocked)}
            className={`p-3 rounded-2xl border-2 flex items-center gap-2.5 text-right transition-all cursor-pointer relative overflow-hidden ${
              isLevel5Unlocked
                ? 'bg-gradient-to-br from-[#3D2111] to-[#251208] border-amber-600/70 hover:border-yellow-400 shadow-md active:scale-95'
                : 'bg-[#1C0D05]/80 border-stone-800 opacity-60'
            }`}
          >
            <div className="w-10 h-10 rounded-xl bg-amber-950 border border-amber-700/80 flex items-center justify-center text-xl shrink-0 shadow">
              📻
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <span className="font-lalezar text-xs text-yellow-300 truncate">
                  رادیو لامپی قدیمی
                </span>
                {!isLevel5Unlocked && <Lock className="w-3 h-3 text-amber-600 shrink-0" />}
              </div>
              <span className="text-[9px] text-amber-200/70 font-vazir block truncate">
                {isLevel5Unlocked ? 'نغمه‌های اصیل سنتی' : 'قفل تا مرحله ۵'}
              </span>
            </div>
          </button>

          {/* 3. Interactive Ledger Book (دفتر حساب / نسیه) */}
          <button
            onClick={() => handleSelect(onOpenDaftarHesab, !isLevel5Unlocked)}
            className={`p-3 rounded-2xl border-2 flex items-center gap-2.5 text-right transition-all cursor-pointer relative overflow-hidden ${
              isLevel5Unlocked
                ? 'bg-gradient-to-br from-[#3D2111] to-[#251208] border-amber-600/70 hover:border-yellow-400 shadow-md active:scale-95'
                : 'bg-[#1C0D05]/80 border-stone-800 opacity-60'
            }`}
          >
            <div className="w-10 h-10 rounded-xl bg-amber-950 border border-amber-700/80 flex items-center justify-center text-xl shrink-0 shadow">
              📜
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <span className="font-lalezar text-xs text-yellow-300 truncate">
                  دفتر حساب و نسیه
                </span>
                {!isLevel5Unlocked && <Lock className="w-3 h-3 text-amber-600 shrink-0" />}
              </div>
              <span className="text-[9px] text-amber-200/70 font-vazir block truncate">
                {isLevel5Unlocked
                  ? isDebtActive
                    ? '⚠️ بدهی فعال'
                    : 'قرض و مرام ۳۰۰ سکه'
                  : 'قفل تا مرحله ۵'}
              </span>
            </div>
            {isDebtActive && isLevel5Unlocked && (
              <span className="w-2 h-2 rounded-full bg-red-400 animate-pulse absolute top-2 left-2" />
            )}
          </button>

          {/* 4. Backgammon Dice (تخته‌نرد) */}
          <button
            onClick={() => handleSelect(onOpenTakhtehNard, !isLevel3Unlocked)}
            className={`p-3 rounded-2xl border-2 flex items-center gap-2.5 text-right transition-all cursor-pointer relative overflow-hidden ${
              isLevel3Unlocked
                ? 'bg-gradient-to-br from-[#3D2111] to-[#251208] border-amber-600/70 hover:border-yellow-400 shadow-md active:scale-95'
                : 'bg-[#1C0D05]/80 border-stone-800 opacity-60'
            }`}
          >
            <div className="w-10 h-10 rounded-xl bg-amber-950 border border-amber-700/80 flex items-center justify-center text-xl shrink-0 shadow">
              🎲
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <span className="font-lalezar text-xs text-yellow-300 truncate">
                  تخته‌نرد روزانه
                </span>
                {!isLevel3Unlocked && <Lock className="w-3 h-3 text-amber-600 shrink-0" />}
              </div>
              <span className="text-[9px] text-amber-200/70 font-vazir block truncate">
                {isLevel3Unlocked ? 'تاس شانس و جایزه' : 'قفل تا مرحله ۳'}
              </span>
            </div>
            {hasDiceRollAvailable && isLevel3Unlocked && (
              <span className="w-2 h-2 rounded-full bg-yellow-400 animate-ping absolute top-2 left-2" />
            )}
          </button>

          {/* 5. Wall Frame / Banner: Clans & Neighborhood (پاتوق‌کشی) */}
          <button
            onClick={() => handleSelect(onOpenPatogh, !isLevel8Unlocked)}
            className={`p-3 rounded-2xl border-2 flex items-center gap-2.5 text-right transition-all cursor-pointer relative overflow-hidden ${
              isLevel8Unlocked
                ? 'bg-gradient-to-br from-[#3D2111] to-[#251208] border-amber-600/70 hover:border-yellow-400 shadow-md active:scale-95'
                : 'bg-[#1C0D05]/80 border-stone-800 opacity-60'
            }`}
          >
            <div className="w-10 h-10 rounded-xl bg-amber-950 border border-amber-700/80 flex items-center justify-center text-xl shrink-0 shadow">
              🚩
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <span className="font-lalezar text-xs text-yellow-300 truncate">
                  پاتوق و رده‌بندی محله
                </span>
                {!isLevel8Unlocked && <Lock className="w-3 h-3 text-amber-600 shrink-0" />}
              </div>
              <span className="text-[9px] text-amber-200/70 font-vazir block truncate">
                {isLevel8Unlocked ? 'رقابت قهرمانان' : 'قفل تا مرحله ۸'}
              </span>
            </div>
          </button>

          {/* 6. Coin Gifting & Havaleh (مهمون کردن رفقا) */}
          <button
            onClick={() => handleSelect(onOpenHavaleh, !isLevel5Unlocked)}
            className={`p-3 rounded-2xl border-2 flex items-center gap-2.5 text-right transition-all cursor-pointer relative overflow-hidden ${
              isLevel5Unlocked
                ? 'bg-gradient-to-br from-[#452712] via-[#2F1709] to-[#1E0F06] border-yellow-500/80 hover:border-yellow-300 shadow-md active:scale-95'
                : 'bg-[#1C0D05]/80 border-stone-800 opacity-60'
            }`}
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-600 to-yellow-500 border border-yellow-300 flex items-center justify-center text-xl shrink-0 shadow text-amber-950 font-bold">
              🎁
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <span className="font-lalezar text-xs text-yellow-300 truncate">
                  مهمون کردن رفقا
                </span>
                {!isLevel5Unlocked && <Lock className="w-3 h-3 text-amber-600 shrink-0" />}
              </div>
              <span className="text-[9px] text-amber-200/70 font-vazir block truncate">
                {isLevel5Unlocked ? 'حواله سکه طلا' : 'قفل تا مرحله ۵'}
              </span>
            </div>
          </button>
        </div>

        {/* Quick Footer info */}
        <div className="p-2.5 rounded-xl bg-amber-950/40 border border-amber-900/50 flex items-center justify-between text-[10px] text-amber-300/80 font-vazir">
          <span>مرحله فعلی: {toPersianDigits(currentLevel)}</span>
          <span>امکانات جدید به مرور با افزایش مرحله باز می‌شوند</span>
        </div>
      </div>
    </div>
  );
};
