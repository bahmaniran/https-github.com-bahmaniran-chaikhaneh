import { Cup, DrinkType } from '../types';
import { solveWaterSort } from './Solver';

const ALL_DRINKS: DrinkType[] = [
  'saffron',
  'tea',
  'khakshir',
  'doogh',
  'bahar-narenj',
  'bidmeshk',
];

export interface LevelConfig {
  levelNumber: number;
  cups: Cup[];
  isRushMode: boolean;
  rushTargets?: DrinkType[];
  rushTimeLimit?: number;
  drinkPool: DrinkType[];
}

export function generateLevel(level: number): LevelConfig {
  const isRushMode = level % 5 === 0;

  // Determine drink count & empty cup count based on level
  let colorCount: number;
  let emptyCount: number;

  if (level === 1) {
    colorCount = 2;
    emptyCount = 1; // Total 3 cups
  } else if (level === 2) {
    colorCount = 3;
    emptyCount = 1; // Total 4 cups
  } else if (level === 3) {
    colorCount = 3;
    emptyCount = 2; // Total 5 cups
  } else if (level <= 6) {
    colorCount = 4;
    emptyCount = 2; // Total 6 cups
  } else if (level <= 10) {
    colorCount = 4;
    emptyCount = 2; // Total 6 cups
  } else if (level <= 15) {
    colorCount = 5;
    emptyCount = 2; // Total 7 cups
  } else {
    colorCount = Math.min(6, 4 + Math.floor((level - 10) / 5));
    emptyCount = 2; // Total 7 or 8 cups
  }

  // Pick drinks for this level
  const shuffledDrinks = [...ALL_DRINKS].sort(() => 0.5 - Math.random());
  const selectedDrinks = shuffledDrinks.slice(0, colorCount);

  // Solvable reverse shuffle algorithm
  let attempts = 0;
  let finalCups: Cup[] = [];

  while (attempts < 10) {
    attempts++;
    // Start with solved state
    const cups: Cup[] = [];
    for (let i = 0; i < colorCount; i++) {
      cups.push({
        id: i,
        layers: [selectedDrinks[i], selectedDrinks[i], selectedDrinks[i], selectedDrinks[i]],
      });
    }
    for (let i = 0; i < emptyCount; i++) {
      cups.push({
        id: colorCount + i,
        layers: [],
      });
    }

    // Perform random valid reverse moves
    // A reverse move is: pick cup A (non-empty), move top item to cup B (has capacity < 4)
    // To ensure the puzzle is interesting and non-trivial:
    const numReverseMoves = Math.min(45, 12 + level * 3);
    for (let step = 0; step < numReverseMoves; step++) {
      const nonEmptyCupIndices = cups
        .map((c, idx) => (c.layers.length > 0 ? idx : -1))
        .filter((idx) => idx !== -1);

      if (nonEmptyCupIndices.length === 0) break;

      const fromIdx = nonEmptyCupIndices[Math.floor(Math.random() * nonEmptyCupIndices.length)];
      const nonFullCupIndices = cups
        .map((c, idx) => (idx !== fromIdx && c.layers.length < 4 ? idx : -1))
        .filter((idx) => idx !== -1);

      if (nonFullCupIndices.length === 0) continue;

      const toIdx = nonFullCupIndices[Math.floor(Math.random() * nonFullCupIndices.length)];

      const item = cups[fromIdx].layers.pop();
      if (item) {
        cups[toIdx].layers.push(item);
      }
    }

    // Verify it's not already solved and has at least one valid path
    const isAlreadySolved = cups.every(
      (c) => c.layers.length === 0 || (c.layers.length === 4 && c.layers.every((l) => l === c.layers[0]))
    );

    if (!isAlreadySolved) {
      const solution = solveWaterSort(cups, 1500);
      if (solution && solution.length > 0) {
        finalCups = cups;
        break;
      }
    }
  }

  // Fallback fallback: Guaranteed handcrafted initial distribution if random search exhausted
  if (finalCups.length === 0) {
    if (level === 1) {
      finalCups = [
        { id: 0, layers: ['saffron', 'tea', 'saffron', 'tea'] },
        { id: 1, layers: ['tea', 'saffron', 'tea', 'saffron'] },
        { id: 2, layers: [] },
      ];
    } else {
      // Direct interleaved setup
      const c1: DrinkType[] = [selectedDrinks[0], selectedDrinks[1], selectedDrinks[0], selectedDrinks[1]];
      const c2: DrinkType[] = [selectedDrinks[1], selectedDrinks[0], selectedDrinks[1], selectedDrinks[0]];
      const c3: DrinkType[] = selectedDrinks[2]
        ? [selectedDrinks[2], selectedDrinks[0], selectedDrinks[2], selectedDrinks[1]]
        : [selectedDrinks[0], selectedDrinks[1], selectedDrinks[0], selectedDrinks[1]];
      finalCups = [
        { id: 0, layers: c1 },
        { id: 1, layers: c2 },
        { id: 2, layers: c3 },
        { id: 3, layers: [] },
      ];
      if (emptyCount >= 2) {
        finalCups.push({ id: 4, layers: [] });
      }
    }
  }

  // Progressive Water Sort 2.0 Obstacles (starting Level 3+)
  // 1. Sugar Cube Blocker (Level >= 3)
  if (level >= 3 && (selectedDrinks.includes('tea') || selectedDrinks.includes('saffron'))) {
    const candidate = finalCups.find((c) => c.layers.length >= 3);
    if (candidate) candidate.hasSugarCubeBlocker = true;
  }

  // 2. Steamy Mystery Glass (Level >= 4)
  if (level >= 4) {
    const candidate = finalCups.find((c) => c.layers.length >= 3 && !c.hasSugarCubeBlocker);
    if (candidate) candidate.isSteamy = true;
  }

  // 3. Cooling Tea Timer (Level >= 5)
  if (level >= 5) {
    const candidate = finalCups.find(
      (c) => c.layers.length >= 2 && !c.hasSugarCubeBlocker && !c.isSteamy
    );
    if (candidate) candidate.coolingMovesLeft = Math.max(5, 8 - Math.floor(level / 8));
  }

  let rushTargets: DrinkType[] | undefined;
  if (isRushMode) {
    // Pick 2 target drinks from selected drinks
    rushTargets = selectedDrinks.slice(0, 2);
  }

  return {
    levelNumber: level,
    cups: finalCups,
    isRushMode,
    rushTargets,
    rushTimeLimit: isRushMode ? 45 : undefined,
    drinkPool: selectedDrinks,
  };
}
