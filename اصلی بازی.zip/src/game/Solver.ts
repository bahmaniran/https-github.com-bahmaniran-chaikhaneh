import { Cup, DrinkType } from '../types';

export interface SolverMove {
  fromIndex: number;
  toIndex: number;
}

export function isCupComplete(cup: Cup): boolean {
  if (cup.layers.length === 0) return true;
  if (cup.layers.length < 4) return false;
  return cup.layers.every((l) => l === cup.layers[0]);
}

export function isBoardSolved(cups: Cup[]): boolean {
  return cups.every((cup) => isCupComplete(cup));
}

function stateToKey(cups: DrinkType[][]): string {
  // Canonical sort to eliminate redundant symmetries
  return cups
    .map((c) => c.join(','))
    .sort()
    .join('|');
}

function calculateHeuristic(cups: DrinkType[][]): number {
  let score = 0;
  for (const cup of cups) {
    if (cup.length === 0) continue;
    // Count color switches in this cup
    let switches = 0;
    for (let i = 1; i < cup.length; i++) {
      if (cup[i] !== cup[i - 1]) switches++;
    }
    score += switches * 2;
    if (cup.length < 4 || switches > 0) {
      score += 1;
    }
  }
  return score;
}

export function solveWaterSort(initialCups: Cup[], maxIterations: number = 4000): SolverMove[] | null {
  const startState: DrinkType[][] = initialCups.map((c) => [...c.layers]);

  if (isBoardSolved(initialCups)) {
    return [];
  }

  interface Node {
    cups: DrinkType[][];
    g: number;
    h: number;
    f: number;
    moves: SolverMove[];
  }

  const openSet: Node[] = [];
  const closedSet = new Set<string>();

  const startH = calculateHeuristic(startState);
  openSet.push({
    cups: startState,
    g: 0,
    h: startH,
    f: startH,
    moves: [],
  });

  let iterations = 0;

  while (openSet.length > 0 && iterations < maxIterations) {
    iterations++;

    // Find node with lowest f
    let bestIdx = 0;
    for (let i = 1; i < openSet.length; i++) {
      if (openSet[i].f < openSet[bestIdx].f) {
        bestIdx = i;
      }
    }

    const current = openSet.splice(bestIdx, 1)[0];
    const key = stateToKey(current.cups);

    if (closedSet.has(key)) continue;
    closedSet.add(key);

    // Check if solved
    const allSolved = current.cups.every(
      (c) => c.length === 0 || (c.length === 4 && c.every((l) => l === c[0]))
    );

    if (allSolved) {
      return current.moves;
    }

    // Generate successor moves
    for (let from = 0; from < current.cups.length; from++) {
      const src = current.cups[from];
      if (src.length === 0) continue;

      // If source cup is already complete, avoid moving out of it
      if (src.length === 4 && src.every((l) => l === src[0])) continue;

      const topDrink = src[src.length - 1];

      // Count consecutive top identical drinks
      let count = 0;
      for (let k = src.length - 1; k >= 0; k--) {
        if (src[k] === topDrink) count++;
        else break;
      }

      // If source is already pure (e.g. 3 of same color) and moving to an empty cup, it's a useless circular move
      const isSrcPure = src.length === count;

      for (let to = 0; to < current.cups.length; to++) {
        if (from === to) continue;
        const dst = current.cups[to];

        if (dst.length === 4) continue; // full

        // Cannot move pure cup into an empty cup (waste of move)
        if (dst.length === 0 && isSrcPure) continue;

        // Dst must be empty OR top color must match
        if (dst.length > 0 && dst[dst.length - 1] !== topDrink) continue;

        const availableSpace = 4 - dst.length;
        const toMove = Math.min(count, availableSpace);
        if (toMove <= 0) continue;

        // Create new state
        const nextCups = current.cups.map((c) => [...c]);
        const nextSrc = nextCups[from];
        const nextDst = nextCups[to];

        for (let m = 0; m < toMove; m++) {
          nextSrc.pop();
          nextDst.push(topDrink);
        }

        const nextKey = stateToKey(nextCups);
        if (closedSet.has(nextKey)) continue;

        const nextG = current.g + 1;
        const nextH = calculateHeuristic(nextCups);
        const nextMoves = [...current.moves, { fromIndex: from, toIndex: to }];

        openSet.push({
          cups: nextCups,
          g: nextG,
          h: nextH,
          f: nextG + nextH,
          moves: nextMoves,
        });
      }
    }
  }

  return null;
}
