import { RadioTrackId } from '../types';

class SoundEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private activeMusicNodes: { stop: () => void } | null = null;
  private isMuted: boolean = false;
  private volume: number = 0.8;
  private currentTrack: RadioTrackId = 'tar_sonati';
  private cachedNoiseBuffer: AudioBuffer | null = null;

  private initCtx() {
    if (!this.ctx) {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioContextClass();
      
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(this.volume, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);

      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.setValueAtTime(0.5, this.ctx.currentTime);
      this.musicGain.connect(this.masterGain);

      this.sfxGain = this.ctx.createGain();
      this.sfxGain.gain.setValueAtTime(0.7, this.ctx.currentTime);
      this.sfxGain.connect(this.masterGain);
    }

    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  private getNoiseBuffer(): AudioBuffer | null {
    if (!this.ctx) return null;
    if (!this.cachedNoiseBuffer) {
      const bufferSize = Math.floor(this.ctx.sampleRate * 0.5);
      this.cachedNoiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const output = this.cachedNoiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }
    }
    return this.cachedNoiseBuffer;
  }

  public setVolume(vol: number) {
    this.volume = Math.max(0, Math.min(1, vol));
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(this.volume, this.ctx.currentTime);
    }
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(muted ? 0 : this.volume, this.ctx.currentTime);
    }
  }

  public vibrate(pattern: number | number[] = 25) {
    try {
      if (typeof window !== 'undefined' && 'vibrate' in navigator) {
        navigator.vibrate(pattern);
      }
    } catch {
      // Ignore vibration errors if not supported or disabled
    }
  }

  /**
   * Procedural glass clink (<0.3s) for tapping an Iranian estekan
   */
  public playGlassClink() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    // High crystalline glass resonance ~ 2100Hz and harmonic at 3520Hz
    osc.type = 'sine';
    osc.frequency.setValueAtTime(2150, t);
    osc.frequency.exponentialRampToValueAtTime(2080, t + 0.22);

    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(3640, t);
    osc2.frequency.exponentialRampToValueAtTime(3500, t + 0.15);

    gain.gain.setValueAtTime(0.4, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.25);

    osc.connect(gain);
    osc2.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(t);
    osc2.start(t);
    osc.stop(t + 0.25);
    osc2.stop(t + 0.25);

    this.vibrate(15);
  }

  /**
   * Procedural dynamic pitch-rising liquid pouring sound
   */
  public playPouring(layerIndex: number = 0) {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    const t = this.ctx.currentTime;
    const baseFreq = 400 + layerIndex * 110; // Pitch rises as cup fills up!

    // Liquid bubbling modulator
    const modOsc = this.ctx.createOscillator();
    const modGain = this.ctx.createGain();
    modOsc.type = 'sine';
    modOsc.frequency.setValueAtTime(14, t);
    modOsc.frequency.linearRampToValueAtTime(26, t + 0.45);
    modGain.gain.setValueAtTime(80, t);

    // Main water/tea stream resonance
    const osc = this.ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(baseFreq, t);
    osc.frequency.exponentialRampToValueAtTime(baseFreq + 180, t + 0.45);
    modGain.connect(osc.frequency);

    // Filtered noise for tea droplet splash (using cached buffer)
    const noiseBuffer = this.getNoiseBuffer();
    const noise = this.ctx.createBufferSource();
    if (noiseBuffer) {
      noise.buffer = noiseBuffer;
    }

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(baseFreq * 1.5, t);
    filter.Q.setValueAtTime(4, t);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.01, t);
    gain.gain.linearRampToValueAtTime(0.35, t + 0.1);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.45);

    osc.connect(gain);
    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGain);

    modOsc.start(t);
    osc.start(t);
    noise.start(t);

    modOsc.stop(t + 0.45);
    osc.stop(t + 0.45);
    noise.stop(t + 0.45);

    this.vibrate([10, 30, 15]);
  }

  /**
   * Santur-like Persian celebratory chord on puzzle victory (Dastgah Shur / Mahur arpeggio)
   */
  public playSanturVictory() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    const t = this.ctx.currentTime;
    // Notes: D4 (293.66), F#4 (369.99), A4 (440), B4 (493.88), D5 (587.33), F#5 (739.99)
    const notes = [293.66, 369.99, 440.0, 493.88, 587.33, 739.99];

    notes.forEach((freq, idx) => {
      const strikeTime = t + idx * 0.08;
      
      // Santur mezrab double-strike characteristic
      [0, 0.02].forEach((delayOffset) => {
        if (!this.ctx || !this.sfxGain) return;
        const noteTime = strikeTime + delayOffset;

        const osc = this.ctx.createOscillator();
        const harmonic = this.ctx.createOscillator();
        const noteGain = this.ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, noteTime);

        harmonic.type = 'sine';
        harmonic.frequency.setValueAtTime(freq * 2.01, noteTime); // slight detune for bright metallic string resonance

        noteGain.gain.setValueAtTime(0.28 / (idx * 0.2 + 1), noteTime);
        noteGain.gain.exponentialRampToValueAtTime(0.001, noteTime + 1.2);

        osc.connect(noteGain);
        harmonic.connect(noteGain);
        noteGain.connect(this.sfxGain);

        osc.start(noteTime);
        harmonic.start(noteTime);
        osc.stop(noteTime + 1.25);
        harmonic.stop(noteTime + 1.25);
      });
    });

    this.vibrate([40, 60, 40, 80, 50, 120]);
  }

  /**
   * Traditional Persian gold coin chime
   */
  public playCoin() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    const t = this.ctx.currentTime;
    const osc1 = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(987.77, t); // B5
    osc1.frequency.setValueAtTime(1318.51, t + 0.07); // E6

    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(1975.53, t + 0.07);

    gain.gain.setValueAtTime(0.25, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.35);

    osc1.connect(gain);
    osc2.connect(gain);
    gain.connect(this.sfxGain);

    osc1.start(t);
    osc2.start(t);
    osc1.stop(t + 0.35);
    osc2.stop(t + 0.35);
  }

  public playCoins() {
    this.playCoin();
  }

  /**
   * Sound effect when a cup is completely sorted: hot samovar steam hiss + harmonic crystal bell chime
   */
  public playCupServedSteam() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    const t = this.ctx.currentTime;

    // 1. Aromatic Samovar Steam Hiss (Filtered noise)
    try {
      const bufferSize = Math.floor(this.ctx.sampleRate * 0.45);
      const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }

      const whiteNoise = this.ctx.createBufferSource();
      whiteNoise.buffer = noiseBuffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(1200, t);
      filter.frequency.exponentialRampToValueAtTime(600, t + 0.4);
      filter.Q.setValueAtTime(1.5, t);

      const steamGain = this.ctx.createGain();
      steamGain.gain.setValueAtTime(0.01, t);
      steamGain.gain.linearRampToValueAtTime(0.18, t + 0.08);
      steamGain.gain.exponentialRampToValueAtTime(0.001, t + 0.45);

      whiteNoise.connect(filter);
      filter.connect(steamGain);
      steamGain.connect(this.sfxGain);

      whiteNoise.start(t);
      whiteNoise.stop(t + 0.45);
    } catch {
      // Ignored
    }

    // 2. Clear crystal harmonic chime (celebratory pitch sequence)
    const bellPitches = [1046.5, 1318.5, 1567.98, 2093.0]; // C6, E6, G6, C7
    bellPitches.forEach((freq, idx) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const bellGain = this.ctx.createGain();
      const startTime = t + idx * 0.06;

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, startTime);

      bellGain.gain.setValueAtTime(0.18, startTime);
      bellGain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.45);

      osc.connect(bellGain);
      bellGain.connect(this.sfxGain);

      osc.start(startTime);
      osc.stop(startTime + 0.45);
    });

    this.vibrate([35, 50, 40]);
  }

  /**
   * UI Click / Wooden pop
   */
  public playClick() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(320, t);
    osc.frequency.exponentialRampToValueAtTime(80, t + 0.06);

    gain.gain.setValueAtTime(0.3, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.06);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(t);
    osc.stop(t + 0.06);

    this.vibrate(10);
  }

  /**
   * Procedural Radio Gramophone Ambient Tracks (100% Web Audio, Zero External MP3s)
   */
  public playRadioTrack(trackId: RadioTrackId) {
    this.stopRadio();
    this.currentTrack = trackId;

    if (trackId === 'silence' || this.isMuted) return;
    this.initCtx();
    if (!this.ctx || !this.musicGain) return;

    let isRunning = true;
    const timers: number[] = [];

    if (trackId === 'homayoun') {
      // -------------------------------------------------------------
      // Dastgah Homayoun (دستگاه همایون - گوشه بیداد و شوشتری)
      // Royal, mystical, dignified with the signature augmented second (Eb -> F#)
      // Notes: D3 (146.83), Eb3 (155.56), F#3 (185.0), G3 (196.0), A3 (220.0), Bb3 (233.08), D4 (293.66), Eb4 (311.13), F#4 (369.99)
      // -------------------------------------------------------------
      const homayounPhrases = [
        [146.83, 155.56, 185.0, 196.0, 185.0, 155.56, 146.83], // Foroud
        [185.0, 196.0, 220.0, 233.08, 220.0, 196.0, 185.0],    // Bidad
        [220.0, 233.08, 293.66, 311.13, 293.66, 233.08, 220.0], // Ouj
        [185.0, 196.0, 185.0, 155.56, 146.83, 110.0, 146.83],  // Return to base
      ];

      let phraseIdx = 0;
      let noteIdx = 0;

      // Deep gentle mystic drone (سیم واخوان بم تار و تنبور)
      const droneOsc = this.ctx.createOscillator();
      const droneGain = this.ctx.createGain();
      droneOsc.type = 'triangle';
      droneOsc.frequency.setValueAtTime(146.83, this.ctx.currentTime); // D3
      droneGain.gain.setValueAtTime(0.04, this.ctx.currentTime);
      droneOsc.connect(droneGain);
      droneGain.connect(this.musicGain);
      droneOsc.start();

      const playHomayounNote = () => {
        if (!isRunning || !this.ctx || !this.musicGain) return;
        const now = this.ctx.currentTime;
        const currentPhrase = homayounPhrases[phraseIdx % homayounPhrases.length];
        const freq = currentPhrase[noteIdx % currentPhrase.length];

        // Kamancheh / Setar bowed & plucked dual resonance
        const osc = this.ctx.createOscillator();
        const oscHarmonic = this.ctx.createOscillator();
        const vibrato = this.ctx.createOscillator();
        const vibratoGain = this.ctx.createGain();
        const filter = this.ctx.createBiquadFilter();
        const gain = this.ctx.createGain();

        // Persian micro-vibrato (تحریر کمانچه)
        vibrato.frequency.setValueAtTime(5.2, now);
        vibratoGain.gain.setValueAtTime(2.8, now);
        vibrato.connect(vibratoGain);
        vibratoGain.connect(osc.frequency);

        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(freq, now);

        oscHarmonic.type = 'sine';
        oscHarmonic.frequency.setValueAtTime(freq * 2, now);

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(1200, now);
        filter.frequency.exponentialRampToValueAtTime(550, now + 0.85);

        gain.gain.setValueAtTime(0.01, now);
        gain.gain.linearRampToValueAtTime(0.12, now + 0.08);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.95);

        osc.connect(filter);
        oscHarmonic.connect(filter);
        filter.connect(gain);
        gain.connect(this.musicGain);

        vibrato.start(now);
        osc.start(now);
        oscHarmonic.start(now);

        vibrato.stop(now + 1.0);
        osc.stop(now + 1.0);
        oscHarmonic.stop(now + 1.0);

        noteIdx++;
        if (noteIdx >= currentPhrase.length) {
          noteIdx = 0;
          phraseIdx++;
        }

        const delay = noteIdx === 0 ? 900 : 450 + (noteIdx % 3) * 60;
        const timer = window.setTimeout(playHomayounNote, delay);
        timers.push(timer);
      };

      playHomayounNote();

      this.activeMusicNodes = {
        stop: () => {
          isRunning = false;
          try {
            droneOsc.stop();
          } catch {}
          timers.forEach((t) => clearTimeout(t));
        },
      };
      return;
    } else if (trackId === 'dashti') {
      // -------------------------------------------------------------
      // Avaz Dashti (آواز دشتی - نوای سوزناک نی هفت‌بند و سه‌تار دشتستان)
      // Bittersweet, pastoral, deeply nostalgic and soulful
      // Scale: G3 (196.0), A-koron (213.5), Bb3 (233.08), C4 (261.63), D4 (293.66), Eb4 (311.13)
      // -------------------------------------------------------------
      const dashtiMelody = [
        196.0, 213.5, 233.08, 261.63, 293.66, // Daramad Dashti
        293.66, 311.13, 293.66, 261.63, 233.08, 213.5, // Ouj & Suz
        233.08, 261.63, 233.08, 213.5, 196.0, 164.81, 196.0, // Foroud be G
      ];

      let step = 0;

      // Soft Ney breath ambient wind simulation
      const noiseBuffer = this.ctx.createBuffer(1, this.ctx.sampleRate * 2, this.ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < noiseBuffer.length; i++) {
        output[i] = (Math.random() * 2 - 1) * 0.04;
      }
      const breathNoise = this.ctx.createBufferSource();
      breathNoise.buffer = noiseBuffer;
      breathNoise.loop = true;

      const breathFilter = this.ctx.createBiquadFilter();
      breathFilter.type = 'bandpass';
      breathFilter.frequency.setValueAtTime(650, this.ctx.currentTime);
      breathFilter.Q.setValueAtTime(3.0, this.ctx.currentTime);

      const breathGain = this.ctx.createGain();
      breathGain.gain.setValueAtTime(0.04, this.ctx.currentTime);

      breathNoise.connect(breathFilter);
      breathFilter.connect(breathGain);
      breathGain.connect(this.musicGain);
      breathNoise.start();

      const playNeyNote = () => {
        if (!isRunning || !this.ctx || !this.musicGain) return;
        const now = this.ctx.currentTime;
        const freq = dashtiMelody[step % dashtiMelody.length];

        // Ney tone: Warm fundamental + gentle second harmonic with breath vibrato
        const neyOsc = this.ctx.createOscillator();
        const neyHarmonic = this.ctx.createOscillator();
        const neyVibrato = this.ctx.createOscillator();
        const neyVibGain = this.ctx.createGain();
        const neyFilter = this.ctx.createBiquadFilter();
        const neyGain = this.ctx.createGain();

        // Soulful pitch modulation (4.3 Hz vibrato)
        neyVibrato.frequency.setValueAtTime(4.3, now);
        neyVibGain.gain.setValueAtTime(2.2, now);
        neyVibrato.connect(neyVibGain);
        neyVibGain.connect(neyOsc.frequency);

        neyOsc.type = 'sine';
        neyOsc.frequency.setValueAtTime(freq, now);

        neyHarmonic.type = 'triangle';
        neyHarmonic.frequency.setValueAtTime(freq * 2, now);

        neyFilter.type = 'lowpass';
        neyFilter.frequency.setValueAtTime(950, now);
        neyFilter.frequency.exponentialRampToValueAtTime(600, now + 1.2);

        // Soft breath attack and gentle decay
        neyGain.gain.setValueAtTime(0.005, now);
        neyGain.gain.linearRampToValueAtTime(0.14, now + 0.25);
        neyGain.gain.exponentialRampToValueAtTime(0.001, now + 1.3);

        neyOsc.connect(neyFilter);
        neyHarmonic.connect(neyFilter);
        neyFilter.connect(neyGain);
        neyGain.connect(this.musicGain);

        neyVibrato.start(now);
        neyOsc.start(now);
        neyHarmonic.start(now);

        neyVibrato.stop(now + 1.35);
        neyOsc.stop(now + 1.35);
        neyHarmonic.stop(now + 1.35);

        step++;
        const nextTime = step % 4 === 0 ? 1200 : 650 + (step % 2) * 80;
        const timer = window.setTimeout(playNeyNote, nextTime);
        timers.push(timer);
      };

      playNeyNote();

      this.activeMusicNodes = {
        stop: () => {
          isRunning = false;
          try {
            breathNoise.stop();
          } catch {}
          timers.forEach((t) => clearTimeout(t));
        },
      };
      return;
    } else if (trackId === 'tar_sonati') {
      // Modal Tar arpeggios in Chahargah / Isfahan mode
      // Frequencies: D3 (146.83), F3 (174.61), G3 (196.00), A3 (220.00), Bb3 (233.08), C#4 (277.18), D4 (293.66)
      const scale = [146.83, 174.61, 196.0, 220.0, 233.08, 277.18, 293.66, 349.23, 392.0];
      let step = 0;

      const playTarNote = () => {
        if (!isRunning || !this.ctx || !this.musicGain) return;
        const now = this.ctx.currentTime;
        const noteIdx = (step * 3 + (step % 4)) % scale.length;
        const freq = scale[noteIdx];

        // Tar resonance: saw tooth with lowpass filter + mezrab bite
        const osc = this.ctx.createOscillator();
        const oscSymp = this.ctx.createOscillator();
        const filter = this.ctx.createBiquadFilter();
        const noteGain = this.ctx.createGain();

        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(freq, now);

        oscSymp.type = 'triangle';
        oscSymp.frequency.setValueAtTime(freq * 2, now);

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(1400, now);
        filter.frequency.exponentialRampToValueAtTime(450, now + 0.6);

        noteGain.gain.setValueAtTime(0.12, now);
        noteGain.gain.exponentialRampToValueAtTime(0.001, now + 0.7);

        osc.connect(filter);
        oscSymp.connect(filter);
        filter.connect(noteGain);
        noteGain.connect(this.musicGain);

        osc.start(now);
        oscSymp.start(now);
        osc.stop(now + 0.75);
        oscSymp.stop(now + 0.75);

        step++;
        const nextTime = 420 + Math.sin(step) * 60;
        const timer = window.setTimeout(playTarNote, nextTime);
        timers.push(timer);
      };

      playTarNote();
    } else if (trackId === 'tehran_ghadim') {
      // Warm vinyl crackle + soothing retro slow jazz chords
      const chordNotes = [
        [220, 261.63, 329.63, 392], // Am7
        [196, 246.94, 293.66, 349.23], // G7
        [174.61, 220, 261.63, 329.63], // Fmaj7
        [164.81, 207.65, 246.94, 293.66], // E7
      ];
      let chordIndex = 0;

      const playChord = () => {
        if (!isRunning || !this.ctx || !this.musicGain) return;
        const now = this.ctx.currentTime;
        const currentChord = chordNotes[chordIndex % chordNotes.length];

        currentChord.forEach((f) => {
          if (!this.ctx || !this.musicGain) return;
          const osc = this.ctx.createOscillator();
          const g = this.ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(f, now);

          g.gain.setValueAtTime(0.04, now);
          g.gain.linearRampToValueAtTime(0.07, now + 0.8);
          g.gain.exponentialRampToValueAtTime(0.001, now + 3.2);

          osc.connect(g);
          g.connect(this.musicGain);

          osc.start(now);
          osc.stop(now + 3.3);
        });

        chordIndex++;
        const timer = window.setTimeout(playChord, 3000);
        timers.push(timer);
      };

      playChord();
    } else if (trackId === 'lofi_sonati') {
      // Cozy mellow lo-fi melody
      const lofiPentatonic = [196.0, 220.0, 261.63, 293.66, 329.63, 392.0];
      let beat = 0;

      const playLofiBeat = () => {
        if (!isRunning || !this.ctx || !this.musicGain) return;
        const now = this.ctx.currentTime;
        const freq = lofiPentatonic[Math.floor(Math.random() * lofiPentatonic.length)];

        const osc = this.ctx.createOscillator();
        const g = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now);

        g.gain.setValueAtTime(0.08, now);
        g.gain.exponentialRampToValueAtTime(0.001, now + 0.85);

        osc.connect(g);
        g.connect(this.musicGain);

        osc.start(now);
        osc.stop(now + 0.9);

        beat++;
        const timer = window.setTimeout(playLofiBeat, 500);
        timers.push(timer);
      };

      playLofiBeat();
    } else if (trackId === 'samovar_rain') {
      // Procedural bubbling samovar steam + gentle rain noise
      const bufferSize = this.ctx.sampleRate * 2;
      const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = (Math.random() * 2 - 1) * 0.15;
      }

      const rainSource = this.ctx.createBufferSource();
      rainSource.buffer = noiseBuffer;
      rainSource.loop = true;

      const rainFilter = this.ctx.createBiquadFilter();
      rainFilter.type = 'lowpass';
      rainFilter.frequency.setValueAtTime(800, this.ctx.currentTime);

      const rainGain = this.ctx.createGain();
      rainGain.gain.setValueAtTime(0.12, this.ctx.currentTime);

      rainSource.connect(rainFilter);
      rainFilter.connect(rainGain);
      rainGain.connect(this.musicGain);

      rainSource.start();

      // Samovar bubbles periodic pop
      const playBubble = () => {
        if (!isRunning || !this.ctx || !this.musicGain) return;
        const now = this.ctx.currentTime;
        const bOsc = this.ctx.createOscillator();
        const bGain = this.ctx.createGain();

        const bFreq = 600 + Math.random() * 400;
        bOsc.type = 'sine';
        bOsc.frequency.setValueAtTime(bFreq, now);
        bOsc.frequency.exponentialRampToValueAtTime(bFreq + 300, now + 0.08);

        bGain.gain.setValueAtTime(0.05, now);
        bGain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);

        bOsc.connect(bGain);
        bGain.connect(this.musicGain);

        bOsc.start(now);
        bOsc.stop(now + 0.09);

        const timer = window.setTimeout(playBubble, 120 + Math.random() * 180);
        timers.push(timer);
      };

      playBubble();

      this.activeMusicNodes = {
        stop: () => {
          isRunning = false;
          try {
            rainSource.stop();
          } catch {
            // Safe cleanup
          }
          timers.forEach((t) => clearTimeout(t));
        },
      };
      return;
    }

    this.activeMusicNodes = {
      stop: () => {
        isRunning = false;
        timers.forEach((t) => clearTimeout(t));
      },
    };
  }

  public stopRadio() {
    if (this.activeMusicNodes) {
      this.activeMusicNodes.stop();
      this.activeMusicNodes = null;
    }
  }

  public playDiceRoll() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    // Wooden dice bouncing on backgammon board
    const times = [0, 0.08, 0.16, 0.23, 0.29];
    times.forEach((offset, idx) => {
      if (!this.ctx || !this.sfxGain) return;
      const t = this.ctx.currentTime + offset;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(280 + Math.random() * 120, t);
      osc.frequency.exponentialRampToValueAtTime(140, t + 0.05);

      gain.gain.setValueAtTime(0.35 / (idx + 1), t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.05);

      osc.connect(gain);
      gain.connect(this.sfxGain);
      osc.start(t);
      osc.stop(t + 0.06);
    });
    this.vibrate(20);
  }

  public playSugarMelt() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;
    const t = this.ctx.currentTime;

    // Sizzling sweet melting sound
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(800, t);
    osc.frequency.linearRampToValueAtTime(1600, t + 0.25);
    gain.gain.setValueAtTime(0.2, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.3);

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.3);
  }

  public playIceFreeze() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;
    const t = this.ctx.currentTime;

    // Crystalline frosty crackle
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(1200, t);
    osc.frequency.exponentialRampToValueAtTime(300, t + 0.4);
    gain.gain.setValueAtTime(0.3, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.4);

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.45);
    this.vibrate([30, 20, 30]);
  }

  public playTrayClatter() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;
    const t = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(1800, t);
    osc.frequency.exponentialRampToValueAtTime(600, t + 0.15);
    gain.gain.setValueAtTime(0.25, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.15);

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.16);
  }

  public playSaucerClink() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;
    const t = this.ctx.currentTime;

    // Crisp double-clink like a crystal glass hitting a ceramic saucer
    const osc1 = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(2400, t);
    osc1.frequency.exponentialRampToValueAtTime(1800, t + 0.12);

    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(3200, t + 0.04);
    osc2.frequency.exponentialRampToValueAtTime(2200, t + 0.18);

    gain.gain.setValueAtTime(0.35, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.22);

    osc1.connect(gain);
    osc2.connect(gain);
    gain.connect(this.sfxGain);

    osc1.start(t);
    osc2.start(t + 0.04);
    osc1.stop(t + 0.22);
    osc2.stop(t + 0.22);

    // Tactile haptic double-clink [25, 50, 40]
    this.vibrate([25, 50, 40]);
  }

  public getCurrentTrack(): RadioTrackId {
    return this.currentTrack;
  }
}

export const soundEngine = new SoundEngine();
