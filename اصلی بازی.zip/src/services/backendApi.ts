import { PlayerProfile, MahallehMember } from '../types';
import { APP_SECRET, createHmacSignature } from '../utils/antiCheat';

export const APP_VERSION = '1.0.0';

export interface ServerConfig {
  current_version: string;
  direct_apk_url: string;
  changelog?: string;
  force_update?: boolean;
  announcement?: string;
  [key: string]: any;
}

export const DEFAULT_API_URL = 'https://mrasan.ir/api';
export const API_BASE_URL_KEY = 'bahman_teahouse_api_url_v1';

/**
 * Fetches live configuration and direct update info from https://mrasan.ir/api/config.php
 */
export async function fetchServerConfig(): Promise<ServerConfig | null> {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 4500);

    const res = await fetch('https://mrasan.ir/api/config.php', {
      method: 'GET',
      headers: {
        Accept: 'application/json',
      },
      signal: controller.signal,
    });
    clearTimeout(timeoutId);

    if (res.ok) {
      const data: ServerConfig = await res.json();
      return data;
    }
    return null;
  } catch (err) {
    console.warn('Could not fetch server config:', err);
    return null;
  }
}

export function getApiBaseUrl(): string {
  if (typeof window === 'undefined') return DEFAULT_API_URL;
  try {
    const saved = localStorage.getItem(API_BASE_URL_KEY);
    if (saved && saved.trim()) return saved.trim();
  } catch {}
  return DEFAULT_API_URL;
}

export function setApiBaseUrl(url: string): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(API_BASE_URL_KEY, url.trim());
  } catch {}
}

export const API_BASE_URL = getApiBaseUrl();

const DEVICE_ID_KEY = 'bahman_teahouse_device_id_v1';
const PROFILE_KEY = 'bahman_teahouse_player_profile_v1';

/**
 * Returns or generates a persistent device ID for guest authentication
 */
export function getOrCreateDeviceId(): string {
  if (typeof window === 'undefined') return 'server_side_device_placeholder';
  try {
    let id = localStorage.getItem(DEVICE_ID_KEY);
    if (!id) {
      const randomStr = Math.random().toString(36).substring(2, 10);
      const timeStr = Date.now().toString(36);
      id = `dev_${timeStr}_${randomStr}`;
      localStorage.setItem(DEVICE_ID_KEY, id);
    }
    return id;
  } catch {
    return `dev_fallback_${Date.now()}`;
  }
}

/**
 * Gets cached player profile
 */
export function getStoredPlayerProfile(): PlayerProfile {
  const deviceId = getOrCreateDeviceId();
  if (typeof window === 'undefined') {
    return {
      deviceId,
      firstName: '',
      lastName: '',
      nickname: 'مشتری تازه',
      isRegistered: false,
    };
  }

  try {
    const raw = localStorage.getItem(PROFILE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        deviceId,
        firstName: parsed.firstName || '',
        lastName: parsed.lastName || '',
        nickname: parsed.nickname || (parsed.firstName ? `${parsed.firstName} ${parsed.lastName}`.trim() : 'مشتری تازه'),
        isRegistered: !!parsed.isRegistered,
        registeredAt: parsed.registeredAt,
      };
    }
  } catch {
    // fallback
  }

  return {
    deviceId,
    firstName: '',
    lastName: '',
    nickname: 'مشتری تازه',
    isRegistered: false,
  };
}

/**
 * Saves player profile to localStorage
 */
export function saveStoredPlayerProfile(profile: PlayerProfile): void {
  try {
    localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
  } catch {
    // ignore error
  }
}

export interface RegisterResult {
  success: boolean;
  message?: string;
  user?: {
    id?: number;
    nickname?: string;
    coins?: number;
    current_level?: number;
    weekly_score?: number;
  };
}

/**
 * Registers player (first name + last name) without requiring password or login
 */
export async function registerPlayerOnServer(
  firstName: string,
  lastName: string,
  customNickname?: string
): Promise<RegisterResult> {
  const deviceId = getOrCreateDeviceId();
  const trimmedFirst = firstName.trim();
  const trimmedLast = lastName.trim();
  const displayName = customNickname?.trim() || `${trimmedFirst} ${trimmedLast}`.trim();

  // 1. Save locally immediately
  const profile: PlayerProfile = {
    deviceId,
    firstName: trimmedFirst,
    lastName: trimmedLast,
    nickname: displayName || 'اوستای چایخانه',
    isRegistered: true,
    registeredAt: Date.now(),
  };
  saveStoredPlayerProfile(profile);

  // 2. Send to shared hosting backend (https://mrasan.ir/api/register.php)
  try {
    const payload = {
      device_id: deviceId,
      first_name: trimmedFirst,
      last_name: trimmedLast,
      nickname: displayName,
    };

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 2500);

    const baseUrl = getApiBaseUrl();
    const response = await fetch(`${baseUrl}/register.php`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: JSON.stringify(payload),
      signal: controller.signal,
    });
    clearTimeout(timeoutId);

    if (response.ok) {
      const data = await response.json();
      return {
        success: true,
        message: data.message || 'ثبت‌نام با موفقیت انجام شد',
        user: data.user,
      };
    } else {
      const errorData = await response.json().catch(() => null);
      return {
        success: false,
        message: errorData?.message || `خطای سرور (${response.status})`,
      };
    }
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : 'سرور در دسترس نیست';
    // Still true for the client so the game experience is seamless
    return {
      success: true,
      message: `ثبت محلی انجام شد (${errorMsg}). به محض اتصال سرور همگام می‌شود.`,
    };
  }
}

/**
 * Synchronizes player progress to server
 */
export async function syncProgressToServer(params: {
  coins: number;
  currentLevel: number;
  weeklyScoreDelta: number;
  decorations?: Record<string, string>;
}): Promise<{ success: boolean; data?: unknown; error?: string }> {
  const deviceId = getOrCreateDeviceId();
  const profile = getStoredPlayerProfile();

  const payload = {
    device_id: deviceId,
    first_name: profile.firstName,
    last_name: profile.lastName,
    nickname: profile.nickname || 'مشتری تازه',
    coins: params.coins,
    current_level: params.currentLevel,
    weekly_score_delta: params.weeklyScoreDelta,
    decorations: params.decorations,
  };

  const rawPayload = JSON.stringify(payload);
  const timestamp = Math.floor(Date.now() / 1000);
  const signature = await createHmacSignature(rawPayload, timestamp);

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 2500);

    const baseUrl = getApiBaseUrl();
    const response = await fetch(`${baseUrl}/sync.php`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
        'X-Signature': signature,
        'X-Timestamp': timestamp.toString(),
      },
      body: rawPayload,
      signal: controller.signal,
    });
    clearTimeout(timeoutId);

    if (response.ok) {
      const resData = await response.json();
      return { success: true, data: resData };
    }
    return { success: false, error: `HTTP ${response.status}` };
  } catch (err) {
    return { success: false, error: err instanceof Error ? err.message : 'Network error' };
  }
}

export interface LiveLeaderboardResponse {
  isLive: boolean;
  topUsers: MahallehMember[];
  serverMessage?: string;
}

/**
 * Fetches live leaderboard from https://mrasan.ir/api/neighborhood.php
 */
export async function fetchLiveLeaderboard(): Promise<LiveLeaderboardResponse> {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 2500);

    const baseUrl = getApiBaseUrl();
    const response = await fetch(`${baseUrl}/neighborhood.php?action=list`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
      signal: controller.signal,
    });
    clearTimeout(timeoutId);

    if (response.ok) {
      const data = await response.json();
      if (data && Array.isArray(data.top_users)) {
        interface RawUser {
          id?: number | string;
          device_id?: string;
          first_name?: string;
          last_name?: string;
          nickname?: string;
          weekly_score?: number;
          current_level?: number;
        }

        const members: MahallehMember[] = data.top_users.map((u: RawUser, idx: number) => {
          const fullName = u.first_name && u.last_name ? `${u.first_name} ${u.last_name}` : u.nickname || 'اوستای چایخانه';
          return {
            id: String(u.id || idx + 1),
            name: fullName,
            score: Number(u.weekly_score || 0),
            cupsServed: Math.floor(Number(u.weekly_score || 0) / 30) + Number(u.current_level || 1),
            rank: idx + 1,
            badge: idx === 0 ? '👑 قهرمان هفته' : idx === 1 ? '🥈 سماور نقره' : idx === 2 ? '🥉 سماور برنز' : 'عضو محله',
            avatarSeed: (idx % 8) + 1,
          };
        });

        return {
          isLive: true,
          topUsers: members,
        };
      }
    }
    return { isLive: false, topUsers: [] };
  } catch {
    return { isLive: false, topUsers: [] };
  }
}

/**
 * Tests connection to shared hosting backend (default: https://bahmanbamzad.ir/api)
 */
export async function testHostConnection(customUrl?: string): Promise<{
  ok: boolean;
  statusText: string;
  rawResponse?: string;
}> {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3500);

    const baseUrl = customUrl?.trim() || getApiBaseUrl();
    const response = await fetch(`${baseUrl}/neighborhood.php?action=list`, {
      method: 'GET',
      signal: controller.signal,
    });
    clearTimeout(timeoutId);

    const text = await response.text();
    return {
      ok: response.ok,
      statusText: `کد وضعیت: ${response.status} (سرور فعال است)`,
      rawResponse: text.substring(0, 300),
    };
  } catch (err) {
    return {
      ok: false,
      statusText: 'عدم برقراری ارتباط (بررسی کنید فایل‌های PHP در پوشه api هاست آپلود شده باشند)',
      rawResponse: err instanceof Error ? err.message : String(err),
    };
  }
}
