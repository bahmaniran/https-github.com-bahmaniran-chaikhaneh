/**
 * TeahouseStore.ts - Central persistent state manager for Uncle Bahman's Teahouse
 * Manages: Daftar-e-Hesab, Shab-haye Naghali, Renovations & Daily Tip, VIP Bosses, Dice Roll, and Referral Card
 */

import {
  DaftarHesabState,
  NaghaliState,
  TeahouseDecoration,
  VIPBossCustomer,
  DiceRollResult,
  RadioTrackId,
} from '../types';

const STORAGE_KEYS = {
  DAFTAR_HESAB: 'bahman_daftar_hesab_v1',
  NAGHALI: 'bahman_naghali_v1',
  DECORATIONS: 'bahman_decorations_v1',
  DAILY_TIP: 'bahman_daily_tip_claim_v1',
  DICE_ROLL: 'bahman_dice_roll_date_v1',
  REFERRAL: 'bahman_referral_code_v1',
  REDEEMED_REFERRALS: 'bahman_redeemed_referrals_v1',
  RADIO_STATION: 'bahman_radio_station_v1',
};

// -------------------------------------------------------------
// 1. DAFTAR-E-HESAB (Debt System)
// -------------------------------------------------------------
export function getDaftarHesab(): DaftarHesabState {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.DAFTAR_HESAB);
    if (raw) return JSON.parse(raw);
  } catch {}
  return {
    isDebtActive: false,
    debtAmount: 0,
    debtStreak: 0,
    repossessedItem: null,
    borrowDate: null,
  };
}

export function saveDaftarHesab(state: DaftarHesabState) {
  try {
    localStorage.setItem(STORAGE_KEYS.DAFTAR_HESAB, JSON.stringify(state));
  } catch {}
}

export function borrowDebt(): { success: boolean; coinsGranted: number; state: DaftarHesabState } {
  const current = getDaftarHesab();
  if (current.isDebtActive) return { success: false, coinsGranted: 0, state: current };

  const updated: DaftarHesabState = {
    isDebtActive: true,
    debtAmount: 300,
    debtStreak: 0,
    repossessedItem: null,
    borrowDate: new Date().toISOString(),
  };
  saveDaftarHesab(updated);
  return { success: true, coinsGranted: 300, state: updated };
}

export function advanceDebtStreak(): { cleared: boolean; streak: number; state: DaftarHesabState } {
  const current = getDaftarHesab();
  if (!current.isDebtActive) return { cleared: false, streak: 0, state: current };

  const newStreak = current.debtStreak + 1;
  if (newStreak >= 3) {
    const cleared: DaftarHesabState = {
      isDebtActive: false,
      debtAmount: 0,
      debtStreak: 0,
      repossessedItem: null,
      borrowDate: null,
    };
    saveDaftarHesab(cleared);
    return { cleared: true, streak: 3, state: cleared };
  }

  const updated: DaftarHesabState = { ...current, debtStreak: newStreak };
  saveDaftarHesab(updated);
  return { cleared: false, streak: newStreak, state: updated };
}

export function failDebtStreak(ownedDecorations: string[]): { repossessedItem: string | null; state: DaftarHesabState } {
  const current = getDaftarHesab();
  if (!current.isDebtActive) return { repossessedItem: null, state: current };

  // Repossess one paid item if available, otherwise just lock debt
  const candidate = ownedDecorations.find((id) => !id.includes('halabi') && !id.includes('gelim')) || 'samovar_halabi';
  const updated: DaftarHesabState = {
    ...current,
    debtAmount: 350, // penalty with interest
    debtStreak: 0,
    repossessedItem: candidate,
  };
  saveDaftarHesab(updated);
  return { repossessedItem: candidate, state: updated };
}

export function repayDebtRepossession(): { success: boolean; state: DaftarHesabState } {
  const cleared: DaftarHesabState = {
    isDebtActive: false,
    debtAmount: 0,
    debtStreak: 0,
    repossessedItem: null,
    borrowDate: null,
  };
  saveDaftarHesab(cleared);
  return { success: true, state: cleared };
}

// -------------------------------------------------------------
// 2. SHAB-HAYE NAGHALI (Weekend Live-Ops)
// -------------------------------------------------------------
export function getNaghaliState(): NaghaliState {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.NAGHALI);
    if (raw) return JSON.parse(raw);
  } catch {}
  return {
    isActive: false,
    collectedPieces: [],
    isPaintingCompleted: false,
    hasClaimedReward: false,
    goldenGlassUnlocked: false,
  };
}

export function saveNaghaliState(state: NaghaliState) {
  try {
    localStorage.setItem(STORAGE_KEYS.NAGHALI, JSON.stringify(state));
  } catch {}
}

export function awardNaghaliPiece(): { newPiece: number | null; total: number; completed: boolean } {
  const state = getNaghaliState();
  if (state.collectedPieces.length >= 9) {
    return { newPiece: null, total: 9, completed: true };
  }

  const available: number[] = [];
  for (let i = 0; i < 9; i++) {
    if (!state.collectedPieces.includes(i)) available.push(i);
  }

  if (available.length === 0) return { newPiece: null, total: 9, completed: true };

  const piece = available[Math.floor(Math.random() * available.length)];
  const updatedPieces = [...state.collectedPieces, piece];
  const isCompleted = updatedPieces.length === 9;

  const updated: NaghaliState = {
    ...state,
    collectedPieces: updatedPieces,
    isPaintingCompleted: isCompleted,
    goldenGlassUnlocked: isCompleted ? true : state.goldenGlassUnlocked,
  };
  saveNaghaliState(updated);
  return { newPiece: piece, total: updatedPieces.length, completed: isCompleted };
}

// -------------------------------------------------------------
// 3. TEAHOUSE RENOVATION & DAILY TIP JAR
// -------------------------------------------------------------
export const DEFAULT_DECORATIONS: TeahouseDecoration[] = [
  // Samovars
  {
    id: 'samovar_halabi',
    name: 'سماور حلبی سنتی',
    category: 'samovar',
    tier: 1,
    price: 0,
    unlocked: true,
    description: 'سماور نوستالژیک قهوه‌خانه‌ای، همیشه قل‌قل می‌کنه',
    passiveCoinsPerDay: 50,
    icon: '☕',
  },
  {
    id: 'samovar_ghalamzani',
    name: 'سماور برنجی قلم‌زنی',
    category: 'samovar',
    tier: 2,
    price: 500,
    unlocked: false,
    description: 'نقش برجسته رستم و سهراب با جلای اصیل اصفهان',
    passiveCoinsPerDay: 100,
    icon: '✨',
  },
  {
    id: 'samovar_tala',
    name: 'سماور طلاکوب سلطنتی',
    category: 'samovar',
    tier: 3,
    price: 1500,
    unlocked: false,
    description: 'شاهکار دربار قاجار، برقش چشم هر پهلوانی رو می‌گیره',
    passiveCoinsPerDay: 200,
    icon: '👑',
  },
  // Carpets & Beds
  {
    id: 'carpet_gelim',
    name: 'گلیم دستباف ساده',
    category: 'carpet',
    tier: 1,
    price: 0,
    unlocked: true,
    description: 'گلیم خوش‌رنگ و سنتی عشایری',
    passiveCoinsPerDay: 50,
    icon: '🧶',
  },
  {
    id: 'carpet_kashan',
    name: 'قالیچه لچک‌ترنج کاشان',
    category: 'carpet',
    tier: 2,
    price: 600,
    unlocked: false,
    description: 'پشم دست‌ریس با رنگ روناس طبیعی، نرم و شاهانه',
    passiveCoinsPerDay: 120,
    icon: '🏛️',
  },
  {
    id: 'poshti_torkamoon',
    name: 'پشتی و تخت ترکمنی',
    category: 'carpet',
    tier: 3,
    price: 1200,
    unlocked: false,
    description: 'تخت چوبی منبت با پشتی‌های مخمل برای لم دادن مشتی‌ها',
    passiveCoinsPerDay: 180,
    icon: '🛋️',
  },
  // Antiques
  {
    id: 'radio_lampi',
    name: 'رادیو لامپی قدیمی',
    category: 'antique',
    tier: 2,
    price: 400,
    unlocked: false,
    description: 'خش‌خش دلنشین تصنیف‌های بنان و قمرالملوک وزیری',
    passiveCoinsPerDay: 80,
    icon: '📻',
  },
  {
    id: 'ghafas_ghanari',
    name: 'قفس قناری آوازخوان',
    category: 'antique',
    tier: 3,
    price: 800,
    unlocked: false,
    description: 'قناری خوش‌صدا که مشتری‌ها رو مست و سرخوش می‌کنه',
    passiveCoinsPerDay: 150,
    icon: '🐦',
  },
];

export function getOwnedDecorations(): string[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.DECORATIONS);
    if (raw) return JSON.parse(raw);
  } catch {}
  return ['samovar_halabi', 'carpet_gelim'];
}

export function saveOwnedDecorations(ids: string[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.DECORATIONS, JSON.stringify(ids));
  } catch {}
}

export function calculateDailyTipTotal(ownedIds: string[]): number {
  return ownedIds.reduce((sum, id) => {
    const item = DEFAULT_DECORATIONS.find((d) => d.id === id);
    return sum + (item ? item.passiveCoinsPerDay : 0);
  }, 0);
}

export function getDailyTipStatus(ownedIds: string[] = getOwnedDecorations()): { canClaim: boolean; amount: number; hoursLeft: number } {
  const amount = calculateDailyTipTotal(ownedIds);
  let lastClaim: string | null = null;
  try {
    lastClaim = localStorage.getItem(STORAGE_KEYS.DAILY_TIP);
  } catch {}
  if (!lastClaim) return { canClaim: true, amount, hoursLeft: 0 };

  const diffMs = Date.now() - new Date(lastClaim).getTime();
  const hoursLeft = Math.max(0, 24 - diffMs / (1000 * 60 * 60));
  return {
    canClaim: hoursLeft === 0,
    amount,
    hoursLeft: Math.ceil(hoursLeft),
  };
}

export function claimDailyTip(ownedIds: string[] = getOwnedDecorations()): { success: boolean; coins: number } {
  const status = getDailyTipStatus(ownedIds);
  if (!status.canClaim) return { success: false, coins: 0 };

  try {
    localStorage.setItem(STORAGE_KEYS.DAILY_TIP, new Date().toISOString());
  } catch {}
  return { success: true, coins: status.amount };
}

// -------------------------------------------------------------
// 4. RETRO RADIO STATIONS
// -------------------------------------------------------------
// -------------------------------------------------------------
export type RadioStationId = 1 | 2 | 3 | 4 | 5;

export interface RadioStationInfo {
  id: RadioStationId;
  trackId: RadioTrackId;
  name: string;
  genre: string;
  emoji: string;
  dastgahTag: string;
  tickerMessages: string[];
}

export const RADIO_STATIONS: RadioStationInfo[] = [
  {
    id: 1,
    trackId: 'homayoun',
    name: 'موج ۱: دستگاه همایون',
    genre: 'شوشتری، بیداد و نوای کمانچه',
    emoji: '🎻',
    dastgahTag: 'دستگاه همایون (شاهانه)',
    tickerMessages: [
      '🎶 در حال پخش: گوشه بیداد در دستگاه همایون، نغمه‌ای عمیق و شاهانه',
      '☕ طعم زعفران قائنات و آرامش پرشکوه عصر چایخانه عمو بهمن',
      '🎻 مضراب‌های سنگین و پروقار تار و سوز پرابهت کمانچه اصیل',
      '✨ یاد ایام بارگاه و محفل اهل ادب و معرفت قدیم',
    ],
  },
  {
    id: 2,
    trackId: 'dashti',
    name: 'موج ۲: آواز دشتی و نینوا',
    genre: 'سوز نی هفت‌بند و سه‌تار دشتستان',
    emoji: '🪈',
    dastgahTag: 'آواز دشتی (دلنشین و نوستالژیک)',
    tickerMessages: [
      '🌾 در حال پخش: سوز نای هفت‌بند و گیلکی، نغمه‌های دیلمان و دشتستان',
      '✨ چای قندپهلو با هل اعلا و نوای دل‌انگیز نی‌نوا',
      '🌿 نسیم خنک کوهپایه و زمزمه دلتنگی‌های عاشقی',
      '🍵 دم نوش خاطره‌انگیز شب‌های دنج عمو بهمن',
    ],
  },
  {
    id: 3,
    trackId: 'tar_sonati',
    name: 'موج ۳: سنتور و بیات اصفهان',
    genre: 'چهارمضراب‌های بلورین پایور',
    emoji: '🎼',
    dastgahTag: 'آواز اصفهان (پرشور و لطیف)',
    tickerMessages: [
      '🎶 در حال پخش: چهارمضراب اصفهان، ریزهای بلورین مضراب بر سیم سنتور',
      '☕ سماور قل‌قل می‌کنه، چای قندپهلو دست اوستاست...',
      '🌸 نغمه‌های زلال زاینده‌رود و صفای دل مشتی‌های بازار',
      '🌿 نوای خوش سه‌تار و عطر دارچین تازه چایخانه',
    ],
  },
  {
    id: 4,
    trackId: 'lofi_sonati',
    name: 'موج ۴: کوچه‌بازاری و طهران قدیم',
    genre: 'ریتم ۶/۸ ضربی شاد و ضرب زورخانه',
    emoji: '🪘',
    dastgahTag: 'کوچه‌بازاری (شاد و مردمی)',
    tickerMessages: [
      '🎵 ضرب تنبک مشتی و ترانه‌های شاد لاله‌زار و طهران قدیم!',
      '👏 دست بزنید رفقا! چای تازه‌دم نثار پهلوانان مجلس!',
      '✨ ریتم شاد و مرامی کوچه پس‌کوچه‌های خاطره‌انگیز بهارستان',
      '🪘 زنگ مرشد و گرمای نفس لوتی‌های باصفای محله',
    ],
  },
  {
    id: 5,
    trackId: 'samovar_rain',
    name: 'موج ۵: آوای آرامش و سماور',
    genre: 'قل‌قل سماور ذغالی و نم‌نم باران',
    emoji: '☕',
    dastgahTag: 'امبینت چایخانه (آرامش‌بخش)',
    tickerMessages: [
      '🌧️ صدای باران بر شیشه‌های قدی ارسی و گرمای دلپذیر سماور ذغالی',
      '☕ خلوت دنج عمو بهمن، دمی آسودگی از هیاهوی روزگار',
      '🔥 رقص شعله‌های آتش و عطر چای لاهیجان در شب بارانی',
      '🌿 طنین آرام بخش قطرات باران و نوای ملایم چای‌ریزی',
    ],
  },
];

export function getActiveRadioStation(): RadioStationId {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.RADIO_STATION);
    if (raw) {
      const parsed = Number(raw) as RadioStationId;
      if (parsed >= 1 && parsed <= 5) return parsed;
    }
  } catch {}
  return 1;
}

export function setActiveRadioStation(station: RadioStationId) {
  try {
    localStorage.setItem(STORAGE_KEYS.RADIO_STATION, station.toString());
  } catch {}
}

// -------------------------------------------------------------
// 5. VIP BOSS CUSTOMERS
// -------------------------------------------------------------
export const VIP_BOSSES: Record<string, VIPBossCustomer> = {
  javad_sibil: {
    id: 'javad_sibil',
    name: 'جواد سبیل (عجول)',
    title: 'راننده خطی ترمینال جنوب',
    description: 'فقط ۴۵ ثانیه وقت داری! انگشتاش مدام رو میز ضرب گرفته و دیر بجنبی چای‌تو رد می‌کنه!',
    avatarEmoji: '🧔',
    timeLimit: 45,
    tipReward: 200,
    dialogue: [
      'زوود باش اخوی! سرویسم راه افتاد، مسافرا منتظرن!',
      'دست بجنبون جوون! چای سرد بشه از گلو پایین نمیره!',
      'باریکلا! انعام مشتی پیش من محفوظه!',
    ],
  },
  haj_agha: {
    id: 'haj_agha',
    name: 'حاج‌آقا بازاری (سخت‌گیر)',
    title: 'بزرگ صنف قماش بازار بزرگ',
    description: 'فقط ۱۵ حرکت مجاز داری! هر حرکتی رو با چرتکه و حساب کتاب دقیق زیر نظر داره!',
    avatarEmoji: '👳',
    movesLimit: 15,
    tipReward: 200,
    dialogue: [
      'حرکت اضافه توی حجره ما تاوان داره پسرم! با حساب برو جلو.',
      'چرتکه انداختم، بیشتر از ۱۵ حرکت بشه از سود می‌افته!',
      'طیب‌الله! دست به نقدی و حلال‌خوری هنرته.',
    ],
  },
  poet_shekasteh: {
    id: 'poet_shekasteh',
    name: 'شاعر دلشکسته (غمگین)',
    title: 'مرثیه‌خوان خاطرات دور',
    description: 'همه استکان‌ها زیر بخار غلیظ پوشیده شده‌اند! با هر برگشت (Undo) یک بیت غمگین می‌سراید.',
    avatarEmoji: '🥀',
    tipReward: 200,
    dialogue: [
      'چنان در غم فرو رفتم که رنگ از چای هم بگریخت...',
      'هر بار برمی‌گردی، داغ گذشته در دلم تازه می‌شود...',
      'آفرین بر تو که روشنی را به دل تاریک استکان بازگرداندی.',
    ],
  },
};

// -------------------------------------------------------------
// 6. TAKHTEH-NARD (Backgammon Dice)
// -------------------------------------------------------------
export function canRollDiceToday(): boolean {
  try {
    const lastRoll = localStorage.getItem(STORAGE_KEYS.DICE_ROLL);
    if (!lastRoll) return true;
    const lastDate = new Date(lastRoll).toDateString();
    const today = new Date().toDateString();
    return lastDate !== today;
  } catch {
    return true;
  }
}

export function rollBackgammonDice(): DiceRollResult {
  const d1 = Math.floor(Math.random() * 6) + 1;
  const d2 = Math.floor(Math.random() * 6) + 1;
  const isDouble = d1 === d2;
  const isSheshBesh = d1 === 6 && d2 === 6;

  let coins = (d1 + d2) * 10;
  if (isSheshBesh) coins = 500;
  else if (isDouble) coins = 150;

  try {
    localStorage.setItem(STORAGE_KEYS.DICE_ROLL, new Date().toISOString());
  } catch {}

  return {
    dice1: d1,
    dice2: d2,
    isDouble,
    isSheshBesh,
    coinsAwarded: coins,
    freeBooster: isSheshBesh,
  };
}

// -------------------------------------------------------------
// 7. PAHLAVANI BUSINESS CARD & REFERRALS
// -------------------------------------------------------------
export function getOrCreateReferralCode(): string {
  try {
    let code = localStorage.getItem(STORAGE_KEYS.REFERRAL);
    if (!code) {
      code = 'CHAY-' + Math.floor(1000 + Math.random() * 9000);
      localStorage.setItem(STORAGE_KEYS.REFERRAL, code);
    }
    return code;
  } catch {
    return 'CHAY-2026';
  }
}

export function redeemFriendReferral(code: string): { success: boolean; message: string } {
  try {
    const myCode = getOrCreateReferralCode();
    if (code.trim().toUpperCase() === myCode.toUpperCase()) {
      return { success: false, message: 'نمی‌تونی کد خودت رو وارد کنی پهلوون!' };
    }

    let redeemed: string[] = [];
    try {
      const redeemedRaw = localStorage.getItem(STORAGE_KEYS.REDEEMED_REFERRALS) || '[]';
      redeemed = JSON.parse(redeemedRaw);
    } catch {
      redeemed = [];
    }

    if (redeemed.includes(code.trim().toUpperCase())) {
      return { success: false, message: 'این کد دعوت رو قبلاً دریافت کردی رفیق!' };
    }

    redeemed.push(code.trim().toUpperCase());
    try {
      localStorage.setItem(STORAGE_KEYS.REDEEMED_REFERRALS, JSON.stringify(redeemed));
    } catch {}
    return { success: true, message: 'دمت گرم! ۵۰۰ سکه هدیه رفاقت به جیبت اضافه شد!' };
  } catch {
    return { success: false, message: 'خطا در ثبت کد دعوت! دوباره امتحان کن.' };
  }
}
